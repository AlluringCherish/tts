"""CaP 프로그램 병렬 평가.

  python scripts/run_eval.py --run 20261015_r0 --tasks PickPlaceCounterToSink,OpenDrawer --scenes 0-9 --workers 16

결과: runs/<run>/<task>/scene<k>.json (+ .mp4), runs/<run>/meta.json
job마다 새 프로세스(maxtasksperchild=1)라서 MuJoCo 메모리가 쌓이지 않는다.
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def parse_range(s):
    out = []
    for part in s.split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out


def horizon_of(task):
    from robocasa.utils.dataset_registry import ATOMIC_TASK_DATASETS, COMPOSITE_TASK_DATASETS

    d = ATOMIC_TASK_DATASETS.get(task) or COMPOSITE_TASK_DATASETS.get(task) or {}
    return d.get("horizon", 1000)


def run_job(job):
    """렌더러(EGL) 초기화 실패처럼 동시 실행 때문에 가끔 나는 crash는 두 번까지 다시 돌린다."""
    for attempt in range(3):
        out = _run_job(job)
        path = os.path.join(job[2], f"scene{job[1]}.json")
        r = json.load(open(path))
        msg = (r.get("error") or {}).get("msg", "")
        if (r.get("error") or {}).get("code") == "crash" and ("framebuffer" in msg or "RenderContext" in msg or "EGL" in msg):
            time.sleep(2)
            continue
        return out
    return out


def _run_job(job):
    task, scene, out_dir, video, budget_mult, seed = job
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"scene{scene}.json")
    res = dict(task=task, scene=scene, seed=seed, ok=False, success=False, success_step=None, error=None)
    t0 = time.time()
    try:
        import numpy as np

        from cap.env import Recorder, make_env
        from cap.programs import load_all
        from cap.robot import Robot, SkillFailure
        from cap.world import World

        progs = load_all()
        stage = None
        env_task = task
        if "@" in task:  # 구간 평가 (cap/stages.py)
            from cap.stages import STAGES

            stage = STAGES[task]()
            env_task = stage.task
        horizon = horizon_of(env_task)
        res["horizon"] = horizon
        env = make_env(env_task, scene=scene, seed=seed, render=video)
        env.reset()
        res["lang"] = env.get_ep_meta().get("lang")
        res["layout_style"] = [int(env.layout_id), int(env.style_id)]
        res["objects"] = {c["name"]: c.get("info", {}).get("cat", "") for c in (env.object_cfgs or [])}
        rec = Recorder(env, os.path.join(out_dir, f"scene{scene}.mp4") if video else None, every=3)
        R = Robot(env, rec, step_budget=int(horizon * budget_mult))
        W = World(env, R)
        res["reset_s"] = round(time.time() - t0, 1)
        if stage is None and task not in progs:
            raise RuntimeError(f"no program for {task}")
        if stage is not None:
            try:
                stage.setup(W)
            except SkillFailure as e:
                raise RuntimeError(f"stage setup failed: {e}")
            R.success_seen = False
            res["setup_steps"] = R.steps
        try:
            (stage.program if stage else progs[task])(W)
            R.idle(10)  # 물체 안정화
            res["ok"] = True
        except SkillFailure as e:
            res["error"] = dict(code=e.code, msg=e.msg)
        res["success"] = bool(stage.success(W)) if stage else bool(R.success_seen or env._check_success())
        if stage is not None and task.endswith(("@stir", "@lid_power")):
            res["success"] = bool(res["success"] or R.success_seen)
        res["success_step"] = next((s for s, k, e in R.trace if e == "task_success"), None)
        res["success_in_horizon"] = res["success_step"] is not None and res["success_step"] <= horizon
        res["steps"] = R.steps
        res["history"] = W.history
        res["trace"] = R.trace
        res["video"] = rec.save() and os.path.basename(rec.path)
        env.close()
    except Exception as e:  # noqa: BLE001
        res["error"] = dict(code="crash", msg=f"{type(e).__name__}: {e}", tb=traceback.format_exc()[-2000:])
    res["wall_s"] = round(time.time() - t0, 1)
    with open(path, "w") as f:
        json.dump(res, f, indent=1, default=str)
    return task, scene, res["success"], (res["error"] or {}).get("code")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--tasks", required=True, help="콤마 구분 또는 @파일")
    ap.add_argument("--scenes", default="0-9")
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--no-video", action="store_true")
    ap.add_argument("--budget-mult", type=float, default=2.0, help="step 상한 = horizon × 배수 (성공 여부는 horizon 안/밖 따로 기록)")
    ap.add_argument("--note", default="")
    ap.add_argument("--seed-offset", type=int, default=0, help="개발용은 1000 이상 (공식 평가는 0: seed=scene)")
    a = ap.parse_args()
    tasks = open(a.tasks[1:]).read().split() if a.tasks.startswith("@") else a.tasks.split(",")
    scenes = parse_range(a.scenes)
    run_dir = os.path.join(ROOT, "runs", a.run)
    os.makedirs(run_dir, exist_ok=True)
    meta = dict(run=a.run, tasks=tasks, scenes=scenes, note=a.note, started=time.strftime("%Y-%m-%d %H:%M:%S"),
                budget_mult=a.budget_mult, seed_offset=a.seed_offset)
    json.dump(meta, open(os.path.join(run_dir, "meta.json"), "w"), indent=1)
    jobs = [(t, s, os.path.join(run_dir, t), not a.no_video, a.budget_mult, s + a.seed_offset) for t in tasks for s in scenes]
    ctx = mp.get_context("spawn")
    n_ok = 0
    with ctx.Pool(a.workers, maxtasksperchild=1) as pool:
        for i, (t, s, succ, code) in enumerate(pool.imap_unordered(run_job, jobs)):
            n_ok += succ
            print(f"[{i+1}/{len(jobs)}] {t} scene{s} success={succ} err={code}", flush=True)
    meta["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
    json.dump(meta, open(os.path.join(run_dir, "meta.json"), "w"), indent=1)
    print(f"done {n_ok}/{len(jobs)}")


if __name__ == "__main__":
    main()
