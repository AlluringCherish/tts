"""영상에서 프레임 몇 장 뽑아 한 장으로: python scripts/frames.py <mp4> <out.png> [n=6] [start_frac=0] [end_frac=1]"""
import sys, imageio, numpy as np
p, out = sys.argv[1], sys.argv[2]
n = int(sys.argv[3]) if len(sys.argv) > 3 else 6
a = float(sys.argv[4]) if len(sys.argv) > 4 else 0.0
b = float(sys.argv[5]) if len(sys.argv) > 5 else 1.0
r = imageio.mimread(p, memtest=False)
idx = np.linspace(a * (len(r) - 1), b * (len(r) - 1), n).astype(int)
fr = [r[i] for i in idx]
half = (n + 1) // 2
rows = [np.concatenate(fr[:half], 1), np.concatenate(fr[half:] + [np.zeros_like(fr[0])] * (half - len(fr[half:])), 1)]
img = np.concatenate(rows, 0)
img = img[::2, ::2]
imageio.imwrite(out, img)
print(len(r), idx)
