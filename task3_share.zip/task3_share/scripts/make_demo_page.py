"""3개 task CaP 데모 페이지(HTML) 만들기. make_demo_clips.py 결과(manifest.json, clips/)를 같은 폴더에 둔다.

  python scripts/make_demo_page.py --dir <demo dir>
구간 성공률은 runs/의 공식 라운드 결과에서 바로 센다 (각 구간의 가장 최근 라운드).
"""
import argparse
import glob
import html
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# task별 구간: (구간 이름, 결과를 셀 task 폴더(구간 평가 이름), 후보 run 접두사들 — 앞쪽이 우선)
STAGES = {
    "PrepareCoffee": [
        ("벽장 안 머그 꺼내기", "PrepareCoffee@pick_enclosed", ["f3r3_pick", "f3r2_pick", "f3r1_pick"]),
        ("머그를 노즐 아래 놓기", "CoffeeSetupMug@precise", ["f3r3_place", "f3r2_place", "f3r1_place"]),
        ("커피머신 시작 버튼", "StartCoffeeMachine", ["r3_controls"]),
        ("전체 task (target 장면 0-9)", "PrepareCoffee@full3", ["f3_full_target"]),
        ("전체 task (Astra 고정 장면 0-4)", "PrepareCoffee@full3", ["f3_full_astra"]),
    ],
    "StirVegetables": [
        ("채소 2개 냄비에 넣기", "StirVegetables@place", ["f3r3_stir", "f3r2_stir", "f3r1_stir"]),
        ("주걱 집고 젓기", "StirVegetables@stir", ["f3r3_stir", "f3r2_stir", "f3r1_stir"]),
        ("전체 task (target 장면 0-9)", "StirVegetables@full3", ["f3_full_target"]),
        ("전체 task (Astra 고정 장면 0-4)", "StirVegetables@full3", ["f3_full_astra"]),
    ],
    "PrepareVeggieDip": [
        ("냉장고에서 채소 꺼내기", "PrepareVeggieDip@pick_enclosed", ["f3r3_pick", "f3r2_pick", "f3r1_pick"]),
        ("냉장고에서 크림치즈 꺼내기", "PrepareVeggieDip@pick_cheese_enclosed", ["f3r3_pick", "f3r2_pick", "f3r1_pick"]),
        ("블렌더 용기에 넣기", "PickPlaceCounterToBlender@precise", ["f3r3_place", "f3r2_place", "f3r1_place"]),
        ("블렌더 뚜껑 닫기", "CloseBlenderLid@precise", ["f3r3_place", "f3r2_place", "f3r1_place"]),
        ("블렌더 전원 버튼", "TurnOnBlender@precise", ["f3r3_place", "f3r2_place", "f3r1_place"]),
        ("뚜껑 닫기 + 전원 (연속)", "PrepareVeggieDip@lid_power_precise", ["f3r3_place", "f3r2_place", "f3r1_place"]),
        ("전체 task (target 장면 0-9)", "PrepareVeggieDip@full3", ["f3_full_target"]),
    ],
}
TASK_INFO = {
    "PrepareCoffee": "벽장에서 머그를 꺼내 커피머신 노즐 아래에 놓고 시작 버튼을 누른다.",
    "StirVegetables": "카운터의 채소 2개를 화구 위 냄비에 넣고, 주걱을 집어 채소를 젓는다.",
    "PrepareVeggieDip": "냉장고에서 채소와 크림치즈를 꺼내 블렌더에 넣고, 뚜껑을 닫은 뒤 전원을 켠다.",
}


def stage_rate(tdir, runs):
    for run in runs:
        fs = glob.glob(os.path.join(ROOT, "runs", run, tdir, "scene*.json"))
        if fs:
            rs = [json.load(open(f)) for f in fs]
            ok = [r for r in rs if (r.get("error") or {}).get("code") != "crash"]
            return dict(run=run, n=len(ok), s=sum(bool(r.get("success")) for r in ok), crash=len(rs) - len(ok))
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    a = ap.parse_args()
    manifest = json.load(open(os.path.join(a.dir, "manifest.json")))
    gl = {g["skill"]: g for g in json.load(open(os.path.join(ROOT, "docs", "skill_glossary.json")))}
    extra = json.load(open(os.path.join(ROOT, "docs", "skill_glossary_focus3.json")))
    gl.update({g["skill"]: g for g in extra})
    stages = {t: [dict(name=n, tdir=d, **(stage_rate(d, rs) or {})) for n, d, rs in v] for t, v in STAGES.items()}
    summary = json.load(open(os.path.join(ROOT, "docs", "focus3_learning_targets.json")))
    data = dict(manifest=manifest, stages=stages, glossary=gl, info=TASK_INFO, summary=summary)
    tpl = open(os.path.join(ROOT, "dashboard", "demo3_template.html")).read()
    out = tpl.replace("/*__DATA__*/null", json.dumps(data, ensure_ascii=False))
    open(os.path.join(a.dir, "index.html"), "w").write(out)
    print("stages:", {t: [(s["name"], s.get("s"), s.get("n"), s.get("run")) for s in v] for t, v in stages.items()})


if __name__ == "__main__":
    main()
