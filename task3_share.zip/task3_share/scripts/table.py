"""run별 task 성공률·skill 성공률 표 (markdown): python scripts/table.py run1 [run2 ...]"""
import glob, json, os, sys
from collections import defaultdict
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for run in sys.argv[1:]:
    T = defaultdict(lambda: [0, 0, 0]); S = defaultdict(lambda: [0, 0, 0, defaultdict(int)])
    for f in glob.glob(f"{ROOT}/runs/{run}/*/scene*.json"):
        r = json.load(open(f)); t = T[r["task"]]
        t[0] += 1; t[1] += bool(r["success"]); t[2] += bool(r.get("success_in_horizon"))
        for h in r.get("history", []):
            s = S[h["skill"]]; s[0] += 1; s[1] += bool(h.get("ok")); s[2] += bool(h["attempts"] and h["attempts"][0].get("ok"))
            if not h.get("ok"): s[3][h.get("code", "?")] += 1
    print(f"\n### {run}\n\n| task | 성공 | horizon 안 |\n|---|---|---|")
    for k, (n, s, h) in sorted(T.items()):
        print(f"| {k} | {s}/{n} ({100*s//n}%) | {h}/{n} |")
    print("\n| skill | 호출 | 성공률 | 1회 성공률 | 실패 원인 |\n|---|---|---|---|---|")
    for k, (n, s, f, c) in sorted(S.items(), key=lambda x: -x[1][1] / x[1][0]):
        print(f"| {k} | {n} | {100*s//n}% | {100*f//n}% | {' '.join(f'{a}×{b}' for a, b in sorted(c.items(), key=lambda x: -x[1]))} |")
