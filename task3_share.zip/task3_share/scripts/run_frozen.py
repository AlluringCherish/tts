"""Astra 실험과 같은 고정 장면(common frozen scenes)에서 CaP 프로그램 실행.

  python scripts/run_frozen.py --task StirVegetables --scenes 0-4 --run demo_stir_seed5

장면은 astra-robocasa의 scenes.json(장면 n = 평가 seed 목록의 n번째)과 같은 폴더에서 복원한다
(robocasa_astra.worker.Simulator + frozen_scene.restore_scene). Astra 모델은 부르지 않는다.
결과 형식은 run_eval.py와 같다: runs/<run>/<task>/scene<k>.json (+ .mp4)
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Astra 고정 장면을 쓸 때만 필요: 환경 변수로 위치 지정 (기본값은 원래 서버 경로)
ASTRA = os.environ.get("ASTRA_ROOT", "/data/astra-robocasa")
SCENE_ROOT = os.environ.get("ASTRA_SCENE_ROOT", "/data/astra-robocasa-scenes/common-eval-panda-diverse-scenes-20261006")
SCENE_INDEX = f"{ASTRA}/plugins/inspect-robots-robocasa-astra/src/robocasa_astra/astra_robodawn/assets/scenes.json"
for p in (ROOT, f"{ASTRA}/src", f"{ASTRA}/plugins/inspect-robots-robocasa-astra/src"):
    sys.path.insert(0, p)


def make_frozen_env(task, scene):
    """Astra 고정 장면 복원. (env, info, skipped, geom_diff). task가 "Task@stage"면 Task의 장면."""
    task = task.split("@")[0]
    info = json.load(open(SCENE_INDEX))["tasks"][task][scene]
    from robocasa_astra.worker import Simulator

    import numpy as np

    import robocasa_astra.frozen_scene as FS

    # 고정 장면은 aarch64(Spark)에서 만들어져, x86에서는 메시 다각형 배열(mesh_polymap 등) 모양이 다르다.
    # 원래 restore_scene에서 "모양이 다르면 중단"만 "건너뛰고 기록"으로 바꾼 사본을 쓴다.
    # (XML·초기 state·나머지 compiled 배열은 원래대로 복원된다)
    import inspect
    import textwrap

    skipped = []
    src = textwrap.dedent(inspect.getsource(FS.restore_scene))
    src = src.replace('raise ValueError("Frozen model structure mismatch: " + name)',
                      '_SKIPPED.append(name); continue')
    src = src.replace('raise ValueError("Frozen simulation data structure mismatch: " + name)',
                      '_SKIPPED.append("data." + name); continue')
    # 플랫폼 간 부동소수 차이: 기하 바이트 일치 검사 대신 최대 오차를 기록 (1 mm 넘으면 중단)
    src = src.replace('raise ValueError("Frozen world or camera geometry differs: " + name)',
                      '_saved = np.frombuffer(raw, dtype=actual_geometry.dtype).reshape(actual_geometry.shape); '
                      '_GEOM_DIFF[name] = float(np.abs(_saved - actual_geometry).max()); '
                      '_GEOM_DIFF[name] <= 1e-3 or (_ for _ in ()).throw(ValueError("geometry differs: " + name))')
    geom_diff = {}
    ns = dict(vars(FS))
    ns["_GEOM_DIFF"] = geom_diff
    ns["_SKIPPED"] = skipped
    exec(compile(src, FS.__file__, "exec"), ns)
    restore_tolerant = ns["restore_scene"]
    FS.restore_scene = restore_tolerant
    sim = Simulator("PandaOmron", task, horizon=info["horizon"],
                    frozen_scene=os.path.join(SCENE_ROOT, info["folder"]))
    sim.reset(info["simulator_seed"])
    return sim.env, info, skipped, geom_diff


def run_one(job):
    task, scene, out_dir, video = job
    os.environ.setdefault("MUJOCO_GL", "egl")
    os.makedirs(out_dir, exist_ok=True)
    info = json.load(open(SCENE_INDEX))["tasks"][task.split("@")[0]][scene]
    res = dict(task=task, scene=scene, scene_id=info["scene_id"], seed=info["simulator_seed"],
               layout_style=[info["layout_id"], info["style_id"]], horizon=info["horizon"],
               lang=info["instruction"], success=False, success_step=None, error=None)
    t0 = time.time()
    try:
        from cap.env import Recorder
        from cap.programs import load_all
        from cap.robot import Robot, SkillFailure
        from cap.world import World

        env, info, skipped, geom_diff = make_frozen_env(task, scene)
        res["restore_skipped_arrays"] = skipped
        res["restore_geom_maxdiff"] = max(geom_diff.values()) if geom_diff else 0.0
        res["objects"] = {c["name"]: c.get("info", {}).get("cat", "") for c in (env.object_cfgs or [])}
        rec = Recorder(env, os.path.join(out_dir, f"scene{scene}.mp4") if video else None, every=2, size=384)
        R = Robot(env, rec, step_budget=info["horizon"])  # Astra와 같은 step 상한
        W = World(env, R)
        try:
            if "@" in task:  # 구간/전체 프로그램 (cap/stages*.py)
                from cap.stages import STAGES

                st = STAGES[task]()
                st.setup(W)
                st.program(W)
            else:
                load_all()[task](W)
            R.idle(10)
            res["ok"] = True
        except SkillFailure as e:
            res["error"] = dict(code=e.code, msg=e.msg)
        res["success"] = bool(R.success_seen or env._check_success())
        res["success_step"] = next((s for s, k, e in R.trace if e == "task_success"), None)
        res["success_in_horizon"] = res["success_step"] is not None
        res["steps"] = R.steps
        res["history"] = W.history
        res["trace"] = R.trace
        res["video"] = rec.save() and os.path.basename(rec.path)
        env.close()
    except Exception as e:  # noqa: BLE001
        res["error"] = dict(code="crash", msg=f"{type(e).__name__}: {e}", tb=traceback.format_exc()[-2000:])
    res["wall_s"] = round(time.time() - t0, 1)
    json.dump(res, open(os.path.join(out_dir, f"scene{scene}.json"), "w"), indent=1, default=str)
    return task, scene, res["success"], (res["error"] or {}).get("code")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True, help="콤마로 여러 개")
    ap.add_argument("--scenes", default="0-4")
    ap.add_argument("--run", required=True)
    ap.add_argument("--workers", type=int, default=5)
    ap.add_argument("--note", default="")
    a = ap.parse_args()
    lo, hi = (a.scenes.split("-") + [a.scenes])[:2]
    scenes = list(range(int(lo), int(hi) + 1))
    run_dir = os.path.join(ROOT, "runs", a.run)
    os.makedirs(run_dir, exist_ok=True)
    tasks = a.task.split(",")
    meta = dict(run=a.run, tasks=tasks, scenes=scenes, note=a.note or "Astra 고정 장면(demo_seed5와 같은 장면)",
                started=time.strftime("%Y-%m-%d %H:%M:%S"), frozen_scenes=SCENE_ROOT)
    json.dump(meta, open(os.path.join(run_dir, "meta.json"), "w"), indent=1, ensure_ascii=False)
    jobs = [(t, s, os.path.join(run_dir, t), True) for t in tasks for s in scenes]
    with mp.get_context("spawn").Pool(a.workers, maxtasksperchild=1) as pool:
        for t, s, ok, code in pool.imap_unordered(run_one, jobs):
            print(f"{t} scene{s} success={ok} err={code}", flush=True)
    meta["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
    json.dump(meta, open(os.path.join(run_dir, "meta.json"), "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
