"""데모 페이지용 skill 클립 만들기: task별·skill별로 성공 1개, 실패 1개를 실행 영상에서 잘라낸다.

  python scripts/make_demo_clips.py --out <dir>

영상은 Recorder가 `every` step마다 한 프레임을 찍으므로 skill 구간 [start, end] step → 프레임 [start//every, end//every].
run_eval.py는 every=3, run_frozen.py는 every=2.
"""
import argparse
import glob
import json
import os

import imageio
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (데모 그룹 task, 표시 이름, 영상 출처 task 접두사, skill, 설명)
SPECS = [
    ("PrepareCoffee", "벽장 안 머그 꺼내기", "PrepareCoffee", "pick_enclosed"),
    ("PrepareCoffee", "머그 손잡이 잡기", "CoffeeSetupMug", "grasp_mug_handle"),
    ("PrepareCoffee", "머그를 노즐 아래 놓기", "CoffeeSetupMug", "place_under_nozzle"),
    ("PrepareCoffee", "커피머신 시작 버튼", "StartCoffeeMachine", "press_button"),
    ("StirVegetables", "채소 집기", "StirVegetables", "pick"),
    ("StirVegetables", "채소를 냄비에 넣기", "StirVegetables", "place"),
    ("StirVegetables", "주걱 손잡이 잡기", "StirVegetables", "pick_tool"),
    ("StirVegetables", "주걱으로 밀어 젓기", "StirVegetables", "stir_push"),
    ("PrepareVeggieDip", "냉장고에서 채소·크림치즈 꺼내기", "PrepareVeggieDip", "pick_enclosed"),
    ("PrepareVeggieDip", "블렌더 용기에 넣기", "PickPlaceCounterToBlender", "place_into_jug"),
    ("PrepareVeggieDip", "블렌더 뚜껑 잡기", "PrepareVeggieDip", "grasp_lid"),
    ("PrepareVeggieDip", "블렌더 뚜껑 닫기", "PrepareVeggieDip", "close_lid_precise"),
    ("PrepareVeggieDip", "블렌더 전원 버튼", "PrepareVeggieDip", "press_blender_power"),
]
# 전체 흐름 영상 (episode 통째로)
FULL = [
    ("PrepareCoffee", "전체 task 성공 (target 장면 2, 최종 skill)", "f3_full_target", "PrepareCoffee@full3", 2),
    ("StirVegetables", "전체 task 성공 (target 장면 3, 최종 skill)", "f3_full_target", "StirVegetables@full3", 3),
    ("PrepareVeggieDip", "전체 task 실패 예 (target 장면 9: 냉장고→블렌더 이동 중 채소가 빠짐)", "f3_full_target", "PrepareVeggieDip@full3", 9),
]


def run_rank(run):
    """공식 라운드 > 최신 개발 run 순으로 고른다."""
    if run.startswith("f3r"):
        return (0, -int(run[3]))
    return (1, -os.path.getmtime(os.path.join(ROOT, "runs", run)))


def every_of(run):
    return 2 if run.startswith(("focus", "demo")) and os.path.exists(os.path.join(ROOT, "runs", run, "meta.json")) and \
        "frozen_scenes" in json.load(open(os.path.join(ROOT, "runs", run, "meta.json"))) else 3


def find(task_prefix, skill, ok):
    best = None
    for f in glob.glob(os.path.join(ROOT, "runs", "*", "*", "scene*.json")):
        run, tdir = f.split("/")[-3], f.split("/")[-2]
        if tdir.split("@")[0] != task_prefix or not os.path.exists(f.replace(".json", ".mp4")):
            continue
        r = json.load(open(f))
        for h in r.get("history", []):
            if h["skill"] != skill or bool(h.get("ok")) != ok or h.get("end") is None:
                continue
            if h["end"] - h["start"] < 15:
                continue
            key = (run_rank(run), r["scene"])
            if best is None or key < best[0]:
                best = (key, dict(run=run, tdir=tdir, scene=r["scene"], start=h["start"], end=h["end"],
                                  code=h.get("code", ""), msg=(h.get("msg") or "")[:140], lang=r.get("lang", ""),
                                  episode_success=bool(r.get("success"))))
    return best and best[1]


def cut(src, dst, f0, f1, max_frames=360):
    frames = imageio.mimread(src, memtest=False)
    f1 = min(f1, len(frames) - 1)
    f0 = max(0, min(f0, f1))
    sel = frames[f0:f1 + 1]
    if len(sel) > max_frames:  # 너무 길면 고르게 솎아 낸다
        idx = np.linspace(0, len(sel) - 1, max_frames).astype(int)
        sel = [sel[i] for i in idx]
    imageio.mimsave(dst, sel, fps=12, macro_block_size=1, quality=6)
    return len(sel)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "clips"), exist_ok=True)
    manifest = []
    for group, label, prefix, skill in SPECS:
        for ok in (True, False):
            e = find(prefix, skill, ok)
            if e is None:
                continue
            ev = every_of(e["run"])
            name = f"{group}__{skill}__{'ok' if ok else 'fail'}.mp4"
            src = os.path.join(ROOT, "runs", e["run"], e["tdir"], f"scene{e['scene']}.mp4")
            n = cut(src, os.path.join(a.out, "clips", name), e["start"] // ev, e["end"] // ev + 1)
            manifest.append(dict(group=group, label=label, skill=skill, ok=ok, file=f"clips/{name}", frames=n, **e))
            print(name, e["run"], e["tdir"], e["scene"], n)
    for group, label, run, tdir, scene in FULL:
        src = os.path.join(ROOT, "runs", run, tdir, f"scene{scene}.mp4")
        if not os.path.exists(src):
            continue
        r = json.load(open(src.replace(".mp4", ".json")))
        name = f"{group}__full.mp4"
        n = cut(src, os.path.join(a.out, "clips", name), 0, 10 ** 6, max_frames=600)
        manifest.append(dict(group=group, label=label, skill="(전체)", ok=bool(r.get("success")), file=f"clips/{name}",
                             frames=n, run=run, tdir=tdir, scene=scene, lang=r.get("lang", ""),
                             skills=" → ".join(h["skill"] for h in r.get("history", []))))
        print(name, n)
    json.dump(manifest, open(os.path.join(a.out, "manifest.json"), "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
