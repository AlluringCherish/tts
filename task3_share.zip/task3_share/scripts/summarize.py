"""run 결과 요약: python scripts/summarize.py <run> [task_filter]"""
import glob, json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
run = sys.argv[1]; flt = sys.argv[2] if len(sys.argv) > 2 else ""
for f in sorted(glob.glob(f"{ROOT}/runs/{run}/*/scene*.json")):
    r = json.load(open(f))
    if flt not in r["task"]:
        continue
    hs = " > ".join(f"{h['skill']}[{'/'.join('ok' if a.get('ok') else a.get('code','?') for a in h['attempts'])}]" for h in r.get("history", []))
    e = r.get("error") or {}
    print(f"{r['task'][:26]:26s} s{r['scene']} {'OK ' if r['success'] else 'xx '} {r.get('steps')}/{r.get('horizon')} | {hs} | {e.get('msg','')[:150]}")
