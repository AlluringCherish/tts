# focus3 정밀 놓기 + 블렌더 skill (CoffeeSetupMug · 블렌더 넣기 · 뚜껑 · 전원)

코드: `cap/skills/precise.py` (skill), `cap/programs/precise.py` (프로그램, task 이름으로 등록 안 함),
`cap/stages_precise.py` (구간 정의). 기존 파일은 고치지 않았다.

| 구간 이름 | env task | 성공 판정 |
|---|---|---|
| `CoffeeSetupMug@precise` | CoffeeSetupMug | env `_check_success` (머그 body xy가 받침 site 4 cm 안, \|dz\|<0.10, 손 0.25 m 밖) |
| `PickPlaceCounterToBlender@precise` | PickPlaceCounterToBlender | obj_inside_of(blender, th 0.01) + 손 0.25 m 밖 |
| `CloseBlenderLid@precise` | CloseBlenderLid | 뚜껑이 닫힌 위치 4 cm 안 + 7° 안 + 손 0.15 m 밖 |
| `TurnOnBlender@precise` | TurnOnBlender | blender turned_on |
| `PrepareVeggieDip@lid_power_precise` | PrepareVeggieDip | setup은 `@lid_power`와 같음(두 물체를 블렌더 안에 둠). env 성공(넣기+켜짐) |

## skill 설계 (precondition / content / except / effect)

### press_blender_power (전원 버튼)
- pre: 버튼 geom 존재, **뚜껑이 닫혀 있음**(`lid_on_blender`; 아니면 켜져도 바로 꺼진다 → `pre_lid_off`).
- content: base를 버튼이 전방 0.55 m에 오게 평행 이동. 버튼이 카운터 바로 위(높이 ~1.06 m)라 수평 접근은
  손목 관절 한계(joint6)에 걸림 → **위-앞에서 40° 내려 찍는 자세**(손가락 축 수평 → 아래 knob 회피)로
  닫은 손끝을 2 mm/step으로 접촉까지 밀고 6 step 유지, 곧게 6 cm 뒤로 빼서 **접촉을 한 번에 해제**
  (블렌더는 접촉이 끝나는 순간 toggle). 켜졌는지 확인, 안 켜졌으면 높이를 바꿔 최대 3번.
- except: 접근 방향 반대로 8 cm 빼고 기울기(55°, 28°)를 바꿔 재시도. effect: turned_on.
- 기존 PressButton의 `no_press`는 "놓을 때 바뀌는" 상태를 누르는 중에 확인해서 생긴 문제였다.

### grasp_lid / close_lid_precise (뚜껑)
- grasp_lid: 뚜껑의 `handle_main` geom을 찾아, 가운데 손잡이면 손잡이 중간 높이(손끝은 아래 원판 위 3 mm)에서,
  옆 탭형이면 탭 바깥쪽을 위에서 잡는다. 손가락 축 후보 8개 중 **충돌 검사 IK**(planner)로 가능한 것 선택,
  이동 높이는 위 벽장 천장 아래로 제한, 직선 경로로 못 가면 RRT 경로 계획. pre: 뚜껑이 서 있음(`pre_lid_tilted`).
- close_lid_precise: 손목으로 뚜껑을 수평, **yaw를 블렌더 yaw에 맞춤**(사각·주둥이형 뚜껑), 닫힌 위치 +4 cm에서
  뚜껑 body xy를 폐루프 정렬(오차 ~1-3 mm), 2 mm/step으로 내리다 접촉/안착 시 멈추고 다시 수평 → 손 위치를
  유지한 채 천천히 벌리고 위로. effect: 닫힌 위치 3.5 cm·6° 안. except(dropped/misplaced): 다시 잡아 1회 재시도.

### place_into_jug (블렌더에 넣기)
- pre: 쥐고 있음, 용기 입구가 작업 영역 안. content: 용기 int region 중심, 입구(가장자리) 높이 측정 →
  물체 바닥이 입구 +5 cm인 높이로 옮겨 물체 body xy를 중심에 폐루프 정렬 → 입구 +1.2 cm까지 내려 놓아 떨어뜨림.
- effect: `obj_inside_of(th 0.01)` (아니면 `not_inside`). except(dropped): 다시 집기.
- 뒤에 `retreat_far`: 손이 물체에서 0.30 m 이상 멀어질 때까지 위로·base 후진 (r1의 `retreat effect` 실패 대응).

### grasp_mug_handle + place_under_nozzle (머그 → 노즐 아래)
핵심 진단: Panda 손은 **손가락 축 방향으로 21 cm, 두께 6.4 cm**, eef 위 2.6~12.4 cm를 차지한다.
테두리(rim) 잡기는 손이 머그 중심 위로 10 cm 넘게 나오고, 노즐·머신 머리는 머그 윗면 1.5~8 cm 위라
**rim 잡기로는 어떤 머신에서도 노즐 아래로 넣을 수 없다**(r1~r3 manip 0/10의 원인; front 삽입이 10 cm 모자랐던 것).
- grasp_mug_handle: 충돌 mesh 꼭짓점으로 손잡이 방향(긴 수평축 중 단면이 좁은 끝)·바깥 기둥 높이를 찾아
  **손잡이 기둥 윗부분을 위에서, 손가락 축=접선**으로 잡는다. 머그는 15~25 g이라 손잡이에서 기울기 3~13°.
  나중에 손잡이가 진입 방향을 보도록 돌릴 손목 회전량을 고려해 손가락 부호 선택, 옆에 머신이 있으면
  손잡이 축으로 기울인 자세 후보(±25°, ±40°) 중 충돌 없는 IK로.
- nozzle_entry: 정면·±20/40/60° 진입 방향마다 머그가 지나갈 원기둥 띠와 손잡이 위 손 영역을 위로 ray 검사, 막힘 최소 방향.
- place_under_nozzle: base를 site 정면 0.55 m로(쥔 상태에선 팔을 천천히 접음), 손목을 돌려 손잡이가 바깥을 보게,
  손목으로 머그 수평, 받침 윗면(얇은 받침은 ray가 놓쳐 geom으로 보정)과 노즐 사이 여유의 절반 높이로
  site 앞 20 cm에서 **수평으로 밀어 넣음**(3 cm씩, 매번 머그 위치·수평 재보정) → 받침에 닿을 때까지 내려 놓고
  손잡이 방향(바깥)으로 손 빼기. effect: `check_receptacle_placement_for_pouring`.

## 라운드별 결과 (scene 0-9, seed=scene, `--workers 8`)

| 구간 | f3r1 | f3r2 | f3r3 | 기존 (r3_manip 등) |
|---|---|---|---|---|
| CoffeeSetupMug@precise | 7/10 | 6/10 | **5/10** | 0/10 |
| PickPlaceCounterToBlender@precise | 6/10 | 8/10 | **8/10** | (프로그램 없음) |
| CloseBlenderLid@precise | 5/10 | 4/10 | **4/10** (env 생성 실패 2 제외 시 4/8) | 2/10 |
| TurnOnBlender@precise | 10/10 | 10/10 | **10/10** | - |
| PrepareVeggieDip@lid_power_precise | 1/10 | 1/10 | **1/10** (setup/env 실패 3) | 0 (no_press) |

개발 seed(1000+) 최종: CoffeeSetupMug 8/10 (dev_f3_place_9), CounterToBlender 9/10, TurnOnBlender 10/10, CloseBlenderLid 4~5/10.

라운드 사이 수정
- r1→r2: 뚜껑 직선 접근이 위 벽장에 막히면 RRT 경로 계획, 뚜껑을 닫힌 높이까지 누르던 것을 "접촉 시 멈춤 + 다시 수평 +
  손 고정한 채 천천히 벌림"으로, place_into_jug 뒤 `retreat_far`, 머그 높이를 기울기 무관한 자체 높이로.
- r2→r3: 얇은 받침 높이 보정(geom), 쥔 채 base 이동 시 go_home 대신 천천히 팔 접기(r2 s9 떨어뜨림).
  r3에서 CoffeeSetupMug가 6→5로 오히려 줄었다(s4: 진입 중 막혀 e_in 0.107 후 손 뺄 때 끌려감) — 수정 효과 없음/역효과.

## 실패 코드와 원인 (r3 기준, 영상·GT 수치 확인)

| 구간 | 실패 | 원인 |
|---|---|---|
| CoffeeSetupMug | misplaced ×5 | s9(·dev s9): 노즐 앞으로 튀어나온 수평 파이프(z가 머그 윗면 2 cm 위)에 손이 걸림 — 손 높이가 손잡이 위 12 cm라 어느 방향으로도 피할 수 없음. s1: ±60° 비스듬 진입이 마지막 4.8 cm에서 막힘(4 cm 기준 바로 밖). s3: 받침 앞 턱에 머그가 걸려 37° 기울어짐. s8: 노즐 근처에서 5.7 cm 남기고 정지. s4: 진입 막힘 후 손 뺄 때 머그 끌림 |
| PickPlaceCounterToBlender | s9 pick approach | 카운터 위 물체 pregrasp에 팔이 닿지 못함 (pick 계열, 이 계열 밖) |
| | s4 (모든 skill ok) | 놓은 직후는 용기 안이었으나 판정 시 밖 — 물체가 튀어 테두리에 걸침 추정 (th 0.01 엄격) |
| CloseBlenderLid | s3, s8 crash | env 생성 실패 (`_load_model` 50회) — 모든 라운드 동일 |
| | s2 | 블렌더가 위 벽장 바로 아래: 뚜껑 손잡이 위로 손이 들어갈 틈 2~3 cm. 수평으로 밀어 넣는 구현 없음 |
| | s4 | 옆 탭형 뚜껑(0.61 kg): 탭을 잡으면 기울고 빠져 바닥으로 떨어짐 |
| | s5 | 사각 뚜껑: 처음 잡기 grasp_slip ×2, 손 안에서 yaw가 돌아가 놓은 뒤 6~7 cm 밀림 |
| | s6 | 1.95 kg 마개형 뚜껑: 안착 직전 테두리 한쪽에 걸려 cos 0.95 (≈18°) |
| lid_power | misplaced(뚜껑 기울어 안착) ×4, setup/env 실패 3 | 위 뚜껑 문제와 같음(+ 안에 든 채소가 뚜껑을 받침 가능). s7은 모든 skill ok인데 최종 판정 실패 (미확인) |
| TurnOnBlender | 없음 | |

## 최종 판정 (r3 성공률 기준)

| skill / 구간 | r3 | 판정 | 성격 |
|---|---|---|---|
| press_blender_power (TurnOnBlender) | 100% | **CaP 가능** | |
| place_into_jug (PickPlaceCounterToBlender) | 80% | **CaP 가능** (경계) | 남은 실패는 pick 도달·튀어나감. 구현 보완 여지 |
| place_under_nozzle (CoffeeSetupMug) | 50% | **위험** | 노즐 앞 파이프가 있는 머신(10개 중 1~2)은 이 손 모양·스크립트로 **구조적으로 어려움**(손 높이 12 cm). 나머지(비스듬 진입 막힘, 받침 턱, 끌림)는 **구현 부족** — 진입 경로를 충돌 검사 계획으로 고르면 개선 가능 |
| grasp_lid + close_lid_precise (CloseBlenderLid) | 40% (생성 가능 장면 50%) | **위험** | 가운데 손잡이 뚜껑은 대체로 성공. 위 벽장 아래(틈 2~3 cm)·옆 탭형·무거운 마개형은 **구조적으로 어려움**(접촉이 많은 끼워 넣기, 손 안 미끄러짐 → 학습 후보). yaw 미끄러짐·재잡기는 구현 부족 |
| lid + power (PrepareVeggieDip@lid_power_precise) | 10% | **불가** | 전원은 해결(뚜껑만 닫히면 100%). 병목은 뚜껑 안착(위와 같은 구조적 문제)과 setup/env 실패 3개 |

요약: 버튼은 "놓는 순간 toggle"만 맞추면 CaP로 충분. 머그는 rim 잡기 → 손잡이 잡기로 바꿔 0% → 50~80%가 됐지만
머신 모양(노즐 앞 파이프)에 따라 손 크기 때문에 안 되는 경우가 남는다. 뚜껑 끼우기는 모델마다 형상·무게가 달라
스크립트 정렬만으로는 40~50%에 머문다 → 학습(VLA) 대상 후보.
