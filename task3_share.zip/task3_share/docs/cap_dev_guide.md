# CaP 개발 가이드

skill 코드를 쓰는 사람(사람·agent 모두)이 지킬 규칙과 공통 API.

## 구조

```
cap/
  env.py        make_env(task, scene, seed, render) · Recorder
  robot.py      Robot: 저수준 primitive (GT 폐루프) · SkillFailure
  world.py      World: GT 상태 조회 (나중에 perceptor로 교체할 자리)
  fx.py         fixture 기하 헬퍼 (interior region, 빈 자리 찾기)
  skill.py      Skill 기본 클래스 (precondition / content / effect / on_except), @skill 등록
  skills/       skill 구현 (계열별 파일)
  programs/     task별 CaP 프로그램, @program("TaskName")
scripts/run_eval.py   병렬 평가
```

## Skill 형식

```python
@skill("open_drawer")
class OpenDrawer(Skill):
    retries = 1
    def precondition(self, w, fixture): ...  # 불만족이면 raise SkillFailure("pre_<이유>", msg)  (재시도 안 함)
    def content(self, w, fixture): ...       # 동작. 중간 실패는 raise SkillFailure("<코드>", msg)
    def effect(self, w, fixture): return bool  # 완료 조건 (False면 "effect" 실패)
    def on_except(self, w, err, fixture): ...  # 안전 상태로 복구 (gripper 열기, 뒤로 빼기). True면 재시도
```

- 호출: `OpenDrawer(w)(fixture=...)` — 성공 시 True, 실패 시 SkillFailure 전파. 기록은 `w.history`에 자동.
- 실패 코드는 짧고 재사용 가능한 이름으로 (`approach`, `grasp_slip`, `joint_stuck`, `collision`, `effect`, `too_wide`, ...).
  대시보드가 코드별로 집계한다.
- effect는 env의 `_check_success`를 쓰지 말고 GT 상태로 skill 자체의 완료 조건을 판단한다.

## 금지 (cheat)

정책은 실제 동작(action)으로만 환경을 바꾼다. 아래는 쓰면 안 된다.
- `fixture.open_door/close_door/set_joint_state/set_door_state`, `Stove.set_knob_state`, `Sink.set_handle_state`,
  `Dishwasher.slide_rack`, `ToasterOven.slide_rack/set_time`, `Toaster.set_lever`, `ElectricKettle.set_*`,
  `StandMixer.set_head_pos`, `_turned_on` 대입, `set_robot_base`, `sim.data.qpos` 직접 쓰기.
- 읽기(GT 상태 조회)는 자유. joint 값, site/geom 위치, fixture API의 get_* / is_* 는 써도 된다.

## Robot primitive (cap/robot.py)

- 좌표는 모두 world. `R.eef_pos`, `R.eef_mat`(z=접근 방향, x=손가락 벌어지는 축), `R.base_pos`, `R.base_yaw`.
- `R.move_ee(pos, mat=None, tol, max_steps, speed, stop_fn)` 한 점으로 폐루프 이동 (1 step 최대 5 cm).
- `R.move_ee_path(waypoints, mat, step_len, stop_fn)` 경유점 직선 보간 이동 (문 여는 호 등).
- `R.gripper(close: bool, n)`, `R.gripper_width`, `R.grip`(+1 닫힘 명령, -1 열림).
- `R.move_base(xy, yaw)` mobile base 이동 (deadzone 보상, 1.2 cm 정도 오차). `R.go_home()` 팔 초기 자세.
- `R.step(arm=6d, grip, base=3d, mode)` 원시 action. `R.idle(n)`.
- 팔 action은 base frame delta. `R.arm_cmd(pos, mat)`가 world 목표 → action 변환.

## World (cap/world.py)

`w.obj_pos/obj_mat/obj_aabb/obj_half_size(name)`, `w.grasped(name)`, `w.fixture(ref)` (fixture_refs 키나 이름),
`w.joint_q/joint_frac/joint_range/joint_anchor_axis(joint)`, `w.site_pos/geom_pos/body_pos(name)`,
`w.names(kind, contains)` 이름 검색.

## 평가 규칙

- 개발 실행: `--seed-offset 1000` 이상, run 이름 `dev_<계열>_<번호>`. 장면 수·횟수 자유.
- 공식 라운드: seed-offset 0, scene 0-9, run 이름 `r<k>_<계열>` (k=1,2,3). 라운드 사이에만 코드 수정.
  r3 이후에는 더 고치지 않는다 (= "개선해도 안 되는" 판정 기준).
- 동시 시뮬레이터 수는 맡은 몫만 (`--workers`). 서버 28코어를 여러 작업이 나눠 쓴다.
- 영상은 기본으로 저장 (`--no-video`로 끔). 실패 사례는 영상 프레임을 직접 확인하고 원인을 적는다.

python: `/data/miniconda3/envs/rc365_cli/bin/python`, 작업 디렉터리 `/data/cap-rl`.
