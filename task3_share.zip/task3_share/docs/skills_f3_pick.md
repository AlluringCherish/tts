# 막힌 칸 pick (pick_enclosed) — focus3 (2026-10-16)

## 설계 (cap/skills/enclosed.py, 구간: cap/stages_enclosed.py, planner: cap/planner.py 확장)
- precondition: 물체가 들어 있는 fixture interior region(벽장 칸·냉장고 선반)을 찾는다. 없으면 `pre_not_enclosed`.
- content:
  1. 잡기 후보 생성 (칸 안쪽 방향 u 기준): front(수평 접근, 손가락 좌우) / pitch30·45·60(앞-위 비스듬히) /
     plane15·30·45(손가락 축도 기울임: 옆으로 누운 원통·막대) / 머그는 rim(손잡이 피한 벽, 기울인 반지름 방향 집기)·handle.
     폭은 충돌 mesh 꼭짓점으로 손가락 사이 국소 폭을 재고, 손가락을 그 폭+여유로만 벌린다(선반에 손끝이 닿지 않게).
     길쭉한 물체는 손가락 축이 긴 축과 거의 수직인 후보만.
  2. (base 앞뒤·좌우 이동 × torso 높이) 문맥 × 후보를 scratch MjData에서 검사: pregrasp 충돌없는 IK → 직선 접근 →
     물체를 손에 붙인 채 들기(0.03/0.05/중간/최대) → 칸 밖으로 빼기(곧장/좌우 8 cm 비켜서) → 현재 자세에서 RRT.
     base·torso를 옮기는 계획은 ±1.5 cm 위치 오차에도 통하는지 확인(아슬아슬한 계획 배제).
  3. 실행: base·torso 이동 → 실제 상태로 재계획 → 관절 경로를 촘촘히 OSC로 추종(nullspace posture=계획 관절) → 잡기 → 들기 → 빼기
     → 곧장 뒤로 뺀 뒤 home 위치로(IK 직선 경로가 있을 때만).
  4. 옆으로 누운 막대(크림치즈)로 후보가 없으면: 닫은 손끝으로 막대 끝을 안쪽으로 8 cm 밀어 돌린 뒤 재탐색(최대 2회).
- except: 손 열고 칸 밖으로 뺀 뒤 home, 실패 후보는 제외하고 재시도(1회).
- effect: 쥐고 있음 AND 물체 bbox 전체가 칸 앞면보다 바깥.
- 구간: `PrepareCoffee@pick_enclosed`(obj=머그), `PrepareVeggieDip@pick_enclosed`(vegetable), `PrepareVeggieDip@pick_cheese_enclosed`(cream_cheese). 성공 = 쥔 채 칸 밖.

## 라운드 결과 (scene 0-9, seed=scene)
PrepareVeggieDip의 scene 3·8은 RoboCasa 장면 생성 실패(`_load_model() 50 times`, 정책과 무관)로 매 라운드 crash → 분모에서 제외하고 따로 표기.

| 구간 | 기존 Pick (smoke) | f3r1 | f3r2 | f3r3 (최종) | crash |
|---|---|---|---|---|---|
| PrepareCoffee@pick_enclosed | 0/2 (no_ik) | 10/10 | 10/10 | **10/10 = 100%** | 0 |
| PrepareVeggieDip@pick_enclosed | 0/2 | 4/8 | 5/8 | **7/8 = 88%** | 2 (s3, s8) |
| PrepareVeggieDip@pick_cheese_enclosed | – | 2/8 | 5/8 | **5/8 = 62%** | 2 (s3, s8) |

라운드 사이 수정:
- r1→r2: 폭 한도 6.8→7.4 cm (충돌 mesh 국소 폭), 손가락 벌림 여유 축소, base 좌우 ±12 cm 문맥 추가, 들고 옮길 때 RRT의 큰 관절 이동 제거.
- r2→r3: 꺼낸 뒤 home 쪽으로 옮기는 동작 자체를 없앰. 칸 밖에서 쥔 채로 끝내고, 들고 이동은 이동 담당 skill에 맡김.
  (r2 채소 s0·s5: 곧은 관절 경로로 뒤로 빼는 중에도 손가락 끝으로 집은 당근·채소가 관성으로 빠짐)

## 실패 코드와 원인
| 코드 | 라운드·장면 | 원인 | 분류 |
|---|---|---|---|
| not_held | r1 채소 s5·s9, 치즈 s4·s5·s7; r2 채소 s0·s5 | 꺼낸 뒤 옮기는 중 낙하. 기울여 집으면 손가락 끝 쪽만 물체에 닿아 쥐는 힘이 약함 | 내 구현 (r3에서 제거). 다만 들고 이동하는 구간에서는 여전히 위험 |
| no_plan (채소 s6, r1-r3) | 나란히 문 냉장고, 피망(폭 7.5 cm)이 칸 깊숙이(0.70 m) 오른쪽 구석(-0.42 m), z 1.41 | 좁은 칸 + 깊이 + 폭 한계: 손가락이 들어갈 자세에서 팔이 문틀·칸막이와 충돌 | 구조적 (좁은 칸) |
| no_plan (치즈 s2·s6·s9, r1-r3) | 막대가 깊이 0.73-0.78 m에 놓임 (옆으로 눕거나, 앞을 다른 채소가 막음) | 밀어 돌린 뒤에도 집기 직전 자세의 IK가 모두 충돌(ik_pre)이거나 직선 접근이 막힘 | 구조적: 깊은 곳의 납작한 막대는 위 공간이 좁아 손가락 각도가 없음. 끌어내기·굴리기 같은 비파지 조작이 필요 |
| no_plan (채소 s6·s7, r1) | 양파·피망 폭 7 cm 넘음 | 폭 한도 | 내 구현 (r2에서 해결, s7 성공) |
| crash | VeggieDip s3·s8 | 환경 생성 실패 | 정책 밖 |

## 최종 판정 (r3)
- **PrepareCoffee@pick_enclosed: CaP 가능 (100%).** 머그 벽을 기울여 집기(손잡이 피함) + 경로 계획 접근 + 들고 빼기로 해결됨. 기존 Pick의 no_ik 실패가 없어짐.
- **PrepareVeggieDip@pick_enclosed: CaP 가능 (88%).** 남은 1건은 나란히 문 냉장고의 깊은 구석이라 구조적. 다만 손가락 끝으로 집는 경우가 있어서, 들고 이동하는 다음 구간에서는 떨어뜨릴 위험이 남음 (r2 낙하 2건).
- **PrepareVeggieDip@pick_cheese_enclosed: 위험 (62%).** 실패는 모두 깊이 0.73 m 넘는 납작한 막대이고, 위가 막혀 손가락이 선반에 닿지 않는 접근이 없음. 끝을 밀어 돌리는 것으로 일부(가까운 막대)만 해결됨. 내 구현의 여지는 작고(끌어내기 같은 비파지 조작을 더 넣는 정도), 대부분 스크립트 제어에서 구조적으로 어려움 → 학습 후보.
