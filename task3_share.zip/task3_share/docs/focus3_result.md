# 분석 대상 3 task 결과: CaP 구간 판정과 학습 대상 (2026-10-16)

데모 페이지(영상): https://claude.ai/artifact/DSweJ1F5sshWGqymwMfLwb

계획·규칙: docs/focus3_plan.md. 구간별 상세: docs/skills_f3_pick.md, docs/skills_f3_place.md, 젓기·넣기는 runs/f3r1_stir~f3r3_stir.

## 구간 판정 (공식 3라운드 후)

| 판정 | task | 구간 | 최종 성공 | 이유 |
|---|---|---|---|---|
| 학습 대상 | StirVegetables | 주걱으로 젓기 (stir_push) | 5/10 (r1 6 → r2 5 → r3 5) | 주걱이 손 안에서 돌아 빠짐(tool_slip)과 두 채소를 동시에 움직이지 못함. 접촉을 유지하며 미는 동작이라 3라운드 동안 개선이 멈춤. |
| 학습 대상 | PrepareVeggieDip | 블렌더 뚜껑 닫기 (grasp_lid + close_lid_precise) | 4/8 (환경 생성 실패 2 제외) | 옆 탭형·마개형 뚜껑은 잡으면 기울고, 안착 직전 테두리에 걸려 18° 기울어짐(허용 7°). 위 벽장과 2~3 cm 틈인 장면도 있음. |
| 학습 후보 (위험) | PrepareCoffee | 머그를 노즐 아래 놓기 (grasp_mug_handle + place_under_nozzle) | 5/10 (r1 7 → r2 6 → r3 5) | 노즐 위 틈 1.5~8 cm, 노즐 앞 파이프가 튀어나온 머신은 손이 피할 길이 없음. 진입 중 막힘·받침 턱에 걸림은 경로 계획으로 일부 개선 가능. |
| 학습 후보 (위험) | PrepareVeggieDip | 냉장고 깊은 곳의 크림치즈 꺼내기 (pick_enclosed) | 5/8 (r1 2 → r2 5 → r3 5) | 깊이 0.73~0.78 m에 누운 납작한 막대는 손가락이 선반에 닿지 않는 집기 자세가 없음. 밀어 돌리기도 마찰에 따라 달라짐. |
| CaP 보완 필요 | 공통 | 구간 사이 연결: 손끝으로 집은 물체를 들고 이동·다시 잡기 | 전체 task 실패의 대부분 | 막힌 칸에서 비스듬히 집은 물체를 들고 이동하면 빠지고, 내려놓고 손잡이로 다시 잡기(머그)도 손이 못 들어가는 경우가 많음. 구간 평가에는 안 보이고 전체 실행에서만 드러남. |
| CaP 보완 필요 | StirVegetables | 채소 2개 냄비에 넣기 (pick + place) | 4/10 (r1 1 → r2 5 → r3 4) | 둥근 채소가 두 번째 채소를 넣는 동안 굴러 나감, 옮기다 떨어뜨림. 마지막에 다시 확인·재배치하면 고칠 수 있는 구현 문제. |
| CaP | PrepareCoffee | 벽장 안 머그 꺼내기 (pick_enclosed) | 10/10 | 경로 계획 + base·torso 탐색으로 해결. |
| CaP | PrepareVeggieDip | 냉장고 채소 꺼내기 (pick_enclosed) | 7/8 | 남은 1건은 좁은 칸 구석의 넓은 피망 (구조적). |
| CaP (경계) | PrepareVeggieDip | 블렌더 용기에 넣기 (place_into_jug) | 8/10 | 남은 실패는 집기 단계 도달 실패와 물체가 튀어 테두리에 걸림. |
| CaP | PrepareCoffee / PrepareVeggieDip | 버튼 (press_button, press_blender_power) | 10/10, 10/10 | 블렌더는 버튼을 뗄 때 켜지는 점을 반영. |

## 전체 task (최종 skill, 공식 장면에서 1회)

| task | target 장면 0-9 | Astra 고정 장면 0-4 |
|---|---|---|
| PrepareCoffee | 2/10 | 0/5 |
| StirVegetables | 2/10 | 0/5 |
| PrepareVeggieDip | 0/8 (환경 생성 실패 2 제외) | 장면 없음 |

전체 실패는 주로 구간 사이 연결(손끝으로 집은 물체를 들고 이동, 머그를 내려놓고 손잡이로 다시 잡기)과 step 상한 초과에서 난다.
구간 평가에서는 보이지 않던 실패라서, 학습 대상 구간을 정할 때 이 연결 동작을 CaP 쪽에서 먼저 보완하거나 학습 구간에 포함할지 정해야 한다.
