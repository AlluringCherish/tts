# 분석 대상 3 task: skill 재설계·개선 계획 (2026-10-16)

대상: PrepareCoffee, StirVegetables, PrepareVeggieDip. 목표는 세 task를 구간(subtask)으로 나눠 각 구간 skill을
CaP로 최대한 개선한 뒤, 개선해도 안 되는 구간을 학습(VLA) 대상으로 정하는 것.

## 구간과 시험 방법

| task | 구간 | 시험 (구간 평가 `Task@stage` 또는 대리 단독 task) | 담당 |
|---|---|---|---|
| PrepareCoffee | 벽장 안 머그 꺼내기 | `PrepareCoffee@pick`, PickPlaceCabinetToCounter | 막힌 칸 pick |
| | 머그를 노즐 아래 놓기 | CoffeeSetupMug | 정밀 놓기 |
| | 시작 버튼 | StartCoffeeMachine (r3 10/10) | (완료) |
| StirVegetables | 채소 2개 냄비에 넣기 | `StirVegetables@place` | 본 세션 |
| | 주걱 집고 젓기 | `StirVegetables@stir` (채소를 미리 냄비에 넣은 상태) | 본 세션 |
| PrepareVeggieDip | 냉장고 채소·크림치즈 꺼내기 | `PrepareVeggieDip@pick`, `@pick_cheese` | 막힌 칸 pick |
| | 블렌더에 넣기 | PickPlaceCounterToBlender | 정밀 놓기 |
| | 뚜껑 닫기 + 전원 | `PrepareVeggieDip@lid_power`, CloseBlenderLid, TurnOnBlender | 정밀 놓기 |
| 공통 | 물체를 든 채 이동 | 전체 task | 본 세션 |

구간 평가의 setup은 앞 구간이 끝난 상태를 만들기 위해서만 물체 위치를 직접 옮긴다(평가 준비 전용). 정책은 그 뒤 action으로만 움직인다.

## 평가 규칙

- 개발: seed-offset 1000 (scene 0-9), run 이름 `dev_f3_<계열>_<n>`.
- 공식 라운드: seed = scene (0-9), run 이름 `f3r<k>_<계열>`, k=1,2,3. 라운드 사이에만 코드 수정, r3 이후 고정.
- 전체 task: PrepareCoffee·StirVegetables는 Astra 고정 장면 0-4 (`scripts/run_frozen.py`) + target scene 0-9,
  PrepareVeggieDip은 target scene 0-9. run 이름 `f3r<k>_full_*`.
- "개선해도 안 됨" 판정: r3 구간 성공률 < 30% → 학습 대상, 30-80% → 위험(학습 후보), ≥ 80% → CaP.
