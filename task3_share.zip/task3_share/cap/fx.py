"""fixture 기하 헬퍼 (GT). 놓을 위치·영역 계산."""
import numpy as np


def ext_box(fx):
    """fixture 외곽 world 꼭짓점 (p0, px, py, pz)."""
    return [np.asarray(p) for p in fx.get_ext_sites(relative=False)]


def int_regions(fx):
    """{region: (p0, px, py, pz)} world."""
    return {k: [np.asarray(p) for p in v] for k, v in fx.get_int_sites(relative=False).items()}


def region_center(p0, px, py, pz):
    return p0 + (px - p0) / 2 + (py - p0) / 2, p0[2]


def box_grid(p0, px, py, margin=0.06, n=9):
    """p0-px-py 평행사변형 안쪽 격자점 (바닥 높이 p0[2])."""
    ex, ey = px - p0, py - p0
    lx, ly = np.linalg.norm(ex), np.linalg.norm(ey)
    mx, my = min(margin / max(lx, 1e-6), 0.45), min(margin / max(ly, 1e-6), 0.45)
    pts = []
    for a in np.linspace(mx, 1 - mx, n):
        for b in np.linspace(my, 1 - my, n):
            pts.append(p0 + a * ex + b * ey)
    return np.array(pts)


def free_spot(w, fx, near, region=None, clear=0.12, max_dist=0.85, avoid_fixtures=True):
    """fixture 표면(또는 내부 region) 위에서 near와 가깝고 물체와 clear 이상 떨어진 점."""
    if region is None:
        regs = int_regions(fx)
        cands = []
        for p0, px, py, pz in regs.values():
            if np.linalg.norm(px - p0) * np.linalg.norm(py - p0) < 0.01:  # 크기 없는 region은 무시
                continue
            cands.append(box_grid(p0, px, py))
        if not cands:
            p0, px, py, pz = ext_box(fx)
            top = pz[2]
            g = box_grid(p0, px, py)
            g[:, 2] = top
            cands.append(g)
        pts = np.concatenate(cands)
    else:
        p0, px, py, pz = region
        pts = box_grid(p0, px, py)
    objs = [w.obj_pos(o) for o in w.env.objects]
    base = w.R.base_pos[:2]
    best, bscore = None, 1e9
    for p in pts:
        if np.linalg.norm(p[:2] - base) > max_dist:
            continue
        if objs and min(np.linalg.norm(p[:2] - o[:2]) for o in objs) < clear:
            continue
        if avoid_fixtures and _over_other_fixture(w, p, fx):
            continue
        s = np.linalg.norm(p[:2] - np.asarray(near)[:2])
        if s < bscore:
            best, bscore = p, s
    return best


def _over_other_fixture(w, p, fx):
    """점이 sink/stove 등 다른 fixture 위면 True (counter에 놓을 때 싱크 위 회피)."""
    from robocasa.models.fixtures import Sink, Stove, Stovetop

    for f in w.env.fixtures.values():
        if f is fx or not isinstance(f, (Sink, Stove, Stovetop)):
            continue
        p0, px, py, pz = ext_box(f)
        ex, ey = px - p0, py - p0
        d = p - p0
        a, b = np.dot(d, ex) / np.dot(ex, ex), np.dot(d, ey) / np.dot(ey, ey)
        if -0.05 <= a <= 1.05 and -0.05 <= b <= 1.05:
            return True
    return False
