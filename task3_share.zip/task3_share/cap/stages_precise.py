"""정밀 놓기 + 블렌더 계열 구간 (focus3). 단독 atomic task를 이 계열의 skill로 실행한다.

  CoffeeSetupMug@precise, PickPlaceCounterToBlender@precise, CloseBlenderLid@precise, TurnOnBlender@precise
  PrepareVeggieDip@lid_power_precise (채소·크림치즈를 미리 블렌더에 넣은 상태: 뚜껑 + 전원)
성공 판정은 env._check_success() (단독 task 성공 조건 그대로).
"""
from cap.stages import Stage, VeggieLidPower, stage


@stage("CoffeeSetupMug@precise", "CoffeeSetupMug")
class CoffeeSetupMugPrecise(Stage):
    def program(self, w):
        from cap.programs.precise import coffee_setup_mug

        coffee_setup_mug(w)


@stage("PickPlaceCounterToBlender@precise", "PickPlaceCounterToBlender")
class CounterToBlenderPrecise(Stage):
    def program(self, w):
        from cap.programs.precise import counter_to_blender

        counter_to_blender(w)


@stage("CloseBlenderLid@precise", "CloseBlenderLid")
class CloseBlenderLidPrecise(Stage):
    def program(self, w):
        from cap.programs.precise import close_blender_lid

        close_blender_lid(w)


@stage("TurnOnBlender@precise", "TurnOnBlender")
class TurnOnBlenderPrecise(Stage):
    def program(self, w):
        from cap.programs.precise import turn_on_blender

        turn_on_blender(w)


@stage("PrepareVeggieDip@lid_power_precise", "PrepareVeggieDip")
class VeggieLidPowerPrecise(VeggieLidPower):
    """setup은 PrepareVeggieDip@lid_power와 같다 (두 물체를 블렌더 안에 두고 블렌더 앞으로)."""

    def program(self, w):
        from cap.programs.precise import lid_and_power

        lid_and_power(w)

    def success(self, w):
        return bool(w.env._check_success() or w.R.success_seen)
