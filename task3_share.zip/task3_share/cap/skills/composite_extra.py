"""composite task용 보조 skill: navigate_near, navigate_pose, wait.

- navigate_near(fixture, point): fixture 앞 표준 자세(navigate와 같은 방향·거리)에서 fixture 옆 방향으로만
  미끄러져 point(긴 카운터 위의 물체 등)가 정면에 오도록 선다. 표준 자세는 fixture 중심 기준이라
  긴 카운터·식탁에서는 물체가 팔 도달 범위 밖이 되는 경우가 많다.
- navigate_pose(xy, yaw): 기억해 둔 base 자세로 돌아가기 (예: 시작 위치 = 물체가 있던 곳).
- wait(n | until): 아무 동작 없이 기다림 (토스터가 끝날 때까지, 물 아래 두기 등).
"""
import numpy as np

from ..robot import SkillFailure
from ..skill import Skill, skill
from .nav import Navigate, follow, plan_path


def _base_free(w, xy, yaw):
    from .slide import base_pose_free

    return base_pose_free(w, xy, yaw, margin=0.02)


def _drive(w, goal, yaw):
    R = w.R
    R.go_home(max_steps=60)
    if np.linalg.norm(goal - R.base_pos[:2]) < 0.05:
        R.move_base(goal, yaw)
        return
    path = plan_path(w, goal)
    if path is None:
        raise SkillFailure("no_path", "A* failed")
    follow(w, path, yaw)


@skill("navigate_near")
class NavigateNear(Navigate):
    """fixture 정면 줄을 따라 point 앞으로. point: world xyz 또는 env.objects 이름."""

    def content(self, w, fixture, point, **kw):
        p = w.obj_pos(point) if isinstance(point, str) else np.asarray(point, float)
        goal0, yaw = self.target(w, fixture)
        lat = np.array([-np.sin(yaw), np.cos(yaw)])
        s = float(np.dot(p[:2] - goal0, lat))
        goal = goal0
        # 옆으로 민 자리가 다른 fixture와 겹치면 조금씩 덜 민다
        for t in np.linspace(1.0, 0.0, 11):
            g = goal0 + lat * s * t
            if _base_free(w, g, yaw):
                goal = g
                break
        self.goal = (goal, yaw)
        _drive(w, goal, yaw)


@skill("navigate_pose")
class NavigatePose(Skill):
    """world base 자세 (xy, yaw)로 이동 (A* + 추종)."""

    retries = 1

    def content(self, w, xy, yaw, **kw):
        _drive(w, np.asarray(xy, float)[:2], float(yaw))

    def effect(self, w, xy, yaw, **kw):
        return np.linalg.norm(np.asarray(xy)[:2] - w.R.base_pos[:2]) <= 0.10 and np.cos(yaw - w.R.base_yaw) >= 0.99

    def on_except(self, w, err, **kw):
        R = w.R
        back = R.base_pos[:2] - 0.15 * np.array([np.cos(R.base_yaw), np.sin(R.base_yaw)])
        R.move_base(back, R.base_yaw, max_steps=80)
        return True


@skill("wait")
class Wait(Skill):
    """n step 대기, 또는 until()이 참이 될 때까지 (최대 max_steps)."""

    retries = 0

    def content(self, w, n=50, until=None, max_steps=800, **kw):
        R = w.R
        steps = max_steps if until is not None else n
        for _ in range(steps):
            if until is not None and until():
                return
            R.step(arm=np.zeros(6))

    def effect(self, w, n=50, until=None, **kw):
        if until is not None and not until():
            raise SkillFailure("timeout", "condition not reached while waiting")
        return True
