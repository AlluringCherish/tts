"""hinge 문 skill: open_door, close_door.

대상: hinge cabinet (single/double), fridge, microwave (수직 힌지), toaster oven / dishwasher (아래 힌지, drop-down).
GT: door joint anchor/axis/range, door body geom 기하(문짝 판, 손잡이). 문 상태는 action으로만 바꾼다.

문 local 좌표 (Door): a = 힌지 축, r = 축에서 문짝 쪽(반경), n = 열릴 때 문짝이 움직이는 방향(=바깥면 법선).
문이 각도 q일 때 local 점 (a, r, n)의 world 위치 = anchor + B(q) @ (a, r, n).
"""
import numpy as np

from ..robot import SkillFailure
from ..skill import Skill, skill

# ---------------------------------------------------------------- geometry


def rot_axis(axis, ang):
    """Rodrigues 회전 행렬."""
    a = np.asarray(axis, float)
    a = a / np.linalg.norm(a)
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * K @ K


def door_joints(fx, compartment="fridge"):
    """task 성공 판정에 쓰이는 door joint 목록."""
    if hasattr(fx, "_fridge_door_joint_names"):
        return list(fx._fridge_door_joint_names if compartment == "fridge" else fx._freezer_door_joint_names)
    return list(fx.door_joint_names)


def _geom_corners(m, d, g):
    """geom의 local AABB 8 꼭짓점 (world)."""
    aabb = m._model.geom_aabb[g]
    c, h = aabb[:3], aabb[3:]
    R = d.geom_xmat[g].reshape(3, 3)
    p = d.geom_xpos[g]
    pts = []
    for sx in (-1, 1):
        for sy in (-1, 1):
            for sz in (-1, 1):
                pts.append(p + R @ (c + h * np.array([sx, sy, sz])))
    return np.array(pts)


def mat_from(z, x):
    """eef 회전행렬: z=접근 방향, x=손가락 벌어지는 축 (z에 직교화)."""
    z = np.asarray(z, float)
    z = z / np.linalg.norm(z)
    x = np.asarray(x, float)
    x = x - np.dot(x, z) * z
    x = x / np.linalg.norm(x)
    return np.stack([x, np.cross(z, x), z], axis=1)


def flip_x_near(M, ref_x):
    """손가락 축 부호를 현재 eef x와 가깝게 (z축 180도 회전 대칭)."""
    if np.dot(M[:, 0], ref_x) < 0:
        M = M @ np.diag([-1.0, -1.0, 1.0])
    return M


# gripper 충돌 형상 (eef frame, 손가락 닫힘): 손 상자 + 손가락 상자 꼭짓점. probe 측정값.
def _box(lo, hi):
    return np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])


GRIP_PTS = np.concatenate([_box([-0.102, -0.032, -0.124], [0.106, 0.032, -0.026]),
                           _box([-0.03, -0.011, -0.049], [0.03, 0.011, 0.012])])


def grip_support(M, u):
    """eef 자세 M일 때 gripper의 방향 u 쪽 최대 돌출 거리 (eef site 기준)."""
    ul = M.T @ np.asarray(u, float)
    return float((GRIP_PTS @ ul).max())


class Door:
    """door joint 하나의 기하."""

    def __init__(self, w, fx, joint):
        self.w, self.fx, self.joint = w, fx, joint
        m, d = w.sim.model, w.sim.data
        self.jid = m.joint_name2id(joint)
        self.body = m.body(m.jnt_bodyid[self.jid]).name
        lo, hi = w.joint_range(joint)
        if lo < 0:  # 음수 방향으로 열림 (get_joint_state가 1-x로 뒤집는 경우)
            self.q_close, self.q_open, self.sgn = hi, lo, -1.0
        else:
            self.q_close, self.q_open, self.sgn = lo, hi, 1.0
        geoms = w.geoms_of_body_tree(self.body)
        col = [g for g in geoms if m.geom_contype[g] or m.geom_conaffinity[g]]
        nm = {g: (m.geom(g).name or "") for g in geoms}
        self.handle_geoms = [g for g in col if "handle" in nm[g]]
        self.panel_geoms = [g for g in col if g not in self.handle_geoms] or geoms
        self.main_geoms = [g for g in col if nm[g].endswith("door_main") or nm[g].endswith("door_g1")] or self.panel_geoms
        self._ref_frame()

    # ---- state
    @property
    def q(self):
        return self.w.joint_q(self.joint)

    @property
    def frac(self):
        return float(self.fx.get_joint_state(self.w.env, [self.joint])[self.joint])

    @property
    def horizontal(self):
        """힌지 축이 수평 (아래로 열리는 drop-down 문)."""
        return abs(self.anchor_axis()[1][2]) < 0.5

    def anchor_axis(self):
        anc, ax = self.w.joint_anchor_axis(self.joint)
        return anc, ax / np.linalg.norm(ax)

    def _pts(self, geoms):
        m, d = self.w.sim.model, self.w.sim.data
        if not geoms:
            return np.zeros((0, 3))
        return np.concatenate([_geom_corners(m, d, g) for g in geoms])

    def _ref_frame(self):
        anc, ax = self.anchor_axis()
        P = self._pts(self.panel_geoms)
        r = self._panel_dir(anc, ax)
        a = self.sgn * ax  # B를 오른손 좌표계로 유지 (n = a x r = 열리는 방향)
        n = np.cross(a, r)
        self.B0, self.q0 = np.stack([a, r, n], 1), self.q
        loc = (P - anc) @ self.B0
        self.a_rng = (loc[:, 0].min(), loc[:, 0].max())
        self.r_max = loc[:, 1].max()
        Pm = (self._pts(self.main_geoms) - anc) @ self.B0
        self.n_out = Pm[:, 2].max()  # 바깥면 (손잡이 제외)
        self.n_in = loc[:, 2].min()  # 안쪽면 (선반/빈 포함)
        self.n_in_main = Pm[:, 2].min()
        # 손잡이: 가장 긴 geom = bar
        self.bar = None
        if self.handle_geoms:
            best = None
            for g in self.handle_geoms:
                L = (_geom_corners(self.w.sim.model, self.w.sim.data, g) - anc) @ self.B0
                lo, hi = L.min(0), L.max(0)
                ext = max(hi[0] - lo[0], hi[1] - lo[1])
                if best is None or ext > best[0]:
                    best = (ext, lo, hi)
            H = (self._pts(self.handle_geoms) - anc) @ self.B0
            self.h_lo, self.h_hi = H.min(0), H.max(0)
            self.bar = (best[1], best[2])

    def _panel_dir(self, anc, ax):
        """문짝 판 방향(힌지 → 자유끝): 가장 큰 main box geom의 축 중 힌지축에 수직이고 가장 긴 축."""
        m, d = self.w.sim.model, self.w.sim.data
        best = None
        for g in self.main_geoms:
            half = m._model.geom_aabb[g][3:]
            Rg = d.geom_xmat[g].reshape(3, 3)
            for k in range(3):
                v = Rg[:, k]
                if abs(np.dot(v, ax)) > 0.3:
                    continue
                if best is None or half[k] > best[0]:
                    c = d.geom_xpos[g] + Rg @ m._model.geom_aabb[g][:3]
                    best = (half[k], v, c)
        if best is None:
            c = self._pts(self.panel_geoms).mean(0)
            v = c - anc
        else:
            _, v, c = best
            v = v * np.sign(np.dot(c - anc, v) or 1.0)
        v = v - np.dot(v, ax) * ax
        return v / np.linalg.norm(v)

    def frame(self, q=None):
        """q에서의 world (anchor, B=[a r n])."""
        anc, ax = self.anchor_axis()
        if q is None:
            q = self.q
        return anc, rot_axis(ax, (q - self.q0)) @ self.B0

    def to_world(self, loc, q=None):
        anc, B = self.frame(q)
        return anc + B @ np.asarray(loc, float)

    def to_local(self, p, q=None):
        anc, B = self.frame(q)
        return B.T @ (np.asarray(p, float) - anc)

    def q_at(self, f):
        return self.q_close + (self.q_open - self.q_close) * f

    def frac_of_q(self, q):
        return (q - self.q_close) / (self.q_open - self.q_close)

    @property
    def z_rng(self):
        P = self._pts(self.panel_geoms)
        return P[:, 2].min(), P[:, 2].max()

    def a_of_z(self, z):
        """수직 힌지에서 world 높이 z에 해당하는 a 좌표."""
        anc, _ = self.anchor_axis()
        return (z - anc[2]) / self.B0[2, 0]


# ---------------------------------------------------------------- motion helpers
import os

DBG = os.environ.get("DOORDBG")


def dbg(*a):
    if DBG:
        print("[doors]", *a, flush=True)


def track_arc(w, D, loc, q_end, mat_fn, speed=0.012, done_fn=None, max_steps=500, lead_max=0.35,
              stall_steps=40, grip=None, closed_loop=False, slip_fn=None):
    """문 local 점 loc를 q 진행에 맞춰 호를 따라 이동. (밀기/잡고 당기기 공용)

    target 각 qt는 일정 속도로 q_end 쪽으로 진행하되, 실제 문 q보다 lead_max 이상 앞서지 않는다.
    closed_loop=True면 qt = 현재 q + lead (잡고 당길 때).
    mat_fn(qt) -> eef 자세. done_fn() 참이면 종료. 반환: 'done' | 'end' | 'stall'."""
    R = w.R
    rho = max(0.08, np.hypot(loc[1], loc[2]))
    dq = speed / rho
    s = np.sign(q_end - D.q) or 1.0
    qt = D.q
    best_q, best_t = D.q, 0
    for t in range(max_steps):
        if done_fn is not None and done_fn():
            return "done"
        q = D.q
        if closed_loop:
            qt = q + s * min(lead_max, abs(q_end - q))
        else:
            qt = qt + s * dq
            if s * (qt - q) > lead_max:  # 문이 안 따라오면 더 앞서가지 않음
                qt = q + s * lead_max
            if s * (qt - q_end) > 0:
                qt = q_end
        pos = D.to_world(loc, qt)
        R.step(arm=R.arm_cmd(pos, mat_fn(qt), max_dpos=0.6), grip=grip)
        if slip_fn is not None and slip_fn():
            raise SkillFailure("grasp_slip", f"{D.joint}: handle lost at frac {D.frac:.2f}")
        # 진행 감시
        if s * (D.q - best_q) > 0.01:
            best_q, best_t = D.q, t
        elif t - best_t > stall_steps:
            return "stall"
        if not closed_loop and qt == q_end and np.linalg.norm(pos - R.eef_pos) < 0.02 and t - best_t > 10:
            return "end"
    return "end"


def move_path(w, pts, mat, step=0.03, tol=0.02, max_steps=200, grip=None):
    R = w.R
    return R.move_ee_path([np.asarray(p, float) for p in pts], mat, step_len=step, tol=tol, max_steps=max_steps,
                          grip=grip)


def fwd_dir(w, D):
    """닫힌 상태 기준 fixture 안쪽 방향(= -n0, 로봇 → 문) 의 world 벡터 (현재 각도 무관)."""
    _, B = D.frame(D.q_close)
    return -B[:, 2]


# ---------------------------------------------------------------- grasp handle & pull


def handle_grasp(w, D):
    """손잡이 bar를 잡는 local 점과 local 자세(M_loc: columns x,y,z in (a,r,n))."""
    if D.bar is None:
        raise SkillFailure("pre_no_handle", D.joint)
    lo, hi = D.bar
    c = (lo + hi) / 2
    along_a = (hi[0] - lo[0]) >= (hi[1] - lo[1])
    if along_a and not D.horizontal:
        # 수직 bar: 높이는 bar 범위 안에서 eef 현재 높이에 가깝게 (끝 standoff 피함)
        a_eef = D.a_of_z(w.R.eef_pos[2])
        margin = min(0.06, (hi[0] - lo[0]) / 3)
        c[0] = np.clip(a_eef, lo[0] + margin, hi[0] - margin)
        if (hi[0] - lo[0]) < 0.35:
            c[0] = (lo[0] + hi[0]) / 2
    x_loc = np.array([0, 1.0, 0]) if along_a else np.array([1.0, 0, 0])
    z_loc = np.array([0, 0, -1.0])
    M_loc = np.stack([x_loc, np.cross(z_loc, x_loc), z_loc], 1)
    gl = c.copy()
    # 손가락 패드(eef site 뒤 0~1.2cm)가 bar 중심에 오도록, 손가락 끝은 문 면에 닿지 않게
    gl[2] = max((lo[2] + hi[2]) / 2 - 0.004, D.n_out + 0.016)
    return gl, M_loc


def grasp_handle(w, D, deeper=0.0):
    """손잡이 접근 → 잡기. 반환 (grasp local point, M_loc)."""
    R = w.R
    gl, M_loc = handle_grasp(w, D)
    gl[2] = max(gl[2] - deeper, D.n_out + 0.013)
    q = D.q
    B = D.frame(q)[1]
    M = flip_x_near(B @ M_loc, R.eef_mat[:, 0])
    M_loc = B.T @ M
    # 손잡이가 로봇에 가까우면(토스터 오븐) 접근점을 짧게: base 중심에서 0.36m 보다 가까우면 팔이 관절 한계
    dist = np.linalg.norm((D.to_world(gl) - R.base_pos)[:2])
    pre = gl + np.array([0, 0, float(np.clip(dist - 0.36, 0.04, 0.12))])
    R.gripper(False, n=4)
    move_path(w, [D.to_world(pre)], M, step=0.04, max_steps=120)
    if not R.move_ee(D.to_world(pre), M, tol=0.02, max_steps=60):
        if np.linalg.norm(R.eef_pos - D.to_world(pre)) > 0.11:
            raise SkillFailure("approach", f"{D.joint}: pregrasp not reached "
                                           f"(err {np.linalg.norm(R.eef_pos - D.to_world(pre)):.3f})")
    move_path(w, [D.to_world(gl)], M, step=0.012, tol=0.008, max_steps=80)
    R.move_ee(D.to_world(gl), M, tol=0.006, max_steps=20)
    R.gripper(True, n=12)
    if R.gripper_width < 0.003:
        raise SkillFailure("grasp_miss", f"{D.joint}: gripper closed on nothing")
    return gl, M_loc


def pull_open(w, D, gl, M_loc, f_target, max_steps=350):
    """손잡이 잡은 채로 문 호를 따라 당김 (자세도 같이 회전)."""
    R = w.R

    def slip():
        return np.linalg.norm(R.eef_pos - D.to_world(gl)) > 0.035

    res = track_arc(w, D, gl, D.q_at(min(1.0, f_target + 0.05)), lambda qt: D.frame(qt)[1] @ M_loc,
                    done_fn=lambda: D.frac >= f_target, closed_loop=True, lead_max=0.15 if D.horizontal else 0.06, grip=1.0,
                    slip_fn=slip, max_steps=max_steps, stall_steps=50)
    return res


def release_back(w, D, dist=0.10):
    """gripper 열고 문 바깥 법선 방향(현재 각)으로 물러남."""
    R = w.R
    R.gripper(False, n=8)
    n = D.frame()[1][:, 2]
    R.move_ee_path([R.eef_pos + dist * n], R.eef_mat, step_len=0.02, max_steps=40)


# ---------------------------------------------------------------- push phases

Z_MIN, Z_MAX = 0.45, 1.55  # eef 높이 도달 범위(근사)


def push_mat(w, D, route="front"):
    """밀기 자세(world 고정): 접근 = fixture 안쪽(-n0).
    수직 힌지: 손가락 축 = 힌지축(수평 방향으로 얇음). under/over 경로는 손가락 축 = r0 (수직으로 얇음).
    수평 힌지: 손가락 축 = 힌지축."""
    _, B0 = D.frame(D.q_close)
    z = -B0[:, 2]
    x = B0[:, 1] if (route in ("under", "over") and not D.horizontal) else B0[:, 0]
    return flip_x_near(mat_from(z, x), w.R.eef_mat[:, 0])


def face_offset(D, M, q, side):
    """eef가 문 면에 닿을 때 eef site와 면 사이 거리. side=+1: 바깥쪽에서 -n 방향으로 밂, -1: 안쪽에서 +n."""
    n = D.frame(q)[1][:, 2]
    return grip_support(M, -side * n)


def push_sweep(w, D, loc_fn, q_end, M, done_fn, max_steps=700, speed=0.012, stall=60):
    """local 접촉점 loc_fn(qt)을 문 호를 따라 이동하며 밂. target 각은 일정 속도로 진행하되 문보다 너무 앞서지 않음."""
    R = w.R
    rho = max(0.08, abs(loc_fn(D.q)[1]))
    dq = speed / rho
    s = np.sign(q_end - D.q) or 1.0
    qt = D.q
    best_q, best_t = D.q, 0
    lead_max = 0.08 / rho + 0.08
    for t in range(max_steps):
        if done_fn():
            return "done"
        q = D.q
        qt = qt + s * dq
        if s * (qt - q) > lead_max:
            qt = q + s * lead_max
        if s * (qt - q_end) > 0:
            qt = q_end
        pos = D.to_world(loc_fn(qt), qt)
        R.step(arm=R.arm_cmd(pos, M, max_dpos=0.6), grip=1.0)
        if s * (D.q - best_q) > 0.004:
            best_q, best_t = D.q, t
        elif t - best_t > stall:
            return "stall"
    return "timeout"


def hold(w, n=6):
    R = w.R
    for _ in range(n):
        R.step(arm=R.arm_cmd(R.eef_pos, R.eef_mat), grip=R.grip)


def retreat_from(w, D, side, dist=0.10, up=0.0):
    """문 면에서 떨어짐: side=+1 바깥쪽(+n), -1 안쪽(-n)."""
    R = w.R
    n = D.frame()[1][:, 2]
    tgt = R.eef_pos + side * dist * n + np.array([0, 0, up])
    R.move_ee_path([tgt], R.eef_mat, step_len=0.02, max_steps=40)


def _hflat(v):
    v = np.array([v[0], v[1], 0.0])
    return v / (np.linalg.norm(v) + 1e-9)


REACH_OK = 0.78  # base 중심(link0)에서 eef 수평 거리 여유 한계
PHASE2_FRAC = 0.42  # 이 이하로 닫히면 바깥면이 로봇 쪽을 향함 -> 앞에서 밀기


def door_frame2d(D):
    """닫힌 상태 기준 2D: hinge xy, r0, n0 (수평 단위벡터)."""
    anc, B0 = D.frame(D.q_close)
    return anc[:2], _hflat(B0[:, 1])[:2], _hflat(B0[:, 2])[:2]


def base_in_door2d(w, D):
    hinge, r0, n0 = door_frame2d(D)
    rel = w.R.base_pos[:2] - hinge
    return float(rel @ r0), float(rel @ n0)


FOOT = dict(front=0.30, back=0.58, half_w=0.29)  # base footprint (+여유)


def base_pose_free(w, xy, yaw):
    """base footprint가 fixture(카운터/아일랜드/벽/냉장고 등)와 겹치지 않는지 (2D)."""
    from robocasa.utils import object_utils as OU

    c, s_ = np.cos(yaw), np.sin(yaw)
    fwd, left = np.array([c, s_]), np.array([-s_, c])
    for fx_ in np.linspace(-FOOT["back"], FOOT["front"], 5):
        for fy in np.linspace(-FOOT["half_w"], FOOT["half_w"], 4):
            p = np.asarray(xy) + fx_ * fwd + fy * left
            p3 = np.r_[p, 0.3]
            if OU.check_fxtr_contact(w.env, p3) or OU.point_outside_scene(w.env, p3):
                return False
    return True


def base_path_free(w, xy, yaw):
    R = w.R
    a, b = R.base_pos[:2], np.asarray(xy)
    n = max(2, int(np.linalg.norm(b - a) / 0.08))
    for k in range(1, n + 1):
        if not base_pose_free(w, a + (b - a) * k / n, yaw):
            return False
    return True


def goto_base(w, D, r_off, n_off, tag, n_min=None):
    """base를 hinge 기준 (r0, n0) 오프셋 위치로(fixture를 바라보게). 충돌하면 n_off를 줄이며 가능한 곳을 찾는다.
    팔은 먼저 접는다. 반환: 이동했으면 True."""
    R = w.R
    hinge, r0, n0 = door_frame2d(D)
    yaw = float(np.arctan2(-n0[1], -n0[0]))
    n_min = n_off - 0.3 if n_min is None else n_min
    cands = []
    for dn in np.arange(0.0, n_off - n_min + 1e-6, 0.05):
        for dr in (0.0, 0.08, -0.08, 0.16, -0.16):
            cands.append((r_off + dr, n_off - dn))
    for ro, no in cands:
        xy = hinge + ro * r0 + no * n0
        if base_pose_free(w, xy, yaw) and base_path_free(w, xy, R.base_yaw):
            R.go_home()
            ok = R.move_base(xy, yaw, max_steps=300)
            R.log("close_door", f"{D.joint}: base->{tag} ({ro:.2f},{no:.2f}) ok={ok}")
            dbg(f"base->{tag} want=({r_off:.2f},{n_off:.2f}) got=({ro:.2f},{no:.2f}) ok={ok}")
            return True
    R.log("close_door", f"{D.joint}: base->{tag} no free pose")
    dbg(f"base->{tag} no free pose")
    return False


def contact_z(w, D, lo_margin=0.10, hi_margin=0.10):
    zb, zt = D.z_rng
    z = np.clip(1.05, zb + lo_margin, zt - hi_margin)
    return float(z)


def phase1_route(w, D):
    """크게 열린 수직 문: 바깥면에 접근하는 경로. under(문 아래 통과, 상부장/전자레인지) 또는 around(자유끝 돌아감)."""
    zb, zt = D.z_rng
    if zb - 0.07 >= 1.0:
        return "under"
    if zt + 0.07 <= Z_MAX and zt < 1.2:
        return "over"
    return "around"


def push_target(w, D, z_want):
    """미는 접촉점 (a, rho, n_face). 손잡이가 있으면 손잡이 bar 바깥면(가장 튀어나온 곳)을 민다
    (손잡이를 피하는 것보다 확실하고, 자유끝 가까이라 힘이 덜 든다). 없으면 문짝 바깥면 0.75W."""
    zb, zt = D.z_rng
    z_want = float(np.clip(z_want, zb + 0.06, zt - 0.06))
    a_w = D.a_of_z(z_want)
    if D.bar is not None:
        lo, hi = D.bar
        m = min(0.04, (hi[0] - lo[0]) / 3)
        a_c = float(np.clip(a_w, lo[0] + m, hi[0] - m))
        return a_c, float((lo[1] + hi[1]) / 2), float(hi[2])
    return a_w, 0.75 * D.r_max, D.n_out


def sweep_close(w, D, M, tgt, f_stop, tag):
    a_c, rho, n_face = tgt
    loc_fn = lambda qt: np.array([a_c, rho, n_face + face_offset(D, M, qt, +1) - 0.012])
    q_end = D.q_close - D.sgn * (0.03 / rho) if f_stop <= 0.01 else D.q_at(f_stop - 0.1)
    res = push_sweep(w, D, loc_fn, q_end, M, done_fn=lambda: D.frac <= f_stop)
    w.R.log("close_door", f"{D.joint}: {tag} sweep={res} frac={D.frac:.3f}")
    dbg(f"{tag} res={res} frac={D.frac:.3f} eef_loc={np.round(D.to_local(w.R.eef_pos), 3)} tgt={np.round(tgt, 3)}")
    return res


def close_phase1_edge(w, D):
    """자유끝 쪽에서 문짝 방향(-r)으로 gripper를 세워 손잡이(또는 문짝) 바깥면에 손가락을 걸고,
    문과 함께 회전하며(자세도 문 frame에 고정) PHASE2_FRAC 까지 민다. 팔이 문 자유끝 바깥에 머물러
    문이 닫히는 길을 막지 않는다."""
    R = w.R
    W = D.r_max
    if D.bar is not None:
        lo, hi = D.bar
        a_lo, a_hi = lo[0], hi[0]
        r_c, n_face = (lo[1] + hi[1]) / 2, D.h_hi[2]
    else:
        a_lo, a_hi = D.a_rng
        r_c, n_face = W - 0.04, D.n_out
    zb, zt = D.z_rng
    a_w = D.a_of_z(float(np.clip(1.05, zb + 0.08, zt - 0.08)))
    m = min(0.12, (a_hi - a_lo) / 3)
    a_c = float(np.clip(a_w, a_lo + m, a_hi - m))
    br, bn = base_in_door2d(w, D)
    n_need = r_c + 0.45
    if not (bn >= n_need - 0.06 and -0.2 <= br <= 0.2):
        goto_base(w, D, 0.05, n_need, "phase1")
    # door-local 자세: z = -r (힌지 쪽), x = a (손가락 축 수직 -> n 방향으로 얇음: 손가락 ±1.1cm, 손 ±3.2cm)
    z_loc, x_loc = np.array([0, -1.0, 0]), np.array([1.0, 0, 0])
    M_loc = np.stack([x_loc, np.cross(z_loc, x_loc), z_loc], 1)
    B = D.frame()[1]
    M = flip_x_near(B @ M_loc, R.eef_mat[:, 0])
    M_loc = B.T @ M
    n_e = max(n_face + 0.011, D.n_out + 0.034) + 0.006
    R.gripper(True, n=4)
    pre = [a_c, W + 0.16, n_e + 0.02]
    move_path(w, [D.to_world(pre)], M, step=0.04, max_steps=250)
    move_path(w, [D.to_world([a_c, r_c, n_e])], M, step=0.015, max_steps=120)
    loc = np.array([a_c, r_c, n_face + 0.011 - 0.012])
    best, t_best, res = D.frac, 0, "stall"
    for t in range(500):
        if D.frac <= PHASE2_FRAC:
            res = "done"
            break
        qt = D.q - D.sgn * 0.12
        R.step(arm=R.arm_cmd(D.to_world(loc, qt), D.frame(qt)[1] @ M_loc, max_dpos=0.6), grip=1.0)
        if D.frac < best - 0.004:
            best, t_best = D.frac, t
        elif t - t_best > 50:
            break
    R.log("close_door", f"{D.joint}: phase1-edge {res} frac={D.frac:.3f}")
    dbg(f"phase1-edge res={res} frac={D.frac:.3f} eef_loc={np.round(D.to_local(R.eef_pos), 3)} loc={np.round(loc, 3)}")
    # 자유끝 바깥으로 빠짐
    R.move_ee_path([D.to_world([a_c, W + 0.15, n_e + 0.03])], R.eef_mat, step_len=0.03, max_steps=60)
    return res


USE_BIN = False  # 실험: 문 안쪽 수납칸 걸어 당기기 (dev에서 손가락이 칸 안으로 못 들어가 효과 없음)


def door_bins(D):
    """문 안쪽 면의 수납칸(bin) 앞벽: n 방향으로 얇고 r 방향으로 긴 판. 반환 [(top_z, a_top, r_lo, r_hi, n_wall_max)]."""
    m, d = D.w.sim.model, D.w.sim.data
    anc, B = D.frame()
    out = []
    for g in D.panel_geoms:
        P = (_geom_corners(m, d, g) - anc) @ B
        lo, hi = P.min(0), P.max(0)
        if hi[2] - lo[2] > 0.016 or hi[2] > D.n_in_main - 0.02 or (hi[1] - lo[1]) < 0.4 * D.r_max:
            continue
        if hi[0] - lo[0] < 0.03:
            continue
        Pw = _geom_corners(m, d, g)
        top_z = Pw[:, 2].max()
        a_top = D.a_of_z(top_z)
        out.append((float(top_z), float(a_top), float(lo[1]), float(hi[1]), float(hi[2])))
    return out


def close_phase1_bin(w, D):
    """냉장고 문 안쪽 수납칸 앞벽 뒤(문 쪽)에 손가락을 위에서 넣어 로봇 쪽(-n)으로 당긴다.
    로봇은 문 안쪽에 있으므로 팔이 문 경로를 막지 않고 base 이동도 필요 없다."""
    R = w.R
    allb = door_bins(D)
    # 위에 다른 칸이 있으면 손이 못 들어감 -> 도달 가능한 높이에서 가장 위 칸
    bins = [b for b in allb if 0.75 <= b[0] <= 1.6 and not any(o[0] > b[0] + 0.02 for o in allb)]
    if not bins:
        return None
    bins.sort(key=lambda b: -b[0])
    top_z, a_top, r_lo, r_hi, n_w = bins[0]
    r_h = r_hi - 0.07
    n_cav = 0.5 * (n_w + D.n_in_main)
    down = np.array([0, 0, -1.0])

    def mat(q):
        return mat_from(down, D.frame(q)[1][:, 1])

    M0 = flip_x_near(mat(D.q), R.eef_mat[:, 0])
    flip = np.dot(M0[:, 0], mat(D.q)[:, 0]) < 0
    matf = (lambda q: mat(q) @ np.diag([-1.0, -1.0, 1.0])) if flip else mat
    a_in = D.a_of_z(top_z - 0.022)  # 손가락 끝을 벽 윗면 2.2cm 아래까지 (손바닥은 벽 위)
    a_up = D.a_of_z(top_z + 0.10)
    R.gripper(True, n=4)
    move_path(w, [D.to_world([a_up, r_h, n_cav])], M0, step=0.04, max_steps=200)
    move_path(w, [D.to_world([a_in, r_h, n_cav])], M0, step=0.015, max_steps=80)
    dbg(f"bin hook top_z={top_z:.2f} r={r_h:.2f} n_w={n_w:.3f} cav={n_cav:.3f} eef_loc={np.round(D.to_local(R.eef_pos), 3)}")
    loc = np.array([a_in, r_h, n_w - 0.011 - 0.015])  # 벽 안쪽면(문 쪽)을 -n으로 당김
    best, t_best, res = D.frac, 0, "stall"
    for t in range(450):
        if D.frac <= PHASE2_FRAC:
            res = "done"
            break
        qt = D.q - D.sgn * 0.10
        R.step(arm=R.arm_cmd(D.to_world(loc, qt), matf(qt), max_dpos=0.6), grip=1.0)
        if D.frac < best - 0.004:
            best, t_best = D.frac, t
        elif t - t_best > 50:
            break
    R.log("close_door", f"{D.joint}: phase1-bin {res} frac={D.frac:.3f}")
    dbg(f"phase1-bin res={res} frac={D.frac:.3f} eef_loc={np.round(D.to_local(R.eef_pos), 3)}")
    R.move_ee_path([R.eef_pos + np.array([0, 0, 0.12])], R.eef_mat, step_len=0.02, max_steps=50)
    return res


def close_phase1(w, D):
    """바깥면이 로봇 반대쪽을 향할 만큼 열린 문을 PHASE2_FRAC 까지 민다."""
    R = w.R
    route = phase1_route(w, D)
    W = D.r_max
    dbg(f"phase1 {D.joint} route={route} W={W:.2f} base_in_door={np.round(base_in_door2d(w, D), 2)} frac={D.frac:.3f}")
    if route == "around":
        if USE_BIN and D.frac > PHASE2_FRAC + 0.03 and not getattr(D, "_bin_tried", False):
            D._bin_tried = True
            res = close_phase1_bin(w, D)
            if res is not None and D.frac <= PHASE2_FRAC + 0.08:
                return res
        return close_phase1_edge(w, D)
    M = push_mat(w, D, route)
    R.gripper(True, n=4)
    zb, zt = D.z_rng
    z_want = zb + 0.06 if route == "under" else zt - 0.06
    tgt = push_target(w, D, z_want)
    route_to_outer(w, D, M, tgt, route)
    return sweep_close(w, D, M, tgt, PHASE2_FRAC, f"phase1-{route}")


def close_phase2(w, D, th):
    R = w.R
    zb, zt = D.z_rng
    tgt = push_target(w, D, 1.05 if zb < 1.0 else zb + 0.08)
    if D.bar is not None and (D.h_hi[2] - D.n_out) > 0.03:
        # 많이 튀어나온 손잡이(냉장고)는 밀다가 옆으로 미끄러짐 -> 힌지와 손잡이 사이 판을 민다
        tgt = (tgt[0], float(max(D.h_lo[1] - 0.065, 0.35 * D.r_max)), D.n_out)
    # 닫힘 끝 접촉점이 닿는 base 위치인지
    pts = [D.to_world([tgt[0], tgt[1], tgt[2] + 0.10], D.q_at(f))[:2] for f in (min(D.frac, PHASE2_FRAC + 0.05), 0.0)]
    dist = max(np.linalg.norm(p - R.base_pos[:2]) for p in pts)
    if dist > REACH_OK:
        goto_base(w, D, min(tgt[1], 0.45) + 0.05, 0.72, "phase2")
    M = push_mat(w, D, "front")
    R.gripper(True, n=4)
    route_to_outer(w, D, M, tgt, "front")
    res = sweep_close(w, D, M, tgt, th, "phase2")
    hold(w, 4)
    retreat_from(w, D, +1, 0.10)
    return res


def close_vertical(w, D, th):
    if D.frac > PHASE2_FRAC + 0.03:
        res1 = close_phase1(w, D)
        if D.frac > PHASE2_FRAC + 0.08 and D.frac <= 0.75:
            # 일부만 닫힌 경우: 바깥면이 어느 정도 로봇 쪽을 보므로 앞에서 밀기로 이어간다
            w.R.log("close_door", f"{D.joint}: phase1 partial {D.frac:.3f} -> phase2")
        elif D.frac > PHASE2_FRAC + 0.08:
            retreat_from(w, D, +1, 0.08)
            raise SkillFailure("phase1_" + res1, f"{D.joint.split('_group_')[-1]}: frac={D.frac:.3f}")
    res = close_phase2(w, D, th)
    if D.frac > th:
        raise SkillFailure("not_closed" if res != "stall" else "stall",
                           f"{D.joint.split('_group_')[-1]}: phase2 {res} frac={D.frac:.3f}")


def route_to_outer(w, D, M, tgt, route):
    """수직 힌지 문 바깥쪽(접촉 직전)으로 eef 이동."""
    R = w.R
    a_c, rho, n_face = tgt
    h = face_offset(D, M, D.q, +1)
    n_c = n_face + h + 0.015
    cur = D.to_local(R.eef_pos)
    nh = max(n_c, (D.h_hi[2] + h + 0.03) if D.bar is not None else n_c)
    if route == "front":
        move_path(w, [D.to_world([a_c, rho, nh + 0.05])], M, step=0.04, max_steps=200)
        move_path(w, [D.to_world([a_c, rho, n_c])], M, step=0.02, max_steps=100)
        return
    if route in ("under", "over"):
        zb, zt = D.z_rng
        z_pass = zb - 0.07 if route == "under" else zt + 0.07
        a_pass = D.a_of_z(z_pass)
        n_side = min(cur[2], D.n_in - 0.12)
        pts = [D.to_world([a_pass, rho, n_side]), D.to_world([a_pass, rho, nh + 0.02]),
               D.to_world([a_c, rho, nh + 0.02]), D.to_world([a_c, rho, n_c])]
        move_path(w, pts, M, step=0.04, max_steps=350)
        return
    # around: 자유 끝 너머로 돌아 바깥쪽으로 (손잡이는 위로 넘어감)
    r_out = D.r_max + 0.12
    pts = [D.to_world([a_c, r_out, min(cur[2], D.n_in - 0.05)]), D.to_world([a_c, r_out, nh]),
           D.to_world([a_c, rho, nh]), D.to_world([a_c, rho, n_c])]
    move_path(w, pts, M, step=0.03, max_steps=350)
    dbg(f"around reached eef_loc={np.round(D.to_local(R.eef_pos), 3)} want={np.round([a_c, rho, n_c], 3)}")


def open_push_vertical(w, D, f_goal):
    """잡고 당겨 일부 연 문을 안쪽 면에서 밀어 끝까지 연다."""
    R = w.R
    M = push_mat(w, D, "front")
    R.gripper(True, n=4)
    cur = D.to_local(R.eef_pos)
    a_p = cur[0]
    rho = D.r_max - 0.07
    h = face_offset(D, M, D.q, -1)
    n_c = D.n_in - h - 0.015
    r_out = D.r_max + 0.12
    nh = max(cur[2], D.n_out + 0.08)
    pts = [D.to_world([a_p, r_out, nh]), D.to_world([a_p, r_out, n_c - 0.03]), D.to_world([a_p, rho, n_c])]
    move_path(w, pts, M, step=0.03, max_steps=300)
    loc_fn = lambda qt: np.array([a_p, rho, D.n_in - face_offset(D, M, qt, -1) + 0.01])
    res = push_sweep(w, D, loc_fn, D.q_open + D.sgn * 0.15, M, done_fn=lambda: D.frac >= f_goal)
    hold(w, 4)
    retreat_from(w, D, -1, 0.08)
    return res


def open_push_horizontal(w, D, f_goal):
    """drop-down 문: 위에서 안쪽 면을 눌러 끝까지 연다."""
    R = w.R
    _, B0 = D.frame(D.q_close)
    M = flip_x_near(mat_from(np.array([0, 0, -1.0]), B0[:, 0]), R.eef_mat[:, 0])
    R.gripper(True, n=4)
    cur = D.to_local(R.eef_pos)
    rho = D.r_max - 0.06
    h = face_offset(D, M, D.q, -1)
    n_c = D.n_in - h - 0.015
    r_out = D.r_max + 0.10
    pts = [D.to_world([0.0, r_out, max(cur[2], D.n_out + 0.06)]), D.to_world([0.0, r_out, n_c - 0.04]),
           D.to_world([0.0, rho, n_c])]
    move_path(w, pts, M, step=0.03, max_steps=300)
    loc_fn = lambda qt: np.array([0.0, rho, D.n_in - face_offset(D, M, qt, -1) + 0.01])
    res = push_sweep(w, D, loc_fn, D.q_open + D.sgn * 0.15, M, done_fn=lambda: D.frac >= f_goal)
    hold(w, 4)
    retreat_from(w, D, -1, 0.08)
    return res


FINGER_PTS = GRIP_PTS[8:]
TIP_LEAD = float(os.environ.get('TIP_LEAD', 0.05))
TIP_PRESS = float(os.environ.get('TIP_PRESS', 0.03))


def finger_support(M, u):
    ul = M.T @ np.asarray(u, float)
    return float((FINGER_PTS @ ul).max())


def pad_lift(w, D, th, theta=np.radians(35)):
    """drop-down 문 끝 단면을 바깥 손가락 패드(마찰 2.0)로 눌러 잡고 들어올림.
    gripper를 세로(아래 방향)에서 theta 만큼 기울여 바깥 손가락은 문 끝 바깥 아래에, 안쪽 손가락은 문 윗면 위에 오게 한 뒤
    손가락을 닫으면 바깥 패드가 단면을 힌지 쪽으로 누른다. 그 상태로 문 frame에 붙여 회전시킨다."""
    R = w.R
    c, s_ = np.cos(theta), np.sin(theta)
    x_loc = np.array([0.0, c, s_])  # 문 끝 쪽 + 아래(n)
    z_loc = np.array([0.0, -s_, c])
    M_loc = np.stack([x_loc, np.cross(z_loc, x_loc), z_loc], 1)
    q0 = D.q
    B = D.frame(q0)[1]
    M = B @ M_loc
    thick = max(0.008, D.n_out - D.n_in_main)
    P = np.array([0.0, D.r_max + 0.008, D.n_in_main + 0.5 * thick])
    eef_loc = P - 0.040 * x_loc + 0.004 * z_loc
    R.gripper(False, n=10)
    pre1 = eef_loc + np.array([0, 0.04, -0.08])
    pre2 = eef_loc + np.array([0, 0.03, 0.0])
    move_path(w, [D.to_world(pre1, q0)], M, step=0.04, max_steps=200)
    move_path(w, [D.to_world(pre2, q0), D.to_world(eef_loc, q0)], M, step=0.01, max_steps=80)
    R.gripper(True, n=20)
    dbg(f"pad grasp width={R.gripper_width:.3f} eef_loc={np.round(D.to_local(R.eef_pos), 3)} want={np.round(eef_loc, 3)}")
    gl = D.to_local(R.eef_pos)
    best, t_best = D.frac, 0
    for t in range(400):
        if D.frac <= th:
            break
        qt = D.q - D.sgn * 0.10
        R.step(arm=R.arm_cmd(D.to_world(gl, qt), D.frame(qt)[1] @ M_loc, max_dpos=0.6), grip=1.0)
        if D.frac < best - 0.003:
            best, t_best = D.frac, t
        elif t - t_best > 40:
            break
    hold(w, 3)
    dbg(f"pad lift frac={D.frac:.3f}")
    R.log("close_door", f"{D.joint}: pad-lift frac={D.frac:.3f}")
    return D.frac


def close_horizontal(w, D, th):
    """drop-down 문 닫기.
    1) (거의 수평으로 열린 경우) 손가락을 아래로 세워 문 끝 단면을 힌지 쪽으로 누르면서 호를 따라 위로 쓸어 올림
       (단면 마찰 + 힌지 평면 위쪽 접촉으로 들어올림)
    2) 어느 정도 올라오면 수평 자세로 바깥면을 앞에서 밀어 닫음."""
    R = w.R
    _, B0 = D.frame(D.q_close)
    a0 = B0[:, 0]
    R.gripper(True, n=4)
    if D.frac > 0.6 and abs(D.q - D.q_close) > 1.0:  # 거의 수평으로 누운 문 (토스터 오븐). 식기세척기(35도)는 바로 앞에서 민다
        Mt = flip_x_near(mat_from(np.array([0, 0, -1.0]), a0), R.eef_mat[:, 0])
        up_n = D.n_in_main  # 문 판 윗면(열린 상태에서 위)
        thick = max(0.005, D.n_out - D.n_in_main)
        ftip = 0.012  # eef site → 손가락 끝

        def tip_loc(qt, press, tip_n):
            # 손가락 끝이 단면(tip_n 높이)에, 손가락 옆면이 단면을 press 만큼 누르게
            B = D.frame(qt)[1]
            fs = finger_support(Mt, -B[:, 1])
            p = np.array([0.0, D.r_max + fs - press, tip_n])
            return p + B.T @ np.array([0, 0, ftip])  # eef site는 손가락 끝보다 world 위로 ftip

        for k, depth in enumerate((0.3, 0.6, 0.15)):
            # 단면 높이 안의 깊이 (0=윗면, 1=아랫면). 실패하면 다른 높이로 다시
            tip_n = D.n_in_main + depth * thick
            q0 = D.q
            move_path(w, [D.to_world(tip_loc(q0, -0.05, tip_n) + np.array([0, 0, up_n - 0.10])),
                          D.to_world(tip_loc(q0, -0.03, tip_n))], Mt, step=0.03, max_steps=200)
            move_path(w, [D.to_world(tip_loc(q0, 0.01, tip_n))], Mt, step=0.008, max_steps=40)
            # 단면을 누른 채 위로 끌어 올림 (마찰), 문을 따라 닫히는 쪽으로 closed-loop
            best, t_best = D.frac, 0
            for t in range(220):
                if D.frac <= 0.5:
                    break
                qt = D.q - D.sgn * TIP_LEAD
                tgt = D.to_world(tip_loc(qt, TIP_PRESS, tip_n), qt)
                R.step(arm=R.arm_cmd(tgt, Mt, max_dpos=0.6), grip=1.0)
                if D.frac < best - 0.003:
                    best, t_best = D.frac, t
                elif t - t_best > 40:
                    break
            dbg(f"tip-lift try{k} depth={depth} frac={D.frac:.3f} eef_loc={np.round(D.to_local(R.eef_pos), 3)}")
            if D.frac <= 0.6:
                break
            R.move_ee_path([R.eef_pos + np.array([0, 0, 0.05])], Mt, step_len=0.02, max_steps=30)
        R.log("close_door", f"{D.joint}: tip-lift frac={D.frac:.3f}")
        if D.frac > 0.6:
            retreat_from(w, D, -1, 0.06)
            raise SkillFailure("lift_fail", f"{D.joint.split('_group_')[-1]}: tip lift frac={D.frac:.3f}")
        # 2) 손가락으로 문 끝 모서리(가장 앞쪽 점)를 수평으로 밀어 끝까지 닫음 (손을 떼지 않음)
        fwd = _hflat(-B0[:, 2])
        fs = finger_support(Mt, fwd)
        best, t_best = D.frac, 0
        for t in range(400):
            if D.frac <= th:
                break
            qt = D.q - D.sgn * 0.08
            B = D.frame(qt)[1]
            P = D.to_world([0.0, D.r_max, D.n_out], qt)
            Pin = D.to_world([0.0, D.r_max - 0.012, D.n_out], qt)  # 모서리 안쪽(바깥면 위)
            ztip = max(P[2], Pin[2]) - 0.008
            front = max(np.dot(P, fwd), np.dot(Pin, fwd)) if False else min(np.dot(P, fwd), np.dot(Pin, fwd))
            tgt = P + (front - np.dot(P, fwd)) * fwd
            tgt = tgt - fwd * (fs - 0.02)
            tgt[2] = ztip + ftip
            R.step(arm=R.arm_cmd(tgt, Mt, max_dpos=0.6), grip=1.0)
            if D.frac < best - 0.003:
                best, t_best = D.frac, t
            elif t - t_best > 60:
                break
        hold(w, 4)
        R.log("close_door", f"{D.joint}: tip-push frac={D.frac:.3f}")
        R.move_ee_path([R.eef_pos - 0.08 * fwd + np.array([0, 0, 0.03])], Mt, step_len=0.02, max_steps=40)
        if D.frac <= th:
            return
    M = flip_x_near(mat_from(-B0[:, 2], a0), R.eef_mat[:, 0])
    rho = D.r_max - 0.03
    h = face_offset(D, M, D.q, +1)
    move_path(w, [D.to_world([0.0, rho, D.n_out + h + 0.05]), D.to_world([0.0, rho, D.n_out + h + 0.01])], M,
              step=0.025, max_steps=150)
    loc_fn = lambda qt: np.array([0.0, rho, D.n_out + face_offset(D, M, qt, +1) - 0.01])
    res = push_sweep(w, D, loc_fn, D.q_close - D.sgn * 0.06, M, done_fn=lambda: D.frac <= th)
    hold(w, 4)
    R.log("close_door", f"{D.joint}: push {res} frac={D.frac:.3f}")
    retreat_from(w, D, +1, 0.10)
    if D.frac > th:
        raise SkillFailure("not_closed", f"{D.joint.split('_group_')[-1]}: sweep={res} frac={D.frac:.3f}")


# ---------------------------------------------------------------- skills


def _target_joints(w, fixture, joints=None, compartment="fridge"):
    fx = w.fixture(fixture)
    js = joints or door_joints(fx, compartment)
    if not js:
        raise SkillFailure("pre_no_door", f"{getattr(fx, 'name', fixture)} has no door joint")
    return fx, js


@skill("open_door")
class OpenDoor(Skill):
    """hinge 문 열기. fixture: fixture ref, joints: 특정 door joint (기본: 전부), th: 완료 임계 (task와 동일 0.90)."""

    retries = 1
    PULL_FRAC = 0.40

    def precondition(self, w, fixture, joints=None, compartment="fridge", th=0.90, **kw):
        _target_joints(w, fixture, joints, compartment)

    def content(self, w, fixture, joints=None, compartment="fridge", th=0.90, **kw):
        fx, js = _target_joints(w, fixture, joints, compartment)
        R = w.R
        # 로봇 쪽 문부터 (eef와 가까운 손잡이)
        for j in js:
            D = Door(w, fx, j)
            if D.frac >= th + 0.03:
                continue
            if D.frac < self.PULL_FRAC:
                gl, M_loc = grasp_handle(w, D, deeper=0.005 * self.attempt)
                try:
                    res = pull_open(w, D, gl, M_loc, self.PULL_FRAC)
                except SkillFailure as e:
                    # 충분히 벌어진 뒤 놓친 경우: 안쪽 면 밀기로 이어간다
                    if e.code != "grasp_slip" or D.frac < 0.2:
                        raise
                    res = "slip"
                R.log("open_door", f"{j}: pull {res} frac={D.frac:.3f}")
                release_back(w, D, 0.08)
                if D.frac < 0.15:
                    raise SkillFailure("pull_fail", f"{j.split('_group_')[-1]}: pull {res} frac={D.frac:.3f}")
            if D.horizontal:
                res = open_push_horizontal(w, D, min(1.0, th + 0.06))
            else:
                res = open_push_vertical(w, D, min(1.0, th + 0.06))
            R.log("open_door", f"{j}: push {res} frac={D.frac:.3f}")
            if D.frac < th:
                raise SkillFailure("not_open", f"{j.split('_group_')[-1]}: push {res} frac={D.frac:.3f}")

    def effect(self, w, fixture, joints=None, compartment="fridge", th=0.90, **kw):
        fx, js = _target_joints(w, fixture, joints, compartment)
        return all(Door(w, fx, j).frac >= th for j in js)

    def on_except(self, w, err, **kw):
        w.R.gripper(False, n=6)
        w.R.go_home()
        return True


@skill("close_door")
class CloseDoor(Skill):
    """hinge 문 닫기 (문짝을 밀어서). th: 완료 임계 (task와 동일 0.005)."""

    retries = 1

    def precondition(self, w, fixture, joints=None, compartment="fridge", th=0.005, **kw):
        _target_joints(w, fixture, joints, compartment)

    def content(self, w, fixture, joints=None, compartment="fridge", th=0.005, **kw):
        fx, js = _target_joints(w, fixture, joints, compartment)
        goal = max(th * 0.5, 0.002)
        for j in js:
            D = Door(w, fx, j)
            if D.frac <= goal:
                continue
            if D.horizontal:
                close_horizontal(w, D, goal)
            else:
                close_vertical(w, D, goal)

    def effect(self, w, fixture, joints=None, compartment="fridge", th=0.005, **kw):
        fx, js = _target_joints(w, fixture, joints, compartment)
        return all(Door(w, fx, j).frac <= th for j in js)

    def on_except(self, w, err, **kw):
        w.R.gripper(False, n=4)
        w.R.go_home()
        return True
