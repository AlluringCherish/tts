"""막힌 칸(벽장·냉장고 선반) 안 물체 꺼내기: pick_enclosed.

위가 막혀 top-down 손이 들어가지 않고, 직선 접근은 선반·문틀에 걸리는 곳에서 쓴다.
- 칸(fixture interior region)을 찾고, 칸 안쪽 방향 u(선반 깊이 방향)를 기준으로 잡기 후보를 만든다.
    front : 수평 접근, 손가락 좌우 (좌우 폭 ≤ 6.8 cm)
    pitch : 앞-위에서 비스듬히 (손가락 좌우)
    plane : 앞-위에서 비스듬히, 손가락 축도 앞뒤-위아래 평면 안 (옆으로 누운 원통·막대)
    rim   : 머그·컵 벽 (손잡이 피해서), 손가락 축 = 반지름 방향(기울임 포함)
    handle: 머그 손잡이 (로봇 쪽을 볼 때)
- base 위치(앞뒤·좌우 조금)·torso 높이 문맥 × 잡기 후보를 scratch에서 검사:
  pregrasp IK(충돌 없음) → 직선 접근 → 잡은 물체를 붙인 채 살짝 들기 → 칸 밖으로 빼기 → (현재 자세에서 pregrasp까지 RRT).
  처음으로 전부 통과하는 조합을 실행한다.
- 실행: base·torso 이동 → 실제 상태로 다시 계획 → RRT → 직선 접근 → 잡기 → 들기 → 빼기 → 칸 밖인지·쥐었는지 확인.
"""
import time

import numpy as np

from .. import fx as FX
from ..planner import ArmPlanner
from ..robot import SkillFailure
from ..skill import Skill, skill
from .manip import RIM_CATS

MAX_W = 0.074  # 손가락 사이에 넣을 수 있는 폭 (최대 벌림 ~0.079, mesh 기준 국소 폭이라 여유를 작게)
Z = np.array([0, 0, 1.0])


def _unit(v):
    v = np.asarray(v, float)
    return v / (np.linalg.norm(v) + 1e-9)


def _rotz(v, ang):
    c, s = np.cos(ang), np.sin(ang)
    return np.array([c * v[0] - s * v[1], s * v[0] + c * v[1], v[2]])


def _mat(f, a):
    """손가락 축 f, 접근 방향 a(= eef z) → eef 회전행렬."""
    a = _unit(a)
    f = _unit(f - np.dot(f, a) * a)
    return np.stack([f, np.cross(a, f), a], axis=1)


def _in_box(p, box, margin=0.0):
    p0, px, py, pz = box
    ex, ey, ez = px - p0, py - p0, pz - p0
    d = np.asarray(p) - p0
    out = []
    for e in (ex, ey, ez):
        L = np.linalg.norm(e)
        if L < 1e-6:
            return False
        out.append((np.dot(d, e) / L, L))
    return all(-margin <= t <= L + margin for t, L in out)


def find_enclosure(w, obj):
    """obj가 들어 있는 fixture interior region: (fixture, region 이름, box). 없으면 None."""
    c = np.mean(w.obj_aabb(obj), axis=0)
    best = None
    for f in w.env.fixtures.values():
        try:
            regs = FX.int_regions(f)
        except Exception:  # noqa: BLE001
            continue
        for k, box in regs.items():
            if np.linalg.norm(box[1] - box[0]) * np.linalg.norm(box[2] - box[0]) < 0.01:
                continue
            if _in_box(c, box, margin=0.03):
                vol = np.linalg.norm(box[1] - box[0]) * np.linalg.norm(box[2] - box[0]) * np.linalg.norm(box[3] - box[0])
                if best is None or vol < best[3]:
                    best = (f, k, box, vol)
    return None if best is None else best[:3]


def enclosure_frame(box):
    """region의 안쪽 방향 u(수평), 앞면 위치 s_front(= u 방향 좌표), 천장 z."""
    p0, px, py, pz = box
    u = _unit(np.r_[(py - p0)[:2], 0.0])
    s_front = min(np.dot(p0, u), np.dot(px, u))
    return u, s_front, pz[2]


def obj_outside(w, obj, box, margin=0.0):
    """물체 bbox 전체가 칸 앞면보다 바깥(로봇 쪽)이면 True."""
    u, s_front, _ = enclosure_frame(box)
    P = w.obj_bbox(obj)
    return float(np.max(P @ u)) < s_front - margin


# ---------------------------------------------------------------- 머그 기하


def _circle_fit(P):
    """xy 점들의 원 (중심, 반지름) — 최소제곱 (Kasa)."""
    A = np.c_[2 * P[:, 0], 2 * P[:, 1], np.ones(len(P))]
    bb = (P ** 2).sum(1)
    sol = np.linalg.lstsq(A, bb, rcond=None)[0]
    cxy = sol[:2]
    return cxy, float(np.sqrt(max(sol[2] + cxy @ cxy, 1e-6)))


def cup_geometry(w, obj):
    """(축 xy, 안 반지름, 벽 반지름, 윗면 z, 손잡이 방향 또는 None, 손잡이 점 또는 None).
    충돌 mesh 꼭짓점 중 윗 테두리 고리에 원을 맞추고(손잡이 등 벗어난 점은 반복 제거), 그 밖으로 튀어나온 점을 손잡이로 본다."""
    lo, hi = w.obj_aabb(obj)
    V = obj_points(w, obj)
    top = float(V[:, 2].max())
    ring = V[V[:, 2] > top - 0.012][:, :2]
    if len(ring) < 8:
        ring = V[V[:, 2] > top - 0.03][:, :2]
    keep = ring
    cxy, r = _circle_fit(keep)
    for _ in range(4):
        d = np.linalg.norm(keep - cxy, axis=1)
        k2 = keep[np.abs(d - np.median(d)) < 0.012]
        if len(k2) < 6 or len(k2) == len(keep):
            break
        keep = k2
        cxy, r = _circle_fit(keep)
    d = np.linalg.norm(keep - cxy, axis=1)
    r_out = float(np.percentile(d, 90))
    r_in = float(np.percentile(d, 10))
    if r_out - r_in < 0.004:  # 꼭짓점이 바깥 벽에만 있으면 두께를 가정
        r_in = r_out - 0.006
    dall = np.linalg.norm(V[:, :2] - cxy, axis=1)
    H = V[dall > r_out + 0.01]
    hdir, hpt = None, None
    if len(H) >= 3:
        hdir = _unit(np.r_[H[:, :2].mean(0) - cxy, 0.0])
        proj = (H[:, :2] - cxy) @ hdir[:2]
        far = float(proj.max())
        bar = H[proj > far - 0.012]
        hz = (bar[:, 2].min() + bar[:, 2].max()) / 2
        hpt = np.r_[cxy + hdir[:2] * (far - 0.006), hz]
    return cxy, r_in, (r_in + r_out) / 2, top, hdir, hpt


# ---------------------------------------------------------------- 잡기 후보


def grasp_candidates(w, obj, box):
    """[(이름, g, mat, pre_d)] 선호 순."""
    u, s_front, ceil_z = enclosure_frame(box)
    lo, hi = w.obj_aabb(obj)
    c = (lo + hi) / 2
    P = w.obj_bbox(obj)
    height = hi[2] - lo[2]
    floor = w.floor_below(c[:2], lo[2] + 0.02, ignore_objs=(obj,))
    out = []
    hollow = any(k in w.obj_cat(obj) for k in RIM_CATS)
    hs = sorted(w.obj_half_size(obj)[:2])
    if hollow and 2 * hs[0] > MAX_W:
        axis, r_in, r_w, top, hdir, hpt = cup_geometry(w, obj)
        gz = top - 0.022
        # 벽 위치: 로봇 쪽(-u)부터 좌우로, 손잡이 근처는 뺀다
        for th in (0, 30, -30, 60, -60, 90, -90, 120, -120):
            r = _rotz(-u, np.radians(th))
            if hdir is not None and np.dot(r[:2], hdir[:2]) > np.cos(np.radians(40)):
                continue
            g = np.r_[axis + r[:2] * r_w, gz]
            for p in (40, 25, 55, 10):
                pr = np.radians(p)
                f = np.cos(pr) * r - np.sin(pr) * Z
                a0 = -np.cos(pr) * Z - np.sin(pr) * r
                b = np.cross(f, a0)
                for q in (0, 30, -30, 55, -55):
                    qr = np.radians(q)
                    a = np.cos(qr) * a0 + np.sin(qr) * b
                    if np.dot(a, u) < 0.15:  # 손이 로봇 쪽(칸 앞)에서 들어와야 한다
                        continue
                    out.append((f"rim{th}_p{p}_q{q}", g, _mat(f, a), 0.08, 0.078))
        if hdir is not None and np.dot(hdir[:2], -u[:2]) > 0.3:
            s = np.cross(Z, hdir)
            for p in (0, 25, 45):
                pr = np.radians(p)
                a = -np.cos(pr) * hdir - np.sin(pr) * Z
                for yaw in (0,):
                    out.append((f"handle_p{p}", hpt, _mat(s, a), 0.08, 0.05))
        return out
    # 일반 물체: 충돌 mesh 꼭짓점으로 손가락 사이에 들어갈 국소 폭을 잰다
    V = obj_points(w, obj)
    yaws = [0.0, 15.0, -15.0, 30.0, -30.0, 45.0, -45.0]
    M = w.obj_mat(obj)
    for i in range(3):  # 물체 축 방향으로 접근 (대각선으로 놓인 막대 끝에서 잡기)
        e = np.r_[M[:2, i], 0.0]
        if np.linalg.norm(e) < 0.5:
            continue
        e = _unit(e)
        for sg in (1, -1):
            ang = np.degrees(np.arctan2(np.cross(u, sg * e)[2], np.dot(u, sg * e)))
            if abs(ang) < 60 and min(abs(ang - y) for y in yaws) > 5:
                yaws.append(float(round(ang)))
    ext = [(float(np.ptp(V @ _unit(np.r_[M[:2, i], 0.0]))), i) for i in range(3) if np.linalg.norm(M[:2, i]) > 0.5]
    centers = [np.r_[c[:2]]]
    if ext:
        L, i = max(ext)
        if L > 0.09:
            e = _unit(np.r_[M[:2, i], 0.0])
            centers += [c[:2] + e[:2] * L * 0.28, c[:2] - e[:2] * L * 0.28]
    # 길쭉한 물체(막대·오이 등): 손가락 축(수평 성분)이 긴 축과 거의 수직일 때만 (비스듬히 잡으면 미끄러진다)
    e_long, elong = None, False
    if ext:
        L, i = max(ext)
        Ws = min(e for e, _ in ext)
        if L > 1.6 * Ws:
            e_long, elong = _unit(np.r_[M[:2, i], 0.0]), True
    for yaw in yaws:
        uy = _rotz(u, np.radians(yaw))
        lat = np.cross(Z, uy)
        fams = [("front", uy, lat, None)]
        for p in (60, 45, 30):
            pr = np.radians(p)
            fams.append((f"pitch{p}", np.sin(pr) * uy - np.cos(pr) * Z, lat, None))
        for p in (30, 45, 15):
            pr = np.radians(p)
            fams.append((f"plane{p}", np.sin(pr) * uy - np.cos(pr) * Z, np.cos(pr) * uy + np.sin(pr) * Z, pr))
        for ci, cxy in enumerate(centers):
            for fam, a, f, pr in fams:
                if elong:
                    fh = np.r_[f[:2], 0.0]
                    if np.linalg.norm(fh) > 0.5 and abs(np.dot(_unit(fh), e_long)) > 0.5:
                        continue
                zs = [c[2], lo[2] + 0.65 * height] if pr is None else [c[2] + 0.15 * height]
                for zi, z in enumerate(zs):
                    gz = float(np.clip(z, floor + 0.02, hi[2] - 0.008))
                    g = np.r_[cxy, gz]
                    wl, cnt = local_width(V, g, a, f)
                    if cnt == 0 or wl > MAX_W:
                        continue
                    W = float(min(0.079, wl + 0.014))
                    if pr is not None:  # 아래쪽 손가락이 선반에 닿지 않을 높이
                        need = floor + np.sin(pr) * W / 2 + 0.012
                        if need > hi[2] - 0.005:
                            continue
                        g = np.r_[cxy, max(gz, need)]
                        wl, cnt = local_width(V, g, a, f)
                        if cnt == 0 or wl > MAX_W:
                            continue
                        W = float(min(0.078, wl + 0.02))
                    out.append((f"{fam}_y{int(yaw)}_c{ci}_z{zi}", g, _mat(f, a), 0.08, W,
                                (0 if fam == "front" else 1 if fam.startswith("pitch") else 2) + 0.5 * ci + 0.3 * zi + abs(yaw) / 40))
    out.sort(key=lambda x: x[5])
    return [x[:5] for x in out]


def long_axis(w, obj):
    """수평으로 길쭉한 물체면 (긴 축 수평 단위벡터, 길이, 폭), 아니면 None."""
    V = obj_points(w, obj)
    M = w.obj_mat(obj)
    ext = []
    for i in range(3):
        if np.linalg.norm(M[:2, i]) > 0.5:
            e = _unit(np.r_[M[:2, i], 0.0])
            ext.append((float(np.ptp(V @ e)), e))
    if len(ext) < 2:
        return None
    ext.sort(key=lambda x: x[0])
    if ext[-1][0] > 1.6 * ext[0][0] and ext[-1][0] > 0.09:
        return ext[-1][1], ext[-1][0], ext[0][0]
    return None


def obj_points(w, obj):
    """물체 충돌 geom(mesh면 꼭짓점, 아니면 bbox 꼭짓점)의 world 점들."""
    m, d = w.sim.model, w.sim.data
    pts = []
    for g in w.body_geoms(obj, collide_only=True):
        M = d.geom_xmat[g].reshape(3, 3)
        if m.geom_type[g] == 7:
            mid = m.geom_dataid[g]
            a, n = m.mesh_vertadr[mid], m.mesh_vertnum[mid]
            pts.append(d.geom_xpos[g] + m.mesh_vert[a:a + n] @ M.T)
        else:
            c, h = m.geom_aabb[g][:3], m.geom_aabb[g][3:]
            corners = np.array([[sx, sy, sz] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]) * h + c
            pts.append(d.geom_xpos[g] + corners @ M.T)
    if not pts:
        return w.obj_bbox(obj)
    return np.concatenate(pts)


def local_width(V, g, a, f, pad=0.012, back=0.045, front=0.012):
    """손가락이 지나가는 판(손가락 축 f, 접근 a 기준) 안의 물체 점들의 f 방향 폭과 개수."""
    n = np.cross(a, f)
    D = V - g
    ta, tn, tf = D @ a, D @ n, D @ f
    sel = (np.abs(tn) < pad) & (ta > -back) & (ta < front)
    if not np.any(sel):
        return 1.0, 0
    tf = tf[sel]
    return float(max(tf.max(), 0) - min(tf.min(), 0)), int(sel.sum())


# ---------------------------------------------------------------- skill


def set_width(R, W, tol=0.006):
    """손가락 벌림 폭을 W 근처로 (명령은 한 step에 10%씩 바뀌는 증분식). 이후 grip=0으로 유지."""
    R.gripper(False, n=10)
    for _ in range(12):
        if R.gripper_width <= W + tol:
            break
        R.step(arm=R.arm_cmd(R.eef_pos), grip=1.0)
        R.idle(2, arm=R.arm_cmd(R.eef_pos), grip=0.0)
    R.idle(4, arm=R.arm_cmd(R.eef_pos), grip=0.0)


@skill("pick_enclosed")
class PickEnclosed(Skill):
    """막힌 칸 안의 obj를 잡아 칸 밖으로 꺼낸다 (경로 계획 + base·torso 위치 탐색)."""

    retries = 1
    time_budget = 120.0  # 계획 탐색 시간 상한(초, wall)

    def precondition(self, w, obj, **kw):
        if obj not in w.env.objects:
            raise SkillFailure("pre_unknown_obj", obj)
        enc = find_enclosure(w, obj)
        if enc is None:
            raise SkillFailure("pre_not_enclosed", f"{obj} not inside any fixture interior region")
        self.enc = enc

    # ---------- 계획 ----------
    def contexts(self, w, obj, box):
        """(base xy 또는 None, torso) 후보, 비용 순."""
        R = w.R
        u, s_front, _ = enclosure_frame(box)
        lat = np.cross(Z, u)
        c = np.mean(w.obj_aabb(obj), axis=0)
        ol = float(np.dot(c[:2] - R.base_pos[:2], lat[:2]))
        lats = sorted({0.0, round(float(np.clip(ol, -0.25, 0.25)), 2), round(float(np.clip(ol / 2, -0.25, 0.25)), 2), 0.12, -0.12},
                      key=abs)
        deps = [0.0, -0.08, 0.06, -0.16]
        t0 = float(np.clip(c[2] - 1.15, 0.0, 0.34))
        tors = sorted({round(t0, 2), round(float(np.clip(t0 + 0.12, 0, 0.34)), 2), round(float(np.clip(t0 - 0.12, 0, 0.34)), 2),
                       round(float(np.clip(t0 + 0.24, 0, 0.34)), 2)}, key=lambda t: abs(t - t0))
        tors = [min(t, 0.33) for t in tors]  # 상한에 붙이면 실제 torso가 조금 못 미친다
        out = []
        for dl in lats:
            for dd in deps:
                for t in tors:
                    cost = abs(dl) + abs(dd) + 0.3 * abs(t - t0) + (0.5 if (dl or dd) else 0.0)
                    if 0 < np.hypot(dl, dd) < 0.04:
                        continue
                    xy = None if (dl == 0 and dd == 0) else R.base_pos[:2] + lat[:2] * dl + u[:2] * dd
                    out.append((cost, xy, t))
        out.sort(key=lambda x: x[0])
        return [(xy, t) for _, xy, t in out]

    def check_grasp(self, P, w, obj, box, cand, q_start, rrt_time=4.0):
        """후보 하나를 scratch 문맥에서 검사. 통과하면 dict(경로들) 반환."""
        name, g, mat, pre_d, W = cand
        P.finger_w = W
        P.sync()
        a = mat[:, 2]
        u, s_front, ceil_z = enclosure_frame(box)
        # 손목(손 뒤쪽)이 칸 천장에 바로 붙는 후보는 IK 전에 버린다
        wrist = g - a * 0.17
        if _in_box(wrist, box, margin=0.0) and wrist[2] > ceil_z - 0.04:
            return self._why("wrist")
        bset = P.subtree(w.body_id(obj))
        pre = g - a * pre_d
        P.detach()
        P.allowed = set()
        qp = P.ik_free(pre, mat, seeds=3)
        if qp is None:
            return self._why("ik_pre")
        appr = P.line(qp, g, mat, step=0.01, allowed_tail=bset, tail=0.035)
        if appr is None:
            return self._why("approach_line")
        qg = appr[-1]
        # 잡은 뒤: 들기 → 칸 밖으로
        lo, hi = w.obj_aabb(obj)
        room = w.ceiling(np.mean([lo, hi], 0)[:2], hi[2] + 0.005, ignore_objs=(obj,)) - hi[2]
        lifts = [float(np.clip(room - 0.02, 0.008, 0.03))]
        if room - 0.05 > 0.05:  # 앞에 다른 물체가 있으면 더 높이 들어 넘긴다
            lifts += [0.05, float(room * 0.5), float(room - 0.05)]
        lat = np.cross(Z, u)
        P.attach(w.body_id(obj), w.env.objects[obj].joints[0], grasp_pos=g, grasp_mat=mat)
        P.allowed = set()
        try:
            Pts = w.obj_bbox(obj)
            d_out = float(np.max(Pts @ u)) - s_front + 0.04
            up = pull = None
            for side in (0.0, 0.08, -0.08):  # 곧장 빼기, 안 되면 옆으로 비켜서 빼기
                for lift in lifts:
                    up = P.line(qg, g + Z * lift, mat, step=0.005, allowed_tail=None)
                    if up is None:
                        continue
                    q = up[-1]
                    pull = []
                    if side:
                        seg = P.line(q, g + Z * lift + lat * side, mat, step=0.01)
                        if seg is None:
                            continue
                        pull, q = seg[:-1], seg[-1]
                    out_pt = g + Z * lift + lat * side - u * max(d_out, 0.05)
                    seg = P.line(q, out_pt, mat, step=0.01)
                    pull = None if seg is None else pull + seg
                    if pull is not None:
                        break
                if up is not None and pull is not None:
                    break
            if up is None or pull is None:
                return self._why("lift" if up is None else "pull_out")
        finally:
            P.detach()
        P.allowed = set()
        P.time_limit = rrt_time
        path = P.plan(q_start, qp, iters=3000)
        P.time_limit = None
        if path is None:
            return self._why("rrt")
        return dict(name=name, g=g, mat=mat, pre=pre, path=path, appr=appr, up=up, pull=pull, lift=lift, W=W)

    def _why(self, k):
        self.why[k] = self.why.get(k, 0) + 1
        return None

    def search(self, w, obj, box, ctxs, cands, t_budget):
        self.why = {}
        R = w.R
        P = ArmPlanner(w, rng=self.attempt)
        for o in w.env.objects:  # 옆 물체는 살짝(1 cm 이내) 밀어도 된다
            if o != obj:
                P.soft |= P.subtree(w.body_id(o))
        t0 = time.time()
        q_start = P.q_now()
        tried = 0
        for xy, torso in ctxs:
            if time.time() - t0 > t_budget:
                break
            P.finger_w = None
            P.set_context(base_xy=xy, torso=torso)
            P.baseline()
            if xy is not None and P.base_in_collision(q_start):
                continue
            if P.in_collision(q_start):
                continue
            for cand in cands:
                if cand[0] in self.failed:
                    continue
                if time.time() - t0 > t_budget:
                    break
                tried += 1
                res = self.check_grasp(P, w, obj, box, cand, q_start)
                if res is not None and (xy is not None or abs(torso - R.torso_q) > 0.02):
                    # base·torso를 옮겨야 하는 계획은 실제 위치 오차(1~2 cm)에도 통하는지 확인 (아슬아슬한 계획 배제)
                    u, _, _ = enclosure_frame(box)
                    lat = np.cross(Z, u)
                    b0 = R.base_pos[:2] if xy is None else np.asarray(xy)
                    ok = 0
                    for dv in (lat[:2] * 0.015, -lat[:2] * 0.015, u[:2] * 0.015, -u[:2] * 0.015):
                        P.finger_w = None
                        P.set_context(base_xy=b0 + dv, torso=torso - 0.006)
                        P.baseline()
                        ok += self.check_grasp(P, w, obj, box, cand, q_start, rrt_time=1.5) is not None
                        if ok >= 3:
                            break
                    P.finger_w = None
                    P.set_context(base_xy=xy, torso=torso)
                    P.baseline()
                    if ok < 3:
                        res = self._why("fragile")
                if res is not None:
                    res.update(base=xy, torso=torso, tried=tried, secs=round(time.time() - t0, 1))
                    return res
        return dict(fail=True, tried=tried, secs=round(time.time() - t0, 1), why=dict(self.why))

    def push_rotate(self, w, obj, box):
        """막대 한쪽 끝의 앞면을 닫은 손끝으로 안쪽(u)으로 6 cm 밀어 수평으로 돌린다. 했으면 True."""
        R = w.R
        u, s_front, _ = enclosure_frame(box)
        lat = np.cross(Z, u)
        e, L, D = long_axis(w, obj)
        lo, hi = w.obj_aabb(obj)
        c = (lo + hi) / 2
        floor = w.floor_below(c[:2], lo[2] + 0.02, ignore_objs=(obj,))
        nrm = np.cross(Z, e)
        if np.dot(nrm, u) < 0:
            nrm = -nrm
        P = ArmPlanner(w, rng=7)
        for o in w.env.objects:
            if o != obj:
                P.soft |= P.subtree(w.body_id(o))
        bset = P.subtree(w.body_id(obj))
        R.gripper(True, n=10)
        P.finger_w = None
        P.set_context()
        P.baseline()
        q0 = P.q_now()
        for k in (1, -1):
            # 끝 부분만 밀어야 돈다 (닫은 손가락 폭 ~4 cm 중 절반만 막대에 걸치게)
            pc = np.r_[(c + k * e * (L / 2 - 0.0) - nrm * (D / 2 + 0.014))[:2], floor + 0.016]
            for pdeg in (45, 60, 30):
                pr = np.radians(pdeg)
                mat = _mat(lat, np.sin(pr) * u - np.cos(pr) * Z)
                pre = pc - u * 0.03 + Z * 0.03
                P.allowed = set()
                qp = P.ik_free(pre, mat, seeds=3)
                if qp is None:
                    continue
                down = P.line(qp, pc, mat, step=0.01)
                if down is None:
                    continue
                P.allowed = bset
                push = P.line(down[-1], pc + u * 0.08, mat, step=0.01)
                P.allowed = set()
                if push is None:
                    continue
                P.time_limit = 4.0
                path = P.plan(q0, qp, iters=2000)
                P.time_limit = None
                if path is None:
                    continue
                self.follow(w, path, grip=1.0, speed=1.0, final_tol=0.01)
                self.follow(w, down[1:], grip=1.0, speed=0.4)
                self.follow(w, push[1:], grip=1.0, speed=0.3)
                R.move_ee_path([R.eef_pos + Z * 0.03, R.eef_pos + Z * 0.03 - u * 0.10], mat, step_len=0.01, max_steps=60)
                R.go_home(max_steps=80)
                return True
        return False

    def follow(self, w, path, grip, speed=0.6, final_tol=0.006):
        """관절 경로를 OSC로 (경유 관절값을 nullspace posture로)."""
        R = w.R
        P = ArmPlanner(w)
        ctrl = R.robot.part_controllers["right"]
        posture0 = np.array(ctrl.initial_joint)
        dense = []
        prev = P.q_now()
        for q in path:  # 관절 공간에서 촘촘히 (먼 경유점 하나면 OSC가 직교 직선으로 가 버린다)
            n = int(np.ceil(np.max(np.abs(np.asarray(q) - prev)) / 0.06))
            dense += [prev + (np.asarray(q) - prev) * t for t in np.linspace(0, 1, max(n, 1) + 1)[1:]]
            prev = np.asarray(q)
        path = dense
        try:
            for k, q in enumerate(path):
                P.sync()
                pos, mat = P.fk(q)
                ctrl.initial_joint = np.array(q)
                last = k == len(path) - 1
                R.move_ee(pos, mat, tol=final_tol if last else 0.012, rot_tol=0.05 if last else 0.12,
                          max_steps=50 if last else 12, grip=grip, speed=speed)
        finally:
            ctrl.initial_joint = posture0

    def content(self, w, obj, **kw):
        R = w.R
        fxt, reg, box = self.enc
        if not hasattr(self, "failed"):
            self.failed = set()
        self.info = dict(fixture=fxt.name, region=reg)
        R.gripper(False, n=6)
        cands = grasp_candidates(w, obj, box)
        if not cands:
            raise SkillFailure("no_candidate", "no grasp family fits the object size")
        ctxs = self.contexts(w, obj, box)
        plan = self.search(w, obj, box, ctxs, cands, self.time_budget)
        if plan.get("fail") and long_axis(w, obj) is not None and getattr(self, "pushes", 0) < 2:
            # 옆으로 누운 막대: 끝을 밀어 돌린 뒤(앞에서 잡을 수 있게) 다시 탐색
            self.pushes = getattr(self, "pushes", 0) + 1
            if self.push_rotate(w, obj, box):
                R.gripper(False, n=6)
                cands = grasp_candidates(w, obj, box)
                plan = self.search(w, obj, box, self.contexts(w, obj, box), cands, self.time_budget)
                self.info.update(pushed=self.pushes)
        self.info.update(tried=plan.get("tried"), secs=plan.get("secs"))
        if plan.get("fail"):
            raise SkillFailure("no_plan", f"no feasible (base, torso, grasp) among {plan['tried']} tried in {plan['secs']}s "
                                          f"{plan.get('why')} pushed={getattr(self, 'pushes', 0)}")
        self.info.update(grasp=plan["name"], base=None if plan["base"] is None else np.round(plan["base"], 2).tolist(),
                         torso=plan["torso"])
        # base·torso 이동 후 실제 상태에서 다시 계획
        if plan["base"] is not None or abs(plan["torso"] - R.torso_q) > 0.02:
            R.go_home(max_steps=80)
            if plan["base"] is not None:
                R.move_base(plan["base"], R.base_yaw, max_steps=400)
            R.set_torso(plan["torso"])
            R.gripper(False, n=3)
            first = [c for c in cands if c[0] == plan["name"]]
            rest = [c for c in cands if c[0] != plan["name"]]
            plan2 = self.search(w, obj, box, [(None, R.torso_q)], first + rest, 40.0)
            if plan2.get("fail"):  # 실제 위치 오차로 안 되면 새 자리에서 다시 전체 탐색
                plan2 = self.search(w, obj, box, self.contexts(w, obj, box), cands, 60.0)
                if not plan2.get("fail") and (plan2["base"] is not None or abs(plan2["torso"] - R.torso_q) > 0.02):
                    if plan2["base"] is not None:
                        R.go_home(max_steps=80)
                        R.move_base(plan2["base"], R.base_yaw, max_steps=400)
                    R.set_torso(plan2["torso"])
                    plan2 = self.search(w, obj, box, [(None, R.torso_q)],
                                        [c for c in cands if c[0] == plan2["name"]] + cands, 30.0)
            if plan2.get("fail"):
                raise SkillFailure("no_plan_after_move", f"replan failed after base/torso move ({plan2['tried']} tried)")
            plan = plan2
            self.info.update(grasp=plan["name"])
        self.cur = plan["name"]
        # 실행: 손가락을 계획한 폭으로 (선반에 닿지 않게)
        set_width(R, plan["W"])
        self.follow(w, plan["path"], grip=0.0, speed=1.0, final_tol=0.008)
        if np.linalg.norm(R.eef_pos - plan["pre"]) > 0.03:
            raise SkillFailure("approach", f"pregrasp not reached ({plan['name']}): err {np.linalg.norm(R.eef_pos - plan['pre']):.3f} {self.info}")
        self.follow(w, plan["appr"][1:], grip=0.0, speed=0.4)
        err = np.linalg.norm(R.eef_pos - plan["g"])
        R.gripper(True, n=14)
        if R.gripper_width < 0.003 and not w.grasped(obj):
            raise SkillFailure("grasp_miss", f"gripper closed on nothing ({plan['name']}, reach err {err:.3f}) {self.info}")
        R.idle(3, arm=R.arm_cmd(R.eef_pos, plan["mat"]), grip=1.0)
        self.follow(w, plan["up"][1:], grip=1.0, speed=0.3)
        self.follow(w, plan["pull"][1:], grip=1.0, speed=0.4)
        if not w.grasped(obj):
            raise SkillFailure("grasp_slip", f"object dropped while pulling out ({plan['name']}, reach err {err:.3f}) {self.info}")
        # 살짝 올리고, 쥔 자세 그대로 천천히 home 위치로 (흔들려 떨어지지 않게)
        R.move_ee_path([R.eef_pos + np.r_[0, 0, 0.03]], plan["mat"], step_len=0.01, grip=1.0)
        # 더 옮기지 않는다: r2에서 home 쪽으로 옮기는 동안(곧은 관절 경로여도) 손가락 끝으로 집은 당근·막대가
        # 관성으로 빠졌다. 칸 밖에서 든 채로 끝내고, 들고 이동은 이동 담당 skill에 맡긴다.
        self.info.update(stow="none")

    def effect(self, w, obj, **kw):
        _, _, box = self.enc
        if not w.grasped(obj):
            raise SkillFailure("not_held", f"object not held after pull-out ({getattr(self, 'cur', '')})")
        if not obj_outside(w, obj, box):
            raise SkillFailure("still_inside", f"object still inside fixture ({getattr(self, 'cur', '')})")
        return True

    def on_except(self, w, err, obj, **kw):
        R = w.R
        if err.code in ("no_plan", "no_candidate", "no_plan_after_move"):
            return False
        if getattr(self, "cur", None):
            self.failed.add(self.cur)
        # 손을 열고 칸 밖으로 뺀 뒤 home
        _, _, box = self.enc
        u, s_front, _ = enclosure_frame(box)
        R.gripper(False, n=8)
        p = R.eef_pos
        if np.dot(p, u) > s_front - 0.12:
            R.move_ee_path([p + np.r_[0, 0, 0.01], p - u * (np.dot(p, u) - s_front + 0.15)], R.eef_mat, step_len=0.01,
                           max_steps=80)
        R.go_home(max_steps=80)
        return True
