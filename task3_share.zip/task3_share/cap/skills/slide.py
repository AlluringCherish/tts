"""prismatic / lid 계열 skill: open_drawer, close_drawer, slide_rack, open_lid, close_lid.

모두 GT joint(anchor/axis/qpos)와 손잡이·rack·head geom 위치로 폐루프 제어한다.
fixture 상태를 바꾸는 cheat API(set_joint_state, slide_rack, set_head_pos ...)는 쓰지 않는다.
"""
import numpy as np

from ..robot import SkillFailure
from ..skill import Skill, skill
from .manip import front_mat, topdown_mat

# ---------------------------------------------------------------- 공통 helper

DEBUG = False
ROOMY = False  # stand_in_front에서 옆이 넓은 자리 우선 (실험: dev에서 오히려 나빠져 끔)
BASE_HALF_W = 0.25  # mobile base 좌우 반폭 (base_pos 기준)
BASE_FRONT = 0.28  # base_pos에서 앞쪽 끝까지


def move_interp(R, pos, mat, n=None, tol=0.02, per_step=6, final_steps=40):
    """위치와 자세를 함께 보간하며 이동 (큰 회전을 한 번에 명령하면 OSC가 관절 한계로 빠지는 것 방지)."""
    import robosuite.utils.transform_utils as T
    p0, q0 = R.eef_pos.copy(), T.mat2quat(R.eef_mat)
    q1 = T.mat2quat(mat)
    ang = np.linalg.norm(T.quat2axisangle(T.mat2quat(mat @ R.eef_mat.T)))
    dist = np.linalg.norm(np.asarray(pos) - p0)
    if n is None:
        n = int(max(3, np.ceil(max(dist / 0.04, ang / 0.12))))
    for k in range(1, n + 1):
        t = k / n
        qk = T.quat_slerp(q0, q1, t)
        R.move_ee(p0 + (np.asarray(pos) - p0) * t, T.quat2mat(qk), tol=tol, rot_tol=0.15, max_steps=per_step)
    return R.move_ee(pos, mat, tol=tol, max_steps=final_steps)


def fmat(R, approach, finger_axis, flip=False):
    """front_mat + 손가락 축 부호를 현재 eef x축과 가깝게 (손목 회전 최소화). flip이면 반대 부호(손목 180° 돌린 자세)."""
    f = np.asarray(finger_axis, float)
    if np.dot(f, R.eef_mat[:, 0]) < 0:
        f = -f
    if flip:
        f = -f
    return front_mat(approach, finger_axis=f)


def _flat(v):
    v = np.array([v[0], v[1], 0.0])
    return v / (np.linalg.norm(v) + 1e-9)


def geom_world_aabb(w, geoms):
    m, d = w.sim.model, w.sim.data
    pts = []
    for g in geoms:
        c, h = m.geom_aabb[g][:3], m.geom_aabb[g][3:]
        Rg, p = d.geom_xmat[g].reshape(3, 3), d.geom_xpos[g]
        for sx in (-1, 1):
            for sy in (-1, 1):
                for sz in (-1, 1):
                    pts.append(p + Rg @ (c + h * np.array([sx, sy, sz])))
    pts = np.array(pts)
    return pts.min(0), pts.max(0)


def collision_geoms(w, body):
    m = w.sim.model
    return [g for g in w.geoms_of_body_tree(body) if m.geom_contype[g] or m.geom_conaffinity[g]]


def body_aabb(w, body):
    return geom_world_aabb(w, collision_geoms(w, body))


def to_base_frame(w, p):
    return w.R.world_to_base(p)


def retreat(w, away, dist=0.10, up=0.0, n=6):
    """gripper 열고 away 방향(수평 단위벡터)으로 dist, 위로 up 만큼 이동."""
    R = w.R
    R.gripper(False, n=n)
    tgt = R.eef_pos + dist * np.asarray(away) + np.array([0, 0, up])
    R.move_ee_path([tgt], R.eef_mat, step_len=0.03, max_steps=60)


def base_side_shift(w, fx_center, lat_axis, keep_off, max_shift=0.6):
    """base를 fixture 옆 방향(lat_axis)으로만 옮겨서 fixture 중심과의 측면 거리를 keep_off로 맞춘다.
    (앞뒤 위치, yaw 유지 - 장애물 없는 줄을 따라 이동). 멀리 있을 때만 다가간다."""
    R = w.R
    rel = R.base_pos[:2] - np.asarray(fx_center)[:2]
    s = float(np.dot(rel, lat_axis[:2]))
    if abs(s) <= keep_off + 0.02:
        return 0.0
    target_s = np.sign(s) * keep_off
    shift = np.clip(target_s - s, -max_shift, max_shift)
    xy = R.base_pos[:2] + shift * lat_axis[:2]
    R.move_base(xy, R.base_yaw)
    return shift


# base footprint (base frame, x 앞 / y 왼쪽): probe 결과 앞 +0.27, 뒤 -0.55, 좌우 ±0.25
FOOT = dict(front=0.28, back=0.56, half_w=0.26)


def _blockers(w, extra_boxes=()):
    """2D 장애물 목록 [(p0, u, v)] : fixture 외곽 (Floor 제외, 바닥에서 떠 있는 상부장 제외)."""
    out = []
    for name, f in w.env.fixtures.items():
        tn = type(f).__name__
        if tn in ("Floor",) or "floor" in name.lower():
            continue
        try:
            p0, px, py, pz = [np.asarray(p) for p in f.get_ext_sites(relative=False)]
        except Exception:  # noqa: BLE001
            continue
        if min(p0[2], pz[2]) > 0.75:  # 상부장 등 (base 높이 위)
            continue
        out.append((p0[:2], (px - p0)[:2], (py - p0)[:2]))
    for lo, hi in extra_boxes:
        out.append((np.asarray(lo)[:2], np.array([hi[0] - lo[0], 0.0]), np.array([0.0, hi[1] - lo[1]])))
    return out


def _in_box(pt, box):
    p0, u, v = box
    d = pt - p0
    a = np.dot(d, u) / max(np.dot(u, u), 1e-9)
    b = np.dot(d, v) / max(np.dot(v, v), 1e-9)
    return 0 <= a <= 1 and 0 <= b <= 1


def footprint_pts(xy, yaw, margin=0.03):
    c, s = np.cos(yaw), np.sin(yaw)
    Rm = np.array([[c, -s], [s, c]])
    xs = np.linspace(-FOOT["back"] - margin, FOOT["front"] + margin, 9)
    ys = np.linspace(-FOOT["half_w"] - margin, FOOT["half_w"] + margin, 5)
    return np.array([np.asarray(xy) + Rm @ np.array([x, y]) for x in xs for y in ys])


def base_pose_free(w, xy, yaw, margin=0.03, extra_boxes=(), blockers=None):
    bl = blockers if blockers is not None else _blockers(w, extra_boxes)
    for p in footprint_pts(xy, yaw, margin):
        for b in bl:
            if _in_box(p, b):
                return False
    return True


def path_free(w, a, b, yaw, margin=0.0, extra_boxes=(), n=6):
    bl = _blockers(w, extra_boxes)
    return all(base_pose_free(w, a + (b - a) * t, yaw, margin, blockers=bl) for t in np.linspace(0, 1, n))


def stand_in_front(w, point, front, dist, lat_offsets=(0.0, 0.1, -0.1, 0.2, -0.2, 0.3, -0.3),
                   extra_boxes=(), pref_side=0.0):
    """point(손잡이 등) 정면 front 방향으로 dist 떨어진 곳에 base를 세운다 (yaw = -front 를 바라봄).
    footprint가 fixture와 겹치지 않는 후보 중 측면 오프셋이 작은 것. 경로: 먼저 뒤로(front 방향) 물러난 뒤 옆으로.
    실패하면 None, 성공하면 목표 xy."""
    R = w.R
    front = _flat(front)
    lat = np.cross([0, 0, 1.0], front)[:2]
    yaw = float(np.arctan2(-front[1], -front[0]))
    bl = _blockers(w, extra_boxes)
    # 측면 오프셋이 작은 것 우선, 단 옆이 막혀(벽·키 큰 장) 팔꿈치가 걸릴 자리면 뒤로 미룬다
    def roomy(o):
        xy = np.asarray(point)[:2] + front[:2] * dist + lat * o
        return base_pose_free(w, xy, yaw, 0.18, blockers=bl)
    cands = sorted(lat_offsets, key=lambda o: (0 if (roomy(o) or not ROOMY) else 1,
                                               abs(o) - 0.01 * np.sign(o) * np.sign(pref_side)))
    cur = R.base_pos[:2]
    # 현재 위치의 front 방향 좌표
    for o in cands:
        xy = np.asarray(point)[:2] + front[:2] * dist + lat * o
        if not base_pose_free(w, xy, yaw, 0.03, blockers=bl):
            continue
        # 경유점: 현재 위치에서 front 방향으로 물러나 목표 깊이 줄에 도착 (출발점은 이미 붙어 있을 수 있어 검사 제외)
        depth_cur = np.dot(cur - np.asarray(point)[:2], front[:2])
        via = cur + front[:2] * max(0.0, dist - depth_cur)
        legs = [via, xy] if np.linalg.norm(via - cur) > 0.02 else [xy]
        ok = True
        if len(legs) == 2:
            ok = base_pose_free(w, via, R.base_yaw, 0.0, blockers=bl)
        a = legs[0] if len(legs) == 2 else cur
        if ok:
            for t in np.linspace(0.3 if len(legs) == 1 else 0.0, 1, 6):
                if not base_pose_free(w, a + (xy - a) * t, yaw, 0.0, blockers=bl):
                    ok = False
                    break
        if not ok:
            continue
        for leg in legs:
            R.move_base(leg, R.base_yaw if (leg is via and len(legs) > 1) else yaw)
        if DEBUG:
            print("stand_in_front target", np.round(xy, 3), "yaw", round(yaw, 2), "got", np.round(R.base_pos[:2], 3), round(R.base_yaw, 2), "legs", legs)
        return xy
    return None


def drag(w, direction, dist, mat, done_fn, progress=None, lead=0.035, max_steps=220, stall=15, bias=(0, 0, 0),
         abort_fn=None):
    """eef를 direction(단위벡터)으로 dist 만큼 끌거나 민다 (carrot 추종). 경로선에서 벗어나면 되돌림.
    done_fn() 참이면 종료. progress() 값이 stall step 동안 안 변하면 종료."""
    R = w.R
    d = np.asarray(direction, float)
    d /= np.linalg.norm(d)
    p0 = R.eef_pos.copy()
    hist, ehist = [], []
    for i in range(max_steps):
        if done_fn():
            return True
        if abort_fn is not None and abort_fn():
            return False
        e = R.eef_pos
        s_ = float(np.dot(e - p0, d))
        if s_ >= dist:
            return False
        line = p0 + d * s_
        tgt = line + d * min(lead, dist - s_ + 0.005) + np.asarray(bias)
        R.step(arm=R.arm_cmd(tgt, mat))
        if DEBUG and i % 15 == 0:
            print("drag", i, np.round(R.eef_pos, 3), "s", round(s_, 3), "prog", progress() if progress else None)
        ehist.append(float(np.dot(R.eef_pos - p0, d)))
        if len(ehist) > stall and ehist[-1] - ehist[-1 - stall] < 0.01:
            return False  # 손이 더 못 나감 (팔 한계/막힘)
        if progress is not None:
            hist.append(progress())
            if len(hist) > stall and abs(hist[-1] - hist[-1 - stall]) < 5e-3:
                return False
    return False


def move_base_stall(R, xy, yaw=None, max_steps=200, stall=15, tol=0.015, yaw_tol=0.02):
    """R.move_base와 같은 제어 + 막히면(진행 없음) 중단. 도착하면 True."""
    from ..robot import wrap
    xy = np.asarray(xy, dtype=float)
    yaw = R.base_yaw if yaw is None else yaw
    hist = []
    for i in range(max_steps):
        d = R.base_mat.T @ np.r_[xy - R.base_pos[:2], 0.0]
        dyaw = wrap(yaw - R.base_yaw)
        if np.linalg.norm(d[:2]) < tol and abs(dyaw) < yaw_tol:
            break
        hist.append(np.linalg.norm(d[:2]) + 0.3 * abs(dyaw))
        if len(hist) > stall and hist[-1 - stall] - hist[-1] < 0.004:
            break
        v = 0.15 * d[:2]
        n = np.linalg.norm(v)
        if n > 0.025:
            v *= 0.025 / n
        wv = np.clip(0.15 * dyaw, -0.05, 0.05)
        cmd = [R._base_cmd(v[0], R.BASE_LIN_SLOPE), R._base_cmd(v[1], R.BASE_LIN_SLOPE), R._base_cmd(wv, R.BASE_YAW_SLOPE)]
        R.step(arm=np.zeros(6), base=np.array(cmd), mode=1.0)
    for _ in range(4):
        R.step(arm=np.zeros(6), base=np.zeros(3), mode=1.0)
    return np.linalg.norm(xy - R.base_pos[:2]) < 2 * tol


def base_follow(w, direction, max_dist, done_fn, max_steps=120, speed=0.012):
    """팔은 base 기준 자세 그대로 두고 base를 direction(world 수평)으로 움직인다 (mode=1: 팔 목표가 base와 같이 감).
    갈고리를 건 채 팔 한계를 넘어 더 밀 때 사용. 이동 거리 반환."""
    R = w.R
    d = _flat(direction)
    p0 = R.base_pos[:2].copy()
    hist = []
    for i in range(max_steps):
        moved = float(np.dot(R.base_pos[:2] - p0, d[:2]))
        if done_fn() or moved >= max_dist:
            break
        hist.append(moved)
        if len(hist) > 15 and hist[-1] - hist[-16] < 0.005:
            break
        vb = R.base_mat.T @ (d * speed)
        cmd = [R._base_cmd(vb[0], R.BASE_LIN_SLOPE), R._base_cmd(vb[1], R.BASE_LIN_SLOPE), 0.0]
        R.step(arm=np.zeros(6), base=np.array(cmd), mode=1.0)
    for _ in range(3):
        R.step(arm=np.zeros(6), base=np.zeros(3), mode=1.0)
    return float(np.dot(R.base_pos[:2] - p0, d[:2]))


def base_adjust(w, point, out, d0, origin, max_move=0.4):
    """base를 out 축(fixture 정면) 방향으로만 옮겨 point와의 정면 거리를 d0로 맞춘다.
    앞으로(fixture 쪽) 갈 때는 origin(처음 서 있던 곳, 충돌 없음이 보장된 곳)의 정면 거리까지만."""
    R = w.R
    out = _flat(out)
    d_cur = float(np.dot(R.base_pos[:2] - np.asarray(point)[:2], out[:2]))
    if d0 >= d_cur:
        return base_backoff(w, point, out, d0, max_move)
    d_min = float(np.dot(np.asarray(origin)[:2] - np.asarray(point)[:2], out[:2]))
    tgt_d = max(d0, d_min)
    mv = tgt_d - d_cur  # 음수 = 앞으로
    if mv > -0.03:
        return 0.0
    xy = R.base_pos[:2] + out[:2] * mv
    p0 = R.base_pos[:2].copy()
    move_base_stall(R, xy, R.base_yaw)
    return float(np.dot(R.base_pos[:2] - p0, out[:2]))


def base_backoff(w, point, out, d0, max_move=0.4):
    """base를 out 방향(fixture 정면 바깥)으로만 물러나서 point와의 정면 거리를 d0 이상으로. yaw 유지."""
    R = w.R
    out = _flat(out)
    d_cur = float(np.dot(R.base_pos[:2] - np.asarray(point)[:2], out[:2]))
    mv = min(d0 - d_cur, max_move)
    if mv < 0.03:
        return 0.0
    bl = _blockers(w)
    for f in (1.0, 0.75, 0.5):
        xy = R.base_pos[:2] + out[:2] * mv * f
        if base_pose_free(w, xy, R.base_yaw, 0.02, blockers=bl):
            R.move_base(xy, R.base_yaw)
            return mv * f
    # footprint 검사(보수적)가 막으면: 실제로 움직여 보고 막히면 멈춘다
    p0 = R.base_pos[:2].copy()
    move_base_stall(R, R.base_pos[:2] + out[:2] * min(mv, 0.2))
    return float(np.dot(R.base_pos[:2] - p0, out[:2]))


# ---------------------------------------------------------------- drawer


class _DrawerBase(Skill):
    retries = 1

    def _info(self, w, fixture):
        fx = w.fixture(fixture)
        j = f"{fx.name}_slidejoint"
        anchor, axis = w.joint_anchor_axis(j)
        pull = _flat(-axis)  # qpos 음수 = 열림 = -axis 방향
        hb = f"{fx.name}_door_handle_main"
        geoms = collision_geoms(w, hb)
        lo, hi = geom_world_aabb(w, geoms)
        handle = (lo + hi) / 2
        # 잡을 막대 = pull 방향으로 가장 앞에 있는 geom. 그 geom의 앞뒤 중심에 grip site를 둔다
        fr = []
        for g in geoms:
            glo, ghi = geom_world_aabb(w, [g])
            fr.append((max(np.dot(glo[:2], pull[:2]), np.dot(ghi[:2], pull[:2])), glo, ghi))
        fmax = max(f[0] for f in fr)
        blo, bhi = [f for f in fr if f[0] > fmax - 0.004][0][1:]
        bar_c = (blo + bhi) / 2
        handle = handle + pull * (np.dot(bar_c - handle, pull))
        lat = np.cross([0, 0, 1.0], pull)
        hext = hi - lo
        half_len = abs(np.dot(hext, lat)) / 2  # 손잡이 막대 반길이(측면)
        depth = float(fx.size[1])
        return fx, j, pull, lat, handle, half_len, depth

    def frac(self, w, fixture):
        fx = w.fixture(fixture)
        return float(fx.get_door_state(w.env)["door"])

    def precondition(self, w, fixture, **kw):
        fx = w.fixture(fixture)
        if type(fx).__name__ != "Drawer":
            raise SkillFailure("pre_not_drawer", type(fx).__name__)

    def _reposition(self, w, fixture, travel):
        """서랍 정면, travel(앞으로 더 나올 거리)을 고려한 거리에 선다. 불가하면 옆으로만 다가간다."""
        fx, j, pull, lat, handle, half_len, depth = self._info(w, fixture)
        handle_now = handle
        dist = FOOT["front"] + max(travel + 0.10, 0.25)
        s = float(np.dot(w.R.base_pos[:2] - handle[:2], lat[:2]))
        xy = stand_in_front(w, handle_now, pull, dist, pref_side=s)
        if xy is None:
            # 정면에 설 수 없음(섬/벽): 옆에 선 채로 측면 거리만 맞추고, 가능하면 뒤로 물러나 팔 여유를 만든다
            width = float(fx.size[0])
            keep = width / 2 + BASE_HALF_W + 0.06
            base_side_shift(w, handle, lat, keep)
            base_backoff(w, handle, pull, 0.30 + max(travel, 0.0))
            return False
        return True

    def _grasp_handle(self, w, fixture, grasp=True):
        """정면(pull 반대 방향)으로 접근해서 손잡이 막대를 수직 pinch."""
        R = w.R
        fx, j, pull, lat, handle, half_len, depth = self._info(w, fixture)
        # 로봇에 가까운 쪽으로 손잡이 중심에서 살짝 치우쳐 잡기
        s = np.sign(np.dot(R.base_pos[:2] - handle[:2], lat[:2])) or 1.0
        off = 0.0 * s  # 손잡이 중앙 (끝쪽은 굽은 부분이라 미끄러짐)
        g = handle + lat * off
        mat = fmat(R, -pull, (0, 0, 1), flip=self.attempt % 2 == 1)  # 재시도 때는 손목을 반대로 (관절 한계 회피)
        R.gripper(not grasp, n=4)  # 잡을 때는 벌리고, 밀기만 할 때는 닫은 채로
        pre = g + pull * 0.10
        move_interp(R, pre + np.array([0, 0, 0.03]), mat, tol=0.03)
        R.log(self.name, "near_pre")
        R.move_ee(pre, mat, tol=0.012, max_steps=40)
        R.log(self.name, "pre")
        if np.linalg.norm(pre - R.eef_pos) > 0.04:
            if DEBUG:
                print("pre tgt", np.round(pre, 3), "eef", np.round(R.eef_pos, 3), robot_contacts(w),
                      np.round(w.sim.data.qpos[R.robot._ref_joint_pos_indexes], 2), "base", np.round(R.base_pos, 2))
            raise SkillFailure("approach", f"pregrasp not reached err={np.linalg.norm(pre - R.eef_pos):.3f}")
        tgt = g - pull * 0.005
        R.move_ee(tgt, mat, tol=0.008, max_steps=40, speed=0.6)
        if DEBUG:
            print("handle tgt", np.round(tgt, 3), "eef", np.round(R.eef_pos, 3), "contacts", robot_contacts(w))
        if grasp:
            R.gripper(True, n=12)
        return mat, pull


@skill("open_drawer")
class OpenDrawer(_DrawerBase):
    """서랍 손잡이를 잡고 slide 축(-axis) 방향으로 당긴다. 완료: get_door_state >= 0.95."""

    TARGET = 1.03  # get_door_state 목표 (여유)
    PULL_LEAD = 0.02

    def content(self, w, fixture, **kw):
        R = w.R
        if self.frac(w, fixture) >= 0.97:
            return
        fx, j, *_ = self._info(w, fixture)
        okb = self._reposition(w, fixture, travel=self.TARGET * 0.55 * float(fx.size[1]) + w.joint_q(j))
        R.log(self.name, f"base front={okb} frac={self.frac(w, fixture):.2f}")
        mat, pull = self._grasp_handle(w, fixture, grasp=True)
        R.log(self.name, f"grasped w={R.gripper_width:.3f} frac={self.frac(w, fixture):.2f}")
        fx, j, *_ = self._info(w, fixture)
        lo, hi = w.joint_range(j)
        q_target = max(lo + 0.005, -self.TARGET * 0.55 * float(fx.size[1]))
        dist = max(0.0, (-q_target) - (-w.joint_q(j)))
        q0 = w.joint_q(j)
        start = R.eef_pos.copy()
        def _stop():
            if DEBUG and R.steps % 10 == 0:
                print("pull", R.steps, "eef", np.round(R.eef_pos - start, 3), "q", round(w.joint_q(j), 3),
                      "w", round(R.gripper_width, 4), "zax", np.round(R.eef_mat[:, 2], 2), robot_contacts(w))
                m, d = w.sim.model, w.sim.data
                print("   fx contacts", sorted({(m.geom(c.geom1).name, m.geom(c.geom2).name) for c in d.contact[:d.ncon]
                      if (m.geom(c.geom1).name.startswith(fx.name)) != (m.geom(c.geom2).name.startswith(fx.name))}))
            return w.joint_q(j) <= q_target
        drag(w, pull, dist + 0.02, mat, _stop, progress=lambda: w.joint_q(j), lead=self.PULL_LEAD,
             abort_fn=lambda: np.dot(R.eef_pos - start, pull) - (q0 - w.joint_q(j)) > 0.035)
        moved = q0 - w.joint_q(j)
        if DEBUG:
            m, d = w.sim.model, w.sim.data
            tree = set(w.geoms_of_body_tree(f"{fx.name}_inner_box"))
            print("drawer contacts", sorted({(m.geom(c.geom1).name, m.geom(c.geom2).name) for c in d.contact[:d.ncon]
                                            if (c.geom1 in tree) != (c.geom2 in tree)}))
        R.log(self.name, f"pulled frac={self.frac(w, fixture):.2f} eef_moved={np.linalg.norm(R.eef_pos - start):.3f}")
        R.gripper(False, n=8)
        R.move_ee(R.eef_pos + pull * 0.08, mat, tol=0.02, max_steps=20)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), mat, tol=0.02, max_steps=20)
        if self.frac(w, fixture) < 0.95:
            code = "grasp_slip" if moved < 0.5 * dist else "joint_short"
            raise SkillFailure(code, f"frac={self.frac(w, fixture):.2f} moved={moved:.3f}/{dist:.3f}")

    def effect(self, w, fixture, **kw):
        return self.frac(w, fixture) >= 0.95

    def on_except(self, w, err, fixture, **kw):
        R = w.R
        R.gripper(False, n=6)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=30)
        if err.code == "approach":  # 팔이 꼬인 자세 → 초기 자세로 돌린 뒤 손목을 반대로 해서 재시도
            move_interp(R, R.base_to_world(R.home_b), R.base_mat @ R.home_mat_b, tol=0.03)
        return True


@skill("close_drawer")
class CloseDrawer(_DrawerBase):
    """닫힌 gripper로 서랍 앞판(손잡이)을 slide 축(+axis) 방향으로 민다. 완료: get_door_state <= 0.05."""

    def content(self, w, fixture, **kw):
        R = w.R
        if self.frac(w, fixture) <= 0.02:
            return
        okb = self._reposition(w, fixture, travel=0.0)
        R.log(self.name, f"base front={okb}")
        R.gripper(True, n=6)
        try:
            if not okb:
                raise SkillFailure("approach", "side stance: push handle")
            mat, pull = self._push_panel(w, fixture)
            on_handle = False
            R.log(self.name, "at_panel")
        except SkillFailure:
            # 앞판 아래쪽에 손이 안 닿으면 손잡이를 민다 (뺄 때 위로 먼저 빼서 걸림 방지)
            mat, pull = self._grasp_handle(w, fixture, grasp=False)
            on_handle = True
            R.log(self.name, "at_handle")
        fx, j, *_ = self._info(w, fixture)
        dist = -w.joint_q(j)  # 남은 열린 거리
        drag(w, -pull, dist + 0.04, mat, lambda: w.joint_q(j) >= -0.002, progress=lambda: w.joint_q(j))
        R.log(self.name, f"pushed frac={self.frac(w, fixture):.3f}")
        if DEBUG:
            print("before retreat contacts", robot_contacts(w), "eef", np.round(R.eef_pos, 3), "w", R.gripper_width)
        if on_handle:
            R.move_ee(R.eef_pos + pull * 0.005 + np.array([0, 0, 0.06]), mat, tol=0.01, max_steps=20)
            if DEBUG:
                print("after lift contacts", robot_contacts(w), "frac", self.frac(w, fixture))
        R.move_ee(R.eef_pos + pull * 0.08, mat, tol=0.02, max_steps=20)
        R.log(self.name, f"retreated frac={self.frac(w, fixture):.3f}")
        if self.frac(w, fixture) > 0.05:
            raise SkillFailure("joint_short", f"frac={self.frac(w, fixture):.2f}")

    def _push_panel(self, w, fixture):
        """손잡이 아래 서랍 앞판(평면)에 닫힌 손끝을 댄다 (손잡이를 밀면 뺄 때 걸려서 다시 끌려 나옴)."""
        R = w.R
        fx, j, pull, lat, handle, half_len, depth = self._info(w, fixture)
        dlo, dhi = body_aabb(w, f"{fx.name}_door_main")
        face = max(np.dot(dlo[:2], pull[:2]), np.dot(dhi[:2], pull[:2]))
        zc = max(handle[2] - 0.055, dlo[2] + 0.025)
        p = handle.copy()
        p[:2] = p[:2] + pull[:2] * (face - np.dot(handle[:2], pull[:2]) + 0.002)
        p[2] = zc
        mat = fmat(R, -pull, (0, 0, 1), flip=self.attempt % 2 == 1)
        pre = p + pull * 0.10
        R.move_ee(pre + np.array([0, 0, 0.03]), mat, tol=0.03, max_steps=120)
        R.move_ee(pre, mat, tol=0.012, max_steps=40)
        if np.linalg.norm(pre - R.eef_pos) > 0.04:
            raise SkillFailure("approach", f"pre-push not reached err={np.linalg.norm(pre - R.eef_pos):.3f}")
        R.move_ee(p, mat, tol=0.008, max_steps=40, speed=0.6)
        return mat, pull

    def effect(self, w, fixture, **kw):
        return self.frac(w, fixture) <= 0.05

    def on_except(self, w, err, fixture, **kw):
        R = w.R
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=30)
        if err.code == "approach":
            move_interp(R, R.base_to_world(R.home_b), R.base_mat @ R.home_mat_b, tol=0.03)
        return True


# ---------------------------------------------------------------- rack (dishwasher / toaster oven)


def rack_info(w, fixture, rack):
    fx = w.fixture(fixture)
    j = f"{fx.name}_{rack}_joint"
    anchor, axis = w.joint_anchor_axis(j)
    out = _flat(axis)  # qpos 증가 = 밖으로
    lo_q, hi_q = w.joint_range(j)
    if hi_q <= 0:  # 음수 range면 반대
        out = -out
    body = f"{fx.name}_{rack}"
    geoms = collision_geoms(w, body)
    lo, hi = geom_world_aabb(w, geoms)
    return fx, j, out, body, geoms, lo, hi


def rack_frac(w, j):
    lo, hi = w.joint_range(j)
    q = w.joint_q(j)
    f = (q - lo) / (hi - lo)
    return float(f if hi > 0 else 1 - f)


def front_wall(w, geoms, out):
    """rack 앞벽: out 방향으로 가장 앞에 있는 얇은 geom들의 (앞면 좌표, 윗면 z, 측면 범위)."""
    m, d = w.sim.model, w.sim.data
    best = []
    for g in geoms:
        lo, hi = geom_world_aabb(w, [g])
        front = max(np.dot(lo[:2], out[:2]), np.dot(hi[:2], out[:2]))
        best.append((front, g, lo, hi))
    fmax = max(b[0] for b in best)
    wall = [b for b in best if b[0] > fmax - 0.012]
    lo = np.min([b[2] for b in wall], axis=0)
    hi = np.max([b[3] for b in wall], axis=0)
    return fmax, lo, hi


def rack_wires(w, geoms, out, lat):
    """rack 바닥/세로 철사(slide 방향으로 긴 얇은 geom)의 측면 좌표 목록."""
    xs = []
    for g in geoms:
        lo, hi = geom_world_aabb(w, [g])
        ext = hi - lo
        along = abs(np.dot(ext[:2], out[:2]))
        across = abs(np.dot(ext[:2], lat[:2]))
        if along > 0.15 and across < 0.12:
            c = (lo + hi) / 2
            xs.append((float(np.dot(c[:2], lat[:2])), across / 2))
    return xs


def hook_lateral(w, geoms, out, lat, lat_lo, lat_hi, near, margin=0.05, need=0.035):
    """철사 사이 빈 틈 중 near(로봇 쪽)에 가까운 측면 좌표."""
    wires = rack_wires(w, geoms, out, lat)
    best, bscore = None, 1e9
    for x in np.linspace(lat_lo + margin, lat_hi - margin, 60):
        clear = min([abs(x - c) - h for c, h in wires] + [1.0])
        if clear < need / 2:
            continue
        sc = abs(x - near) - 0.3 * min(clear, 0.03)
        if sc < bscore:
            best, bscore = x, sc
    if best is None:
        best = float(np.clip(near, lat_lo + margin, lat_hi - margin))
    return best


def ceiling_front(w, rack_geoms, wlo, whi, out, fpos, reach=0.12):
    """rack 앞벽 위를 덮는 것(counter·sink·dishwasher 윗판)의 out 방향 가장 바깥 좌표와 바닥 높이."""
    m = w.sim.model
    lat = np.cross([0, 0, 1.0], out)
    l_lo, l_hi = sorted([np.dot(wlo[:2], lat[:2]), np.dot(whi[:2], lat[:2])])
    skip = set(rack_geoms)
    best_f, best_z = -1e9, None
    for g in range(m.ngeom):
        if g in skip or (m.geom_contype[g] == 0 and m.geom_conaffinity[g] == 0):
            continue
        n = m.geom(g).name
        if n.startswith(("gripper0", "robot0", "mobilebase0")):
            continue
        glo, ghi = geom_world_aabb(w, [g])
        if glo[2] < whi[2] + 0.003 or glo[2] > whi[2] + reach:
            continue
        a, b = sorted([np.dot(glo[:2], lat[:2]), np.dot(ghi[:2], lat[:2])])
        if b < l_lo or a > l_hi:
            continue
        f_lo, f_hi = sorted([np.dot(glo[:2], out[:2]), np.dot(ghi[:2], out[:2])])
        if f_hi < fpos - 0.6 or f_lo > fpos + 0.15:
            continue
        if f_hi > best_f:
            best_f, best_z = f_hi, glo[2]
    return best_f, best_z


@skill("slide_rack")
class SlideRack(Skill):
    """닫은 gripper를 기울여(손목은 바깥 위쪽) rack 앞벽에 건다.
    out: 앞벽 안쪽에 손끝을 넣고 slide 축 바깥으로 당김 / in: 앞벽 바깥에서 안으로 민다.
    완료: rack 정규화 위치 >= 0.95 (out) / <= 0.05 (in)."""

    retries = 1
    # rad. 손목을 바깥 위로 기울여 위 counter 모서리·열린 문과의 충돌 회피.
    # out(당기기)은 기울이면 손끝이 앞벽을 타고 올라가므로 작게.
    TILT = {"out": 0.45, "in": 0.3}
    HOOK_DEPTH = 0.035  # 앞벽 윗면 아래로 손끝을 넣는 깊이
    PINCH = True  # out은 앞벽 윗모서리를 집어서 당김
    MAX_STROKES = 3
    WAYPT = 0.10  # 접근 경유점: 걸 지점 위 접근축 방향으로 더 뒤
    BASE_FOLLOW = False
    PUSH_PITCH = 0.3  # 수평 밀기 때 손끝을 살짝 아래로
    PINCH_DEPTH = 0.025
    STANDOFF = {"out": 0.72, "in": 0.45}  # 시작 시 base 중심 ~ 걸 지점 정면 거리

    def precondition(self, w, fixture, rack="rack1", direction="out", **kw):
        fx = w.fixture(fixture)
        if f"{fx.name}_{rack}_joint" not in w.sim.model.joint_names:
            raise SkillFailure("pre_no_rack", rack)
        if direction not in ("out", "in"):
            raise SkillFailure("pre_bad_direction", direction)

    def _done(self, w, j, direction, margin=0.0):
        f = rack_frac(w, j)
        return f >= 0.95 + margin if direction == "out" else f <= 0.05 - margin

    def content(self, w, fixture, rack="rack1", direction="out", **kw):
        R = w.R
        fx, j, out, body, geoms, lo, hi = rack_info(w, fixture, rack)
        if self._done(w, j, direction, 0.02):
            return
        if self.attempt == 0:
            self._origin = R.base_pos[:2].copy()  # 앞으로 다시 다가갈 때 넘지 않을 한계 (처음 서 있던 곳)
        f_start = rack_frac(w, j)
        for stroke in range(self.MAX_STROKES):
            self._stroke(w, fixture, rack, direction, stroke)
            if self._done(w, j, direction):
                break
        if not self._done(w, j, direction):
            moved = abs(rack_frac(w, j) - f_start)
            code = "hook_slip" if moved < 0.15 else "joint_short"
            raise SkillFailure(code, f"frac={rack_frac(w, j):.2f} (start {f_start:.2f})")

    def _stroke(self, w, fixture, rack, direction, stroke):
        """한 번 걸고(또는 집고) 끝까지/막힐 때까지 밀거나 당긴다. 팔이 다 펴져 멈추면 base를 옮겨 다시 한다."""
        R = w.R
        fx, j, out, body, geoms, lo, hi = rack_info(w, fixture, rack)
        lat = np.cross([0, 0, 1.0], out)
        fpos, wlo, whi = front_wall(w, geoms, out)
        lat_lo, lat_hi = sorted([np.dot(wlo[:2], lat[:2]), np.dot(whi[:2], lat[:2])])
        near = np.dot(R.base_pos[:2], lat[:2])
        top = whi[2]
        pinch = direction == "out" and self.PINCH
        if pinch:
            lat_c = float(np.clip(near, lat_lo + 0.05, lat_hi - 0.05))
        else:
            lat_c = hook_lateral(w, geoms, out, lat, lat_lo, lat_hi, near)
        # out(pinch): 앞벽 두께 중심을 위에서 잡음 / in: 닫은 손끝을 앞벽 바깥에 대고 민다
        sgn = 0.0 if pinch else (-1.0 if direction == "out" else 1.0)
        tip = out[:2] * (fpos - 0.002 + sgn * (0.022 if direction == "out" else 0.035)) + lat[:2] * lat_c
        moved_b = base_adjust(w, tip, out, self.STANDOFF[direction], self._origin)
        R.log(self.name, f"stroke{stroke} base_adjust {moved_b:.2f}")
        depth = self.PINCH_DEPTH if pinch else self.HOOK_DEPTH
        # 앞벽이 위를 덮은 판(counter 등) 아래로 들어간 뒤에는 기울인 갈고리가 못 들어가므로 수평으로 밀기.
        # 자세 후보를 차례로 시도: tilt(기울인 갈고리) / horiz(수평, 벽 위쪽) / horiz_low(수평, 벽 가운데·덜 숙임)
        cf, cz = ceiling_front(w, geoms, wlo, whi, out, fpos)
        if direction == "in" and stroke > 0:
            modes = ["horiz", "horiz_low", "tilt"] if fpos - cf < 0.04 else ["tilt", "horiz", "horiz_low"]
        else:
            modes = ["tilt"]
        R.log(self.name, f"stroke{stroke} wall-ceil {fpos - cf:.3f} modes={modes}")
        R.gripper(not pinch, n=4)
        last_err = None
        for mode in modes:
            horizontal = mode != "tilt"
            if horizontal:
                pitch = self.PUSH_PITCH if mode == "horiz" else 0.1
                tilt = np.pi / 2 - pitch
                tip_h = out[:2] * (fpos + 0.004) + lat[:2] * lat_c  # 손끝(grip site +1.2cm)이 앞벽에 닿도록
                gz = max(top - 0.06, wlo[2] + 0.03) if mode == "horiz" else (wlo[2] + top) / 2
                g = np.r_[tip_h, gz]
            else:
                tilt = self.TILT[direction]
                g = np.r_[tip, top - depth]
            z = np.array([0, 0, -np.cos(tilt)]) + (-out) * np.sin(tilt)
            mat = fmat(R, z, out if pinch else lat)
            if horizontal:
                above = g - 0.12 * z
                hi_pt = above + out * 0.05 + np.array([0, 0, 0.05])
            else:
                above = np.r_[tip, top + 0.03] - 0.12 * z
                hi_pt = above - self.WAYPT * z  # 접근축을 따라 바깥 위에서 들어옴 (counter 모서리 회피)
            move_interp(R, hi_pt, mat, tol=0.03)
            R.move_ee(above, mat, tol=0.015, max_steps=60)
            if DEBUG:
                print("above tgt", mode, np.round(above, 3), "eef", np.round(R.eef_pos, 3), robot_contacts(w),
                      np.round(w.sim.data.qpos[R.robot._ref_joint_pos_indexes], 2))
            if np.linalg.norm(above - R.eef_pos) > 0.07:
                last_err = SkillFailure("approach", f"{mode} pre-hook err={np.linalg.norm(above - R.eef_pos):.3f}")
                R.move_ee(R.eef_pos - 0.08 * z + np.array([0, 0, 0.04]), mat, tol=0.02, max_steps=20)
                continue
            if not horizontal:
                R.move_ee(np.r_[tip, top + 0.015], mat, tol=0.01, max_steps=30)
            R.move_ee(g, mat, tol=0.008, max_steps=25)
            R.log(self.name, f"{mode} hooked err={np.round(g - R.eef_pos, 3)} {[c[1] for c in robot_contacts(w)][:3]}")
            if R.eef_pos[2] > min(top - 0.004, g[2] + 0.03):
                last_err = SkillFailure("hook_blocked", f"{mode} tip z {R.eef_pos[2]:.3f} >= wall top {top:.3f}")
                R.move_ee(R.eef_pos - 0.10 * z, mat, tol=0.02, max_steps=20)
                continue
            last_err = None
            break
        if last_err is not None:
            raise last_err
        if pinch:
            R.gripper(True, n=14)
            if R.gripper_width < 0.002:
                raise SkillFailure("grasp_miss", "gripper closed on nothing")
        lo_q, hi_q = w.joint_range(j)
        span = hi_q - lo_q
        f0 = rack_frac(w, j)
        dist = ((1.0 - f0) if direction == "out" else f0) * span + 0.06
        mv = out if direction == "out" else -out
        drag(w, mv, dist, mat, lambda: self._done(w, j, direction, 0.035), progress=lambda: rack_frac(w, j),
             lead=0.025 if pinch else 0.035)
        R.log(self.name, f"slid frac={rack_frac(w, j):.2f}")
        if self.BASE_FOLLOW and direction == "in" and not self._done(w, j, direction):
            # 팔이 다 펴져 멈춤 → 갈고리를 건 채 base를 처음 서 있던 곳까지 앞으로 몰아 더 민다 (실험: 효과 없어 끔)
            room = float(np.dot(R.base_pos[:2] - self._origin, out[:2]))
            if room > 0.03:
                mvd = base_follow(w, -out, room, lambda: self._done(w, j, direction, 0.035))
                R.log(self.name, f"base_follow {mvd:.2f} frac={rack_frac(w, j):.2f}")
        # 손 빼기: 앞벽에서 떨어진 뒤 위로
        if pinch:
            R.gripper(False, n=8)
        R.move_ee(R.eef_pos + sgn * out * 0.015, mat, tol=0.008, max_steps=10)
        R.move_ee(R.eef_pos - 0.10 * z, mat, tol=0.02, max_steps=25)
        if horizontal:
            R.move_ee(R.eef_pos + out * 0.08 + np.array([0, 0, 0.05]), mat, tol=0.02, max_steps=20)
        if abs(rack_frac(w, j) - f0) * span < 0.02:
            raise SkillFailure("hook_slip", f"stroke{stroke} moved {abs(rack_frac(w, j) - f0) * span:.3f}")

    def effect(self, w, fixture, rack="rack1", direction="out", **kw):
        fx = w.fixture(fixture)
        return self._done(w, f"{fx.name}_{rack}_joint", direction)

    def on_except(self, w, err, fixture, **kw):
        R = w.R
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=30)
        return err.code != "approach"


# ---------------------------------------------------------------- hinged lid (stand mixer head)


def robot_contacts(w):
    """robot(gripper/arm) geom과 닿아 있는 다른 geom 이름 목록 (디버그용)."""
    m, d = w.sim.model, w.sim.data
    out = set()
    for i in range(d.ncon):
        c = d.contact[i]
        n1, n2 = m.geom(c.geom1).name, m.geom(c.geom2).name
        r1, r2 = n1.startswith(("gripper0", "robot0", "mobilebase0")), n2.startswith(("gripper0", "robot0", "mobilebase0"))
        if r1 != r2:
            out.add((n1, n2) if r1 else (n2, n1))
    return sorted(out)


def rot_about(u, ang):
    u = np.asarray(u, float) / np.linalg.norm(u)
    K = np.array([[0, -u[2], u[1]], [u[2], 0, -u[0]], [-u[1], u[0], 0]])
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * K @ K


def lid_geometry(w, fixture, part="head"):
    """hinge 기준 닫힌 자세(q=0)로 되돌린 head 형상.
    반환: joint, anchor a, axis u, 앞 방향 f(수평, u에 수직), s_max(앞 끝), h_bot_front(앞쪽 끝 아랫면 높이), h_top(윗면)."""
    fx = w.fixture(fixture)
    j = f"{fx.name}_{part}_joint"
    a, u = w.joint_anchor_axis(j)
    q = w.joint_q(j)
    Rb = rot_about(u, -q)
    geoms = collision_geoms(w, f"{fx.name}_{part}")
    m, d = w.sim.model, w.sim.data
    pts_per = []
    for g in geoms:
        c, h = m.geom_aabb[g][:3], m.geom_aabb[g][3:]
        Rg, p = d.geom_xmat[g].reshape(3, 3), d.geom_xpos[g]
        pts = np.array([p + Rg @ (c + h * np.array([sx, sy, sz])) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
        pts_per.append((Rb @ (pts - a).T).T)  # 닫힌 자세, pivot 원점
    allp = np.concatenate(pts_per)
    cen = allp.mean(0)
    f = cen - np.dot(cen, u) * u
    f[2] = 0
    f /= np.linalg.norm(f)
    s_all = allp @ f
    s_max = s_all.max()
    front = [p for p in pts_per if (p @ f).min() > s_max - 0.05]
    if not front:
        front = [allp]
    fp = np.concatenate(front)
    h_bot = fp[:, 2].min()
    c_u = float(np.mean(fp @ u))  # 앞 끝 부분의 축 방향 중심
    # s = 0.6*s_max 부근 윗면 높이 (close_lid 접촉점; 앞끝은 둥글어서 피함)
    s_c = 0.6 * s_max
    top = [p for p in pts_per if ((p @ f).max() > s_c - 0.02) and ((p @ f).min() < s_c + 0.02)]
    h_top = np.concatenate(top)[:, 2].max() if top else allp[:, 2].max()
    w._lid_pts = (pts_per, f)  # open_lid 접촉점 선택용 (닫힌 자세 geom AABB 꼭짓점)
    return j, a, u, f, float(s_max), float(h_bot), float(h_top), c_u


def open_contact(w, u, f, s_max, h_bot, c_u):
    """open_lid 접촉점 (닫힌 자세, pivot 원점) 선택.
    nose 아래가 비어 있으면 nose 아랫면을 위로 밀고(under), 앞끝 아래로 다른 head 부품(beater hub 등)이
    내려와 있으면 pivot보다 높은 앞면을 hinge 쪽으로 민다(face). 반환: mode, 접근점 P0, 추적점 P1."""
    pts_per, _ = w._lid_pts
    strip = [p for p in pts_per if (p @ f).max() > s_max - 0.035]
    low = min(p[:, 2].min() for p in strip)
    if low >= h_bot - 0.01 and not getattr(w, "_lid_force_face", False):
        P0 = f * (s_max - 0.025) + np.array([0, 0, h_bot - 0.013]) + u * c_u
        return "under", P0, P0
    upper = [p for p in pts_per if p[:, 2].min() > 0.03]
    if not upper:
        upper = pts_per
    best = max(upper, key=lambda p: (p @ f).max())
    s_front = float((best @ f).max())
    h_c = float(np.clip((best[:, 2].min() + best[:, 2].max()) / 2, 0.05, None))
    cu = float(np.mean(best @ u))
    P0 = f * (s_front + 0.006) + np.array([0, 0, h_c]) + u * cu
    P1 = P0 - f * 0.025
    return "face", P0, P1


class _LidBase(Skill):
    retries = 1
    LEAD = 0.18  # rad, 손이 head보다 앞서 갈 수 있는 최대 각도
    DPHI = 0.035  # rad/step

    def precondition(self, w, fixture, part="head", **kw):
        fx = w.fixture(fixture)
        if f"{fx.name}_{part}_joint" not in w.sim.model.joint_names:
            raise SkillFailure("pre_no_joint", part)

    def _frac(self, w, j):
        lo, hi = w.joint_range(j)
        return (w.joint_q(j) - lo) / (hi - lo)

    def _arc(self, w, j, a, u, P0, mat, phi_end, opening, max_steps=160):
        """P0(닫힌 자세 기준 접촉점)을 hinge 축 둘레로 돌리며 head를 밀어 올림/내림."""
        R = w.R
        phi = w.joint_q(j)
        hist = []
        lead = self.LEAD
        for i in range(max_steps):
            q = w.joint_q(j)
            if len(hist) > 10 and abs(q - hist[-10]) < 0.005:
                lead = min(lead + 0.01, 0.6)  # 안 움직이면 (접촉 못 함) 더 앞서 간다
            else:
                lead = max(self.LEAD, lead - 0.01)
            if (opening and q >= phi_end - 0.02) or (not opening and q <= phi_end + 0.005):
                return True
            if opening:
                phi = min(phi + self.DPHI, q + lead, phi_end + 0.05)
            else:
                phi = max(phi - self.DPHI, q - lead, phi_end - 0.05)
            tgt = a + rot_about(u, phi) @ P0
            R.step(arm=R.arm_cmd(tgt, mat, max_dpos=1.0))
            hist.append(q)
            if DEBUG and i % 10 == 0:
                print("arc", i, "q", round(q, 3), "phi", round(phi, 3), "err", np.round(tgt - R.eef_pos, 3),
                      robot_contacts(w), np.round(w.sim.data.qpos[R.robot._ref_joint_pos_indexes], 2))
            if len(hist) > 60 and abs(hist[-1] - hist[-61]) < 0.01:
                return False
        return False

    STANDOFF = 0.65  # base 중심 ~ 접촉점 전방 거리 (너무 가까우면 팔이 접혀 도달 못함)
    PITCH = 0.45  # rad, 접근 방향을 아래로 숙임 (수평이면 joint6 한계)

    def _place_base(self, w, P_world, side_dir, lat):
        """접촉점이 base 전방 STANDOFF, side_dir 쪽으로 -lat 에 오도록 base를 옮긴다 (yaw 유지).
        footprint가 fixture와 겹치면 측면량을 줄이고, 그래도 안 되면 뒤로만 물러난다."""
        R = w.R
        fwd = np.array([np.cos(R.base_yaw), np.sin(R.base_yaw), 0.0])
        sd = _flat(side_dir)
        sd = sd - np.dot(sd, fwd) * fwd
        if np.linalg.norm(sd) > 1e-3:
            sd /= np.linalg.norm(sd)
        bl = _blockers(w)
        for l in (lat, 0.75 * lat, 0.5 * lat, 0.25 * lat):
            xy = np.asarray(P_world)[:2] - fwd[:2] * self.STANDOFF + sd[:2] * l
            if base_pose_free(w, xy, R.base_yaw, 0.02, blockers=bl):
                R.move_base(xy, R.base_yaw)
                return float(l)
        base_backoff(w, P_world, -fwd, self.STANDOFF)
        return None

    def _approach(self, w, P_world, app, mat, back=0.10):
        R = w.R
        pre = P_world - app * back
        R.move_ee(pre + np.array([0, 0, 0.06]), mat, tol=0.02, max_steps=110)
        R.move_ee(pre, mat, tol=0.008, max_steps=50)
        if DEBUG:
            print("pre tgt", np.round(pre, 3), "eef", np.round(R.eef_pos, 3), "contacts", robot_contacts(w))
        if np.linalg.norm(pre - R.eef_pos) > (0.055 if not robot_contacts(w) else 0.025):
            raise SkillFailure("approach", f"pre err={np.linalg.norm(pre - R.eef_pos):.3f}")
        R.move_ee(P_world, mat, tol=0.008, max_steps=40)
        if DEBUG:
            print("contact tgt", np.round(P_world, 3), "eef", np.round(R.eef_pos, 3), "contacts", robot_contacts(w))
        if np.linalg.norm(P_world - R.eef_pos) > (0.04 if not robot_contacts(w) else 0.025):
            raise SkillFailure("approach", f"contact err={np.linalg.norm(P_world - R.eef_pos):.3f}")

    def _retreat(self, w, app, mat, dist=0.10):
        R = w.R
        R.move_ee(R.eef_pos - app * dist, mat, tol=0.02, max_steps=30)


@skill("open_lid")
class OpenLid(_LidBase):
    """닫은 gripper를 head 앞끝(nose) 바깥에서 hinge 쪽으로 (약간 아래로 숙여) 넣어 손가락 윗면을 nose 아래에 대고,
    hinge 둘레 호를 따라 밀어 올린다 (손이 head보다 LEAD 이상 앞서지 않게). 완료: head joint 정규화 > 0.99."""

    PITCH = 0.3
    LAT = 0.15  # base를 nose 바깥쪽으로 옮기는 양

    def content(self, w, fixture, part="head", **kw):
        R = w.R
        j, a, u, f, s_max, h_bot, h_top, c_u = lid_geometry(w, fixture, part)
        if self._frac(w, j) >= 0.995:
            return
        # 접촉점(닫힌 자세, pivot 원점): under = 앞끝 2.5cm 안쪽 nose 아랫면 1.3cm 아래 / face = 위쪽 앞면
        mode, P0, P1 = open_contact(w, u, f, s_max, h_bot, c_u)
        R.log(self.name, f"mode={mode}")
        Pw = a + rot_about(u, w.joint_q(j)) @ P0
        lat = self._place_base(w, Pw, f, self.LAT)
        R.log(self.name, f"base lat={lat}")
        app = -f * np.cos(self.PITCH) - np.array([0, 0, np.sin(self.PITCH)])
        mat = fmat(R, app, u)
        R.gripper(True, n=4)
        try:
            self._approach(w, Pw, app, mat)
        except SkillFailure as e:
            if mode != "under" or e.code != "approach":
                raise
            # nose 아래에 손이 안 들어가면 (beater 등 부품) 앞면 밀기로 전환
            R.log(self.name, "under blocked -> face")
            R.move_ee(R.eef_pos - app * 0.08, mat, tol=0.02, max_steps=20)
            w._lid_force_face = True
            lid_geometry(w, fixture, part)
            mode, P0, P1 = open_contact(w, u, f, s_max, h_bot, c_u)
            Pw = a + rot_about(u, w.joint_q(j)) @ P0
            self._approach(w, Pw, app, mat)
        R.log(self.name, "contact")
        lo, hi = w.joint_range(j)
        self._arc(w, j, a, u, P1, mat, hi, opening=True)
        R.log(self.name, f"arc_done frac={self._frac(w, j):.3f}")
        R.idle(3)
        self._retreat(w, app, mat)
        if self._frac(w, j) < 0.99:
            raise SkillFailure("joint_short", f"frac={self._frac(w, j):.3f}")

    def effect(self, w, fixture, part="head", **kw):
        fx = w.fixture(fixture)
        return self._frac(w, f"{fx.name}_{part}_joint") > 0.99

    def on_except(self, w, err, fixture, **kw):
        R = w.R
        R.move_ee(R.eef_pos + np.array([0, 0, 0.06]), max_steps=25)
        return err.code != "approach"


@skill("close_lid")
class CloseLid(_LidBase):
    """열린 head의 원래 윗면(열린 상태에서는 hinge 뒤쪽을 향함) 앞끝 근처를 뒤쪽에서 닫은 gripper로 밀어
    hinge 둘레 호를 따라 내린다 (넘어가면 중력으로 닫힘). 완료: head joint 정규화 < 0.01."""

    PITCH = 0.3
    LAT = 0.15

    def content(self, w, fixture, part="head", **kw):
        R = w.R
        j, a, u, f, s_max, h_bot, h_top, c_u = lid_geometry(w, fixture, part)
        if self._frac(w, j) <= 0.005:
            return
        # 접촉점(닫힌 자세 기준): s = 0.6*s_max, 그 위치 윗면 위 2.5cm (손끝이 윗면에 닿기 직전)
        # 재시도 때는 뒤쪽이 막힌 경우(전자레인지 등)를 위해 앞끝 가까이를 위에서 비스듬히(pitch 0.9) 누른다
        s_frac, pitch = (0.6, self.PITCH) if self.attempt == 0 else (0.85, 0.9)
        P0 = f * (s_frac * s_max) + np.array([0, 0, h_top + 0.025]) + u * c_u
        q = w.joint_q(j)
        Pw = a + rot_about(u, q) @ P0
        push = _flat(rot_about(u, q) @ np.array([0, 0, -1.0]))  # 윗면을 미는 방향 (열린 상태면 +f 쪽)
        if np.linalg.norm(push) < 0.5:
            push = f
        lat = self._place_base(w, Pw, -push, self.LAT)
        R.log(self.name, f"base lat={lat}")
        app = push * np.cos(pitch) - np.array([0, 0, np.sin(pitch)])
        mat = fmat(R, app, u)
        R.gripper(True, n=4)
        self._approach(w, Pw, app, mat)
        R.log(self.name, "contact")
        lo, hi = w.joint_range(j)
        # 호를 따라갈 점은 윗면 1.5cm 안쪽 (둥근 head 윤곽을 스치고 지나가지 않게 눌러 밀기)
        P1 = P0 - np.array([0, 0, 0.04])
        self._arc(w, j, a, u, P1, mat, lo, opening=False)
        R.log(self.name, f"arc_done frac={self._frac(w, j):.3f}")
        R.idle(5)
        self._retreat(w, app, mat)
        if self._frac(w, j) > 0.01:
            raise SkillFailure("joint_short", f"frac={self._frac(w, j):.3f}")

    def effect(self, w, fixture, part="head", **kw):
        fx = w.fixture(fixture)
        return self._frac(w, f"{fx.name}_{part}_joint") < 0.01

    def on_except(self, w, err, fixture, **kw):
        R = w.R
        R.move_ee(R.eef_pos + np.array([0, 0, 0.06]), max_steps=25)
        return True
