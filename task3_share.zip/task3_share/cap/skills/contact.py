"""접촉이 많은 skill: stir, scrub, pour. (도구를 쥔 상태에서 접촉을 유지하며 움직이는 동작)

이 skill들이 CaP로 얼마나 되는지가 "학습이 필요한 skill" 판정의 핵심 근거라서,
일부러 단순하지만 합리적인 스크립트로 시도한다.
"""
import numpy as np

from ..robot import SkillFailure
from ..skill import Skill, skill
from .manip import HAND_H, _ensure_workspace, obj_touching_env, topdown_mat


def rot_about(axis, ang):
    axis = np.asarray(axis, float) / np.linalg.norm(axis)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * K @ K


def contact_between(w, a, b):
    return w.env.check_contact(w.env.objects[a], w.env.objects[b])


@skill("stir")
class Stir(Skill):
    """쥔 도구(tool)를 그릇(container) 안에 기울여 넣고 원을 그리며 젓는다."""

    retries = 0

    def precondition(self, w, tool, container, **kw):
        if not w.grasped(tool):
            raise SkillFailure("pre_not_holding", tool)
        _ensure_workspace(w, w.obj_pos(container))

    def content(self, w, tool, container, targets=(), tilt=0.8, radius=0.035, n_circles=6, **kw):
        R = w.R
        c = w.obj_pos(container)
        lo, hi = w.obj_aabb(container)
        mat0 = topdown_mat(R.eef_mat[:, 0], ref_x=R.eef_mat[:, 0])
        # 손가락 축을 중심으로 기울여 도구 한쪽 끝을 아래로
        mat = rot_about(mat0[:, 0], tilt) @ mat0
        ceil = w.ceiling(c[:2], hi[2] + 0.05, ignore_objs=(tool, container)) - HAND_H
        travel = min(hi[2] + 0.25, ceil)
        R.move_ee_path([np.r_[R.eef_pos[:2], max(R.eef_pos[2], travel)], np.r_[c[:2], travel]], mat0, step_len=0.03)
        R.move_ee(R.eef_pos, mat, rot_tol=0.05, max_steps=40)
        # 도구 끝이 그릇 안 무언가에 닿을 때까지 내린다
        R.move_ee_path([np.r_[c[:2], lo[2] + 0.02]], mat, step_len=0.006,
                       stop_fn=lambda: obj_touching_env(w, tool) and not contact_between(w, tool, container)
                       or any(contact_between(w, tool, t) for t in targets))
        z = R.eef_pos[2] + 0.005
        self.hits = 0
        self.moved = 0
        prev = {t: w.obj_pos(t) for t in targets}
        # 손(eef)이 아니라 도구 끝이 채소들 사이를 지나가도록: 도구 끝-손 오프셋을 재서 원 중심을 보정
        tip_off = np.zeros(2)
        if targets:
            tlo, thi = w.obj_aabb(tool)
            tip = np.r_[(tlo[:2] + thi[:2]) / 2]
            P = w.obj_bbox(tool)
            tip = P[np.argmin(P[:, 2])][:2]  # 가장 낮은 꼭짓점 = 냄비 안에 들어간 끝
            tip_off = tip - R.eef_pos[:2]
            vc = np.mean([w.obj_pos(t)[:2] for t in targets], axis=0)
            spread = max(np.linalg.norm(w.obj_pos(t)[:2] - vc) for t in targets)
            c = np.r_[vc, c[2]]
            radius = float(np.clip(spread + 0.01, 0.02, 0.06))
        for k in range(n_circles * 16):
            a = 2 * np.pi * k / 16
            p = np.r_[c[:2] - tip_off + radius * np.array([np.cos(a), np.sin(a)]), z]
            R.move_ee(p, mat, tol=0.006, max_steps=6, speed=0.5)
            if any(contact_between(w, tool, t) for t in targets):
                self.hits += 1
            for t in targets:
                q = w.obj_pos(t)
                if np.linalg.norm(q[:2] - prev[t][:2]) > 0.0005:
                    self.moved += 1
                prev[t] = q
            if not w.grasped(tool):
                raise SkillFailure("tool_slip", "tool dropped while stirring")

    def effect(self, w, tool, container, targets=(), **kw):
        if targets and self.hits < 5:
            raise SkillFailure("no_contact", f"tool touched targets only {self.hits} steps (moved {self.moved})")
        return True


@skill("scrub")
class Scrub(Skill):
    """쥔 스펀지를 표면(target 물체) 위에 눌러 대고 지그재그로 문지른다."""

    retries = 0

    def precondition(self, w, tool, target, **kw):
        if not w.grasped(tool):
            raise SkillFailure("pre_not_holding", tool)
        _ensure_workspace(w, w.obj_pos(target))

    def content(self, w, tool, target, length=0.14, width=0.06, passes=4, press=0.015, **kw):
        R = w.R
        lo, hi = w.obj_aabb(target)
        c = (lo + hi) / 2
        mat = topdown_mat(R.eef_mat[:, 0], ref_x=R.eef_mat[:, 0])
        tlo, _ = w.obj_aabb(tool)
        below = R.eef_pos[2] - tlo[2]
        travel = max(R.eef_pos[2], hi[2] + below + 0.08)
        R.move_ee_path([np.r_[R.eef_pos[:2], travel], np.r_[c[:2], travel]], mat, step_len=0.03)
        R.move_ee_path([np.r_[c[:2], hi[2] + below - 0.035]], mat, step_len=0.005,
                       stop_fn=lambda: contact_between(w, tool, target))
        if not contact_between(w, tool, target):
            raise SkillFailure("no_contact", "sponge did not reach the surface")
        z = R.eef_pos[2] - press
        # 표면의 긴 축 방향으로 지그재그
        M = w.obj_mat(target)
        hs = w.obj_half_size(target)
        ax = M[:, int(np.argmax(hs[:2]))]
        ax = np.r_[ax[:2], 0] / np.linalg.norm(ax[:2])
        pe = np.r_[-ax[1], ax[0], 0]
        self.pts = []
        for i in range(passes + 1):
            off = (i / passes - 0.5) * width
            for s in ((-0.5, 0.5) if i % 2 == 0 else (0.5, -0.5)):
                p = np.r_[c[:2], z] + ax * s * length + pe * off
                R.move_ee_path([p], mat, step_len=0.01, max_steps=40, stop_fn=lambda: self._record(w, tool, target))
            if not w.grasped(tool):
                raise SkillFailure("tool_slip", "sponge dropped while scrubbing")

    def _record(self, w, tool, target):
        if contact_between(w, tool, target):
            q = w.obj_pos(tool)[:2].copy()
            if not self.pts or min(np.linalg.norm(q - p) for p in self.pts) >= 0.02:
                self.pts.append(q)
        return False

    def effect(self, w, tool, target, **kw):
        if len(self.pts) < 5:
            raise SkillFailure("no_contact", f"only {len(self.pts)} contact points")
        P = np.array(self.pts)
        if np.linalg.norm(P.max(0) - P.min(0)) < 0.10:
            raise SkillFailure("short_sweep", "sweep < 10 cm")
        return True


@skill("pour")
class Pour(Skill):
    """쥔 용기(손잡이 잡기)를 대상 위로 옮겨 기울여 내용물을 쏟고 다시 세운다."""

    retries = 0

    def precondition(self, w, container, target, **kw):
        if not w.grasped(container):
            raise SkillFailure("pre_not_holding", container)
        _ensure_workspace(w, w.obj_pos(target))

    def content(self, w, container, target, contents=(), angle=2.2, height=0.12, **kw):
        R = w.R
        mat0 = R.eef_mat.copy()
        tc = w.obj_pos(target)
        _, thi = w.obj_aabb(target)
        clo, chi = w.obj_aabb(container)
        cc = w.obj_pos(container)
        # 용기 중심이 대상 위에 오도록 (eef는 손잡이)
        off = (cc - R.eef_pos)[:2]
        exy = tc[:2] - off
        z = thi[2] + (R.eef_pos[2] - clo[2]) + height
        R.move_ee_path([np.r_[R.eef_pos[:2], max(R.eef_pos[2], z)], np.r_[exy, z]], mat0, step_len=0.02, grip=1.0)
        # 손잡이 축(eef→용기 중심)을 중심으로 굴려 기울이기
        axis = np.r_[off, 0.0]
        axis /= np.linalg.norm(axis) + 1e-9
        for k in range(1, 9):
            Rk = rot_about(axis, angle * k / 8) @ mat0
            R.move_ee(np.r_[exy, z], Rk, tol=0.02, rot_tol=0.08, max_steps=15, grip=1.0)
        # 흔들기
        for k in range(3):
            R.move_ee(np.r_[exy, z] + np.r_[axis[:2] * 0.03 * (-1) ** k, 0], tol=0.01, max_steps=8, grip=1.0)
        R.idle(15, arm=np.zeros(6))
        for k in range(7, -1, -1):
            Rk = rot_about(axis, angle * k / 8) @ mat0
            R.move_ee(np.r_[exy, z], Rk, tol=0.02, rot_tol=0.08, max_steps=15, grip=1.0)
        if not w.grasped(container):
            raise SkillFailure("container_slip", "container dropped while pouring")

    def effect(self, w, container, target, contents=(), **kw):
        from robocasa.utils import object_utils as OU

        bad = [c for c in contents if not OU.check_obj_in_receptacle(w.env, c, target)]
        if bad:
            raise SkillFailure("spilled", f"not in {target}: {bad}")
        return True


# ---------------------------------------------------------------- 젓기 v2 (focus3)


def tool_parts(w, tool):
    """도구(주걱 등)의 손잡이 geom, 날 geom: geom bbox의 두 번째로 큰 반폭이 큰 쪽이 날."""
    m = w.sim.model
    geoms = w.body_geoms(tool)
    if len(geoms) < 2:
        return None, None
    width = lambda g: sorted(m.geom_aabb[g][3:])[1]  # noqa: E731
    blade = max(geoms, key=width)
    handle = min(geoms, key=width)
    return handle, blade


def geom_world(w, g):
    return np.array(w.sim.data.geom_xpos[g])


@skill("pick_tool")
class PickTool(Skill):
    """긴 도구를 손잡이 쪽으로 잡는다 (날은 자유롭게). top-down, 손가락 축 = 도구 긴 축에 수직."""

    retries = 2

    def precondition(self, w, tool, **kw):
        from .manip import _ensure_workspace

        _ensure_workspace(w, w.obj_pos(tool))

    def content(self, w, tool, **kw):
        from .manip import topdown_mat

        R = w.R
        handle, blade = tool_parts(w, tool)
        if handle is None:
            raise SkillFailure("pre_no_parts", tool)
        h, b = geom_world(w, handle), geom_world(w, blade)
        long_ax = np.r_[(b - h)[:2], 0.0]
        long_ax /= np.linalg.norm(long_ax) + 1e-9
        f = np.array([-long_ax[1], long_ax[0], 0.0])
        # 손잡이 가운데보다 조금 날 쪽(무게 중심 쪽)을 잡아 덜 돈다
        gxy = h[:2] + (b - h)[:2] * (0.5, 0.35, 0.6)[min(self.attempt, 2)]
        top = w.floor_below(gxy, w.obj_aabb(tool)[1][2] + 0.05)
        ground = w.floor_below(gxy + f[:2] * 0.03, top + 0.02, ignore_objs=(tool,))
        # 얇고 납작한 손잡이: 손끝이 카운터에 살짝 닿을 만큼 내려가야 옆면을 잡는다 (OSC가 부드러워 눌러도 괜찮음)
        gz = max(top - 0.01, ground + (0.003 if top - ground < 0.015 else 0.009))
        mat = topdown_mat(f, ref_x=R.eef_mat[:, 0])
        R.gripper(False, n=5)
        g = np.r_[gxy, gz]
        pre = np.r_[gxy, top + 0.05]
        room = w.ceiling(gxy, top + 0.01, ignore_objs=(tool,)) - top
        if room > HAND_H + 0.08 and self.attempt == 0:
            z_travel = min(max(R.eef_pos[2], top + 0.12), top + room - HAND_H)
            R.move_ee_path([np.r_[R.eef_pos[:2], z_travel], np.r_[gxy, z_travel], pre], mat, step_len=0.03)
        if np.linalg.norm(R.eef_pos - pre) > 0.02:
            # 위가 막혔거나(상부장 아래 깊숙이) 직선으로 못 가면: 기울인 자세 후보 + 충돌 검사 경로 계획
            from ..planner import ArmPlanner

            P = ArmPlanner(w)
            P.baseline()
            done = False
            for tilt in (0.0, 0.4, 0.8):
                h_dir = np.cross(np.array([0, 0, 1.0]), f)
                if np.dot(h_dir[:2], gxy - R.base_pos[:2]) < 0:
                    h_dir = -h_dir
                a = np.array([0, 0, -1.0]) * np.cos(tilt) + h_dir * np.sin(tilt)
                m2 = np.stack([f, np.cross(a, f), a], axis=1)
                pre2 = g - a * 0.06
                ok, why = P.go(pre2, m2, grip=-1.0)
                if ok:
                    mat, pre, done = m2, pre2, True
                    break
            if not done:
                raise SkillFailure("approach", f"tool pregrasp not reachable (room above {room:.2f} m)")
        R.move_ee_path([g], mat, step_len=0.006, tol=0.006)
        R.gripper(True, n=14)
        if R.gripper_width < 0.003:
            raise SkillFailure("grasp_miss", "closed on nothing (tool handle)")
        if np.linalg.norm(R.eef_pos - g) > 0.02:
            raise SkillFailure("approach", f"did not reach tool handle: err {np.linalg.norm(R.eef_pos - g):.3f}")
        lift_room = w.ceiling(R.eef_pos[:2], R.eef_pos[2]) - R.eef_pos[2] - HAND_H + 0.1
        R.move_ee_path([R.eef_pos + np.r_[0, 0, float(np.clip(lift_room, 0.04, 0.12))]], mat, step_len=0.008)
        R.go_home(max_steps=80)
        if not w.grasped(tool):
            raise SkillFailure("grasp_slip", "tool dropped while lifting")

    def effect(self, w, tool, **kw):
        return w.grasped(tool)

    def on_except(self, w, err, tool, **kw):
        w.R.gripper(False, n=8)
        w.R.move_ee(w.R.eef_pos + np.r_[0, 0, 0.08], max_steps=30)
        return True


@skill("stir_push")
class StirPush(Skill):
    """쥔 도구의 날을 그릇 안으로 내려, 한 재료 뒤에서 다른 재료 쪽으로 밀어 두 재료를 함께 움직인다 (여러 번)."""

    retries = 1  # 젓다가 도구를 놓치면 except에서 다시 집고 한 번 더

    def on_except(self, w, err, tool, **kw):
        if err.code != "tool_slip":
            return False
        w.R.gripper(False, n=8)
        w.R.move_ee(w.R.eef_pos + np.r_[0, 0, 0.10], max_steps=40)
        try:
            PickTool(w)(tool=tool)
        except SkillFailure:
            return False
        return True

    def precondition(self, w, tool, container, targets, **kw):
        from .manip import _ensure_workspace

        if not w.grasped(tool):
            raise SkillFailure("pre_not_holding", tool)
        _ensure_workspace(w, w.obj_pos(container))

    def _blade(self, w):
        return geom_world(w, self.blade_g)

    def _move_blade(self, w, target, mat, max_steps=8, speed=0.5):
        """날 중심이 target에 가도록 eef를 옮긴다 (쥔 상태에서 날-손 오프셋은 고정으로 봄)."""
        R = w.R
        for _ in range(3):
            off = self._blade(w) - R.eef_pos
            R.move_ee(np.asarray(target) - off, mat, tol=0.006, max_steps=max_steps, speed=speed, grip=1.0)
            if np.linalg.norm(self._blade(w) - target) < 0.01:
                break

    def _count(self, w, tool, targets):
        moved = all(np.linalg.norm(w.obj_pos(t)[:2] - self.prev[t][:2]) > 0.0005 for t in targets)
        touch = any(contact_between(w, tool, t) for t in targets)
        if moved and touch:
            self.good += 1
        for t in targets:
            self.prev[t] = w.obj_pos(t)
        return False

    def content(self, w, tool, container, targets, tilt=1.0, passes=4, **kw):
        R = w.R
        _, self.blade_g = tool_parts(w, tool)
        c = w.obj_pos(container)
        lo, hi = w.obj_aabb(container)
        r_in = 0.5 * min(hi[0] - lo[0], hi[1] - lo[1]) - 0.03
        floor = w.floor_below(c[:2], hi[2] + 0.05, ignore_objs=(tool,) + tuple(targets))  # 냄비 안 바닥(또는 재료 위)
        # 날이 아래로 가도록 손가락 축을 중심으로 기울이기: 두 방향 중 날이 더 낮아지는 쪽
        mat0 = R.eef_mat.copy()
        f = mat0[:, 0]
        best = None
        for sgn in (1, -1):
            Mr = rot_about(f, sgn * tilt) @ mat0
            off = self._blade(w) - R.eef_pos
            off_new = Mr @ mat0.T @ off
            if best is None or off_new[2] < best[1]:
                best = (Mr, off_new[2])
        mat = best[0]
        ceil = w.ceiling(c[:2], hi[2] + 0.05, ignore_objs=(tool, container) + tuple(targets)) - HAND_H
        z_up = min(hi[2] + 0.25, ceil)
        R.move_ee_path([np.r_[R.eef_pos[:2], max(R.eef_pos[2], z_up)]], mat0, step_len=0.02, grip=1.0)
        R.move_ee(R.eef_pos, mat, rot_tol=0.08, max_steps=50, grip=1.0)
        self._move_blade(w, np.r_[c[:2], hi[2] + 0.06], mat, max_steps=40)
        self.good, self.prev = 0, {t: w.obj_pos(t) for t in targets}
        # 채소 중심 높이에서 민다 (바닥을 긁으면 도구가 손에서 돈다)
        z_work = max(max(floor, lo[2]) + 0.035, float(np.mean([w.obj_pos(t)[2] for t in targets])))
        for k in range(passes * len(targets)):
            a, b = targets[k % len(targets)], targets[(k + 1) % len(targets)]
            pa, pb = w.obj_pos(a), w.obj_pos(b)
            d = np.r_[(pb - pa)[:2], 0.0]
            n = np.linalg.norm(d)
            d = d / n if n > 1e-3 else np.array([1.0, 0, 0])
            start = np.r_[pa[:2] - d[:2] * 0.045, z_work]
            end = np.r_[pb[:2] + d[:2] * 0.02, z_work]
            for p in (start, end):  # 그릇 벽 안쪽으로 제한
                v = p[:2] - c[:2]
                if np.linalg.norm(v) > r_in:
                    p[:2] = c[:2] + v / np.linalg.norm(v) * r_in
            self._move_blade(w, np.r_[start[:2], hi[2] + 0.03], mat, max_steps=20)
            self._move_blade(w, start, mat, max_steps=20)
            for t in np.linspace(0, 1, 12)[1:]:
                self._move_blade(w, start + (end - start) * t, mat, max_steps=6, speed=0.2)
                self._count(w, tool, targets)
            if not w.grasped(tool):
                raise SkillFailure("tool_slip", "tool dropped while stirring")
            if self.good >= 8:
                break

    def effect(self, w, tool, container, targets, **kw):
        if self.good < 5:
            raise SkillFailure("no_joint_motion", f"both targets moved with tool contact in only {self.good} steps")
        return True
