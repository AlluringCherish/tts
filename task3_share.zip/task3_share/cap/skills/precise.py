"""정밀 놓기 + 블렌더 skill (focus3 '정밀 놓기' 계열).

- press_blender_power : 블렌더 전원 버튼 (작은 버튼, 놓는 순간 toggle) 한 번만 깔끔하게 누르기.
- close_lid_precise   : 블렌더 뚜껑 손잡이 목(neck)을 잡아 수평 유지, 용기 위에서 물체 위치로 미세 정렬 후 내려 놓기.
- place_into_jug      : 쥔 물체를 블렌더 용기 입구 위에서 미세 정렬 후 놓아 떨어뜨리기.
- place_under_nozzle  : 머그를 커피머신 노즐 아래로 (손이 들어갈 수 있는 만큼 위에서 놓고, 나머지는 옆으로 밀어 넣기).

모든 판단은 GT 상태(World)로 하고, 환경 변경은 action으로만 한다.
"""
import numpy as np

from ..robot import SkillFailure
from ..skill import Skill, skill
from .controls import frame, servo, straight_in, touching, unit
from .manip import HAND_H, Pick, _ensure_workspace, obj_touching_env, topdown_mat, travel_height


# ---------------------------------------------------------------- 공통 헬퍼
def geom_box(w, g):
    """geom의 world aabb (lo, hi)."""
    m, d = w.sim.model, w.sim.data
    if isinstance(g, str):
        g = m.geom_name2id(g)
    c, h = m.geom_aabb[g][:3], m.geom_aabb[g][3:]
    G = d.geom_xmat[g].reshape(3, 3)
    pts = np.array([d.geom_xpos[g] + G @ (c + h * np.array([sx, sy, sz]))
                    for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
    return pts.min(0), pts.max(0)


def back_base_to(w, p, fwd=0.55, lat_max=0.12, tol=0.03):
    """점 p가 base 기준 전방 fwd, 좌우 lat_max 안에 오도록 base 평행이동 (yaw 유지)."""
    R = w.R
    pb = R.world_to_base(p)
    dx = pb[0] - fwd
    dy = 0.0 if abs(pb[1]) <= lat_max else pb[1] - np.sign(pb[1]) * (lat_max * 0.5)
    if abs(dx) < tol and abs(dy) < tol:
        return False
    R.go_home(max_steps=80)
    goal = R.base_pos[:2] + R.base_mat[:2, :2] @ np.array([dx, dy])
    R.move_base(goal, R.base_yaw, max_steps=400)
    R.log("back_base", f"dx {dx:.2f} dy {dy:.2f}")
    return True


def level_mat(w, obj, mat=None):
    """쥔 물체의 z축이 수직이 되도록 하는 eef 자세 (물체 yaw는 유지)."""
    R = w.R
    Mo = w.obj_mat(obj)
    z = Mo[:, 2]
    ax = np.cross(z, [0, 0, 1.0])
    s, c = np.linalg.norm(ax), z[2]
    if s < 1e-6:
        return R.eef_mat.copy() if mat is None else mat
    from .controls import rotmat

    Rc = rotmat(ax, np.arctan2(s, c))
    return Rc @ R.eef_mat


def xy_servo(w, obj, target_xy, z, mat, iters=6, tol=0.004, max_steps=40):
    """쥔 물체 body xy를 target_xy로 (높이 z의 eef 기준), 물체 위치로 폐루프."""
    R = w.R
    for _ in range(iters):
        d = np.asarray(target_xy) - w.obj_pos(obj)[:2]
        if np.linalg.norm(d) < tol:
            break
        servo(w, np.r_[R.eef_pos[:2] + d, z], mat, max_steps=max_steps, tol=0.002, grip=1.0)
    return float(np.linalg.norm(np.asarray(target_xy) - w.obj_pos(obj)[:2]))


def lift_clear(w, dz=0.06, mat=None):
    R = w.R
    top = min(R.eef_pos[2] + dz, w.ceiling(R.eef_pos[:2], R.eef_pos[2]) - HAND_H)
    R.move_ee_path([np.r_[R.eef_pos[:2], max(top, R.eef_pos[2])]], mat, step_len=0.02, max_steps=40)


def retreat_from(w, p, dist=0.30, up=0.06):
    """p에서 멀어지게: 올리고 base 쪽으로 수평 후퇴, home."""
    R = w.R
    lift_clear(w, up)
    to_base = R.base_pos[:2] - R.eef_pos[:2]
    n = np.linalg.norm(to_base)
    back = R.eef_pos[:2] + to_base / max(n, 1e-6) * min(dist, max(n - 0.15, 0.0))
    R.move_ee_path([np.r_[back, R.eef_pos[2]]], step_len=0.03, max_steps=60)
    R.go_home(max_steps=80)


# ---------------------------------------------------------------- press_blender_power
@skill("press_blender_power")
class PressBlenderPower(Skill):
    """블렌더 전원 버튼: 닫은 손가락 끝을 정면에서 수평으로 밀어 접촉 → 잠깐 유지 → 곧게 물러나 접촉 해제(=toggle).
    상태는 '접촉이 끝나는 순간' 바뀌므로 접촉 중 떨림이 없도록 천천히 밀고 한 번에 뗀다. 켜졌는지 확인 후 반복."""

    retries = 1

    def btn(self, w, bl):
        return f"{bl.name}_power_button_main"

    def precondition(self, w, fixture="blender", **kw):
        bl = w.fixture(fixture)
        try:
            w.sim.model.geom_name2id(self.btn(w, bl))
        except Exception:  # noqa: BLE001
            raise SkillFailure("pre_no_button", self.btn(w, bl))
        if not bl.get_state()["lid_on_blender"]:
            raise SkillFailure("pre_lid_off", "blender lid not on (power would not stay on)")

    def content(self, w, fixture="blender", **kw):
        R = w.R
        bl = w.fixture(fixture)
        g = self.btn(w, bl)
        if bl.get_state()["turned_on"]:
            return
        lo, hi = geom_box(w, g)
        p = (lo + hi) / 2
        n = w.fixture_front(bl)  # 바깥 방향 (수평)
        n = unit(np.r_[n[:2], 0.0])
        face = p + n * float(np.max(np.abs((hi - lo) * n)) / 2)  # 버튼 앞면
        # 낮은 곳(카운터 바로 위)이라 수평 접근은 손목 관절 한계 → 위-앞에서 비스듬히(40°) 내려찍듯 접근
        tilt = np.deg2rad((40, 55, 28)[self.attempt % 3])
        a = unit(-n * np.cos(tilt) + np.array([0, 0, -1.0]) * np.sin(tilt))
        f = unit(np.cross([0, 0, 1.0], -n))  # 손가락 축 수평 → 손끝 상하 폭이 작다 (아래 knob 회피)
        mat = frame(a, f)
        aim = face
        back_base_to(w, aim, fwd=0.55)
        R.gripper(True, n=8)
        pre = aim - a * 0.10
        up = np.r_[R.eef_pos[:2], max(R.eef_pos[2], pre[2] + 0.08)]
        R.move_ee_path([up, pre + np.array([0, 0, 0.08]), pre], mat, step_len=0.03, grip=1.0)
        servo(w, pre, mat, max_steps=50, grip=1.0)
        if np.linalg.norm(pre - R.eef_pos) > 0.03:
            raise SkillFailure("approach", f"button pre not reached ({np.linalg.norm(pre - R.eef_pos):.3f})")
        self.dbg = []
        for k in range(3):
            # 손끝(grip site + 0.011)이 버튼 앞면에 닿을 때까지 천천히 전진
            ok = straight_in(w, aim + a * 0.012, mat, step=0.002, max_steps=120,
                             stop_fn=lambda: touching(w, g), grip=1.0)
            t = touching(w, g)
            if t:  # 접촉 유지하며 살짝 더 눌러 확실히
                hold = R.eef_pos + a * 0.002
                for _ in range(6):
                    R.step(arm=R.arm_cmd(hold, mat, max_dpos=0.3), grip=1.0)
            # 곧게 뒤로 (한 번에 떼기)
            back = R.eef_pos - a * 0.06
            R.move_ee_path([back], mat, step_len=0.015, grip=1.0)
            R.idle(3, arm=R.arm_cmd(R.eef_pos, mat), grip=1.0)
            on = bl.get_state()["turned_on"]
            self.dbg.append((k, bool(t), bool(on), round(float(np.dot(R.eef_pos - face, n)), 3)))
            if on:
                break
            if not t:  # 닿지 않았으면 조금 낮추거나 올려 다시
                aim = aim + np.array([0, 0, -0.004 if k == 0 else 0.008])
                servo(w, aim - a * 0.06, mat, max_steps=30, grip=1.0)
        R.move_ee_path([R.eef_pos - a * 0.12], mat, step_len=0.03, max_steps=60, grip=1.0)
        if not bl.get_state()["turned_on"]:
            raise SkillFailure("no_press", f"blender not on after presses {self.dbg}")

    def effect(self, w, fixture="blender", **kw):
        return bool(w.fixture(fixture).get_state()["turned_on"])

    def on_except(self, w, err, **kw):
        R = w.R
        R.move_ee(R.eef_pos - R.eef_mat[:, 2] * 0.08, max_steps=40)
        return True


# ---------------------------------------------------------------- blender lid
def lid_parts(w, bl):
    """뚜껑 body 이름, 원판(가장 넓은 geom) 윗면 z, 손잡이/목 geom 목록."""
    lid = f"{bl.blender_lid.name}_main"
    m = w.sim.model
    gs = w.body_geoms(lid)
    best = None
    for g in gs:
        lo, hi = geom_box(w, g)
        wd = (hi - lo)[:2].max()
        if best is None or wd > best[0]:
            best = (wd, g, lo, hi)
    return lid, best


@skill("grasp_lid")
class GraspLid(Skill):
    """뚜껑 손잡이 목을 위에서 잡는다: 원판 윗면 바로 위(손끝 3 mm 여유)에서 손가락을 닫아 손잡이 아래 목을 쥔다.
    가운데를 잡으니 들어도 수평이 유지된다."""

    retries = 2

    def precondition(self, w, fixture="blender", **kw):
        bl = w.fixture(fixture)
        if bl.blender_lid is None:
            raise SkillFailure("pre_no_lid", "")
        lid = f"{bl.blender_lid.name}_main"
        _ensure_workspace(w, w.obj_pos(lid))

    def plan(self, w, bl):
        """잡을 점·손가락 축 후보. 손잡이(handle_main geom)가 가운데 있으면 그 손잡이를, 옆 탭이면 탭 바깥쪽을 잡는다."""
        R = w.R
        lid = f"{bl.blender_lid.name}_main"
        c = w.obj_pos(lid)
        hname = f"{bl.blender_lid.name}_handle_main"
        try:
            hlo, hhi = geom_box(w, hname)
        except Exception:  # noqa: BLE001
            hlo, hhi = w.obj_aabb(lid)
        hc = (hlo + hhi) / 2
        radial = hc[:2] - c[:2]
        side = np.linalg.norm(radial) > 0.03
        if side:  # 옆 탭: 탭의 바깥 절반, 손가락 축 = 탭 폭 방향(반지름에 수직)
            u = np.r_[unit(radial), 0.0]
            P = np.array([[x, y, z] for x in (hlo[0], hhi[0]) for y in (hlo[1], hhi[1]) for z in (hlo[2], hhi[2])])
            r_out = float(np.max((P - c) @ u))
            gxy = c[:2] + u[:2] * (r_out - 0.022)
            fs = [np.cross([0, 0, 1.0], u)]
        else:
            gxy = hc[:2]
            to_r = unit(np.r_[R.base_pos[:2] - gxy, 0.0])
            base_f = np.cross([0, 0, 1.0], to_r)
            fs = []
            for ang in (0, 90, 45, -45, 30, -30, 60, -60):
                t = np.deg2rad(ang)
                fs.append(np.cos(t) * base_f + np.sin(t) * to_r)
        out = []
        for f in fs:
            f = unit(f)
            # 손가락 방향 손잡이 폭 (너무 넓으면 제외)
            P = w.obj_bbox(lid) if False else None
            mid = (hlo[2] + hhi[2]) / 2
            fl = max(w.floor_below(gxy + f[:2] * s_ * (0.045), hhi[2] + 0.05, ignore_objs=()) for s_ in (-1, 1))
            gz = max(mid + 0.004, fl + 0.015)
            gz = min(gz, hhi[2] - 0.003) if hhi[2] - 0.003 > fl + 0.012 else fl + 0.012
            out.append((np.r_[gxy, gz], topdown_mat(f, ref_x=R.eef_mat[:, 0]), side))
        return out

    def feasible(self, w, P, g, mat, lid_bid):
        P.allowed = set()
        if P.ik_free(g + np.array([0, 0, 0.07]), mat, seeds=2) is None:
            return False
        P.allowed = {lid_bid}
        return P.ik_free(g, mat, seeds=2) is not None

    def content(self, w, fixture="blender", **kw):
        from ..planner import ArmPlanner

        R = w.R
        bl = w.fixture(fixture)
        lid = f"{bl.blender_lid.name}_main"
        lo, hi = w.obj_aabb(lid)
        if w.obj_mat(lid)[2, 2] < 0.9:
            raise SkillFailure("pre_lid_tilted", f"lid z-axis {w.obj_mat(lid)[:, 2].round(2)}")
        c0 = w.obj_pos(lid).copy()
        cands = self.plan(w, bl)
        P = ArmPlanner(w)
        P.baseline()
        bid = w.body_id(lid)
        ok = [cd for cd in cands if self.feasible(w, P, cd[0], cd[1], bid)]
        if not ok:
            ok = cands
        g, mat, side = ok[self.attempt % len(ok)]
        pre = g + np.array([0, 0, 0.07])
        R.gripper(False, n=6)
        want = max(pre[2] + 0.03, min(R.eef_pos[2], hi[2] + 0.2))
        safe = max(travel_height(w, [(R.eef_pos, R.eef_pos[2]), (pre[:2], hi[2] + 0.01)], want, ignore=(lid,)), pre[2])
        R.move_ee_path([np.r_[R.eef_pos[:2], safe], np.r_[pre[:2], safe], pre], mat, step_len=0.03)
        servo(w, pre, mat, max_steps=40)
        if np.linalg.norm(pre - R.eef_pos) > 0.03:  # 직선 경로가 막힘(위 벽장 등) → 충돌 검사 경로 계획
            R.move_ee_path([np.r_[R.eef_pos[:2], safe]], mat, step_len=0.03, max_steps=40)
            P.allowed = set()
            P.go(pre, mat)
            servo(w, pre, mat, max_steps=30)
        if np.linalg.norm(pre - R.eef_pos) > 0.03:
            raise SkillFailure("approach", f"lid pregrasp not reached {np.linalg.norm(pre - R.eef_pos):.3f} "
                                           f"(feasible {len(ok)}/{len(cands)})")
        straight_in(w, g, mat, step=0.006, max_steps=80)
        servo(w, g, mat, max_steps=20, tol=0.003)
        R.gripper(True, n=14)
        if R.gripper_width < 0.004:
            raise SkillFailure("grasp_miss", "closed on nothing (lid)")
        R.idle(3, arm=R.arm_cmd(R.eef_pos, mat), grip=1.0)
        R.move_ee_path([R.eef_pos + np.array([0, 0, 0.10])], mat, step_len=0.01, grip=1.0)
        if not w.grasped(lid) or w.obj_pos(lid)[2] < c0[2] + 0.05:
            raise SkillFailure("grasp_slip", f"lid not lifted (dz {w.obj_pos(lid)[2] - c0[2]:.3f}, side={side})")

    def effect(self, w, fixture="blender", **kw):
        bl = w.fixture(fixture)
        return w.grasped(f"{bl.blender_lid.name}_main")

    def on_except(self, w, err, **kw):
        R = w.R
        R.gripper(False, n=8)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=40)
        return True


@skill("close_lid_precise")
class CloseLidPrecise(Skill):
    """쥔 뚜껑을 용기 위로: 뚜껑 바닥이 용기 입구보다 3 cm 위인 높이로 옮기고, 뚜껑 body를 닫힌 위치 xy로 폐루프 정렬,
    손목으로 수평을 맞춘 뒤 천천히 내리다 닿으면(또는 목표 높이) 놓는다."""

    retries = 1

    def precondition(self, w, fixture="blender", **kw):
        bl = w.fixture(fixture)
        lid = f"{bl.blender_lid.name}_main"
        if not w.grasped(lid):
            raise SkillFailure("pre_not_holding", lid)
        goal = np.asarray(bl.get_lid_closed_pos(w.env))
        _ensure_workspace(w, goal)
        if not w.grasped(lid):
            raise SkillFailure("dropped", "lid slipped while moving base")

    def content(self, w, fixture="blender", **kw):
        R = w.R
        bl = w.fixture(fixture)
        lid = f"{bl.blender_lid.name}_main"
        goal = np.asarray(bl.get_lid_closed_pos(w.env))
        mat = level_mat(w, lid)
        R.move_ee(R.eef_pos, mat, tol=0.02, rot_tol=0.03, max_steps=30, grip=1.0)
        lo, _ = w.obj_aabb(lid)
        off_z = R.eef_pos[2] - w.obj_pos(lid)[2]  # eef - lid body
        carry = goal[2] + off_z + 0.04
        off = w.obj_pos(lid)[:2] - R.eef_pos[:2]
        exy = goal[:2] - off
        want = max(carry, R.eef_pos[2])
        cap = w.ceiling(exy, goal[2] + 0.05) - HAND_H + 0.04
        z1 = max(carry, min(want, cap))
        R.move_ee_path([np.r_[R.eef_pos[:2], z1], np.r_[exy, z1], np.r_[exy, carry]], mat, step_len=0.02, grip=1.0,
                       speed=0.6, stop_fn=lambda: not w.grasped(lid))
        if not w.grasped(lid):
            raise SkillFailure("dropped", "lid slipped while carrying")
        mat = level_mat(w, lid)
        # 뚜껑 yaw를 블렌더 yaw에 맞춘다 (사각·주둥이 있는 뚜껑은 방향이 맞아야 들어간다)
        Ml = w.obj_mat(lid)
        dyaw = wrap(float(bl.rot) - float(np.arctan2(Ml[1, 0], Ml[0, 0])))
        if abs(dyaw) > 0.03:
            mat = rotz(dyaw) @ mat
            R.move_ee(R.eef_pos, mat, tol=0.02, rot_tol=0.03, max_steps=40, grip=1.0)
            mat = level_mat(w, lid)
        self.dyaw = round(float(dyaw), 3)
        e1 = xy_servo(w, lid, goal[:2], carry, mat)
        # 내리기: body z가 goal + 1 cm 가 될 때까지 또는 접촉
        # 닫힌 높이 + 1 cm 까지 천천히 내리고, 닿으면 멈춘다. 놓기 직전에 다시 수평 (누르면 손 안에서 기울어진다)
        tgt = np.r_[R.eef_pos[:2], goal[2] + off_z + 0.006]
        seated = lambda: w.obj_pos(lid)[2] - goal[2] < 0.010  # noqa: E731
        straight_in(w, tgt, mat, step=0.002, max_steps=100, grip=1.0,
                    stop_fn=lambda: seated() or obj_touching_env(w, lid))
        mat = level_mat(w, lid)
        R.move_ee(R.eef_pos, mat, tol=0.02, rot_tol=0.02, max_steps=15, grip=1.0)
        e2 = float(np.linalg.norm(w.obj_pos(lid)[:2] - goal[:2]))
        self.dbg = dict(dyaw=self.dyaw, e_above=round(e1, 3), e_down=round(e2, 3), dz=round(float(w.obj_pos(lid)[2] - goal[2]), 3))
        hold = R.eef_pos.copy()
        for _ in range(12):  # 손 위치를 유지한 채 천천히 벌린다
            R.step(arm=R.arm_cmd(hold, mat, max_dpos=0.3), grip=-1.0)
        R.move_ee_path([R.eef_pos + np.array([0, 0, 0.08])], mat, step_len=0.01)
        R.idle(5)

    def effect(self, w, fixture="blender", **kw):
        bl = w.fixture(fixture)
        lid = f"{bl.blender_lid.name}_main"
        goal = np.asarray(bl.get_lid_closed_pos(w.env))
        d = float(np.linalg.norm(w.obj_pos(lid) - goal))
        if d > 0.035 or w.obj_mat(lid)[2, 2] < np.cos(np.deg2rad(6)):
            raise SkillFailure("misplaced", f"lid {d:.3f} m from closed, cos {w.obj_mat(lid)[2, 2]:.3f}; {getattr(self, 'dbg', '')}")
        return True

    def on_except(self, w, err, fixture="blender", **kw):
        if err.code not in ("dropped", "misplaced"):
            return False
        bl = w.fixture(fixture)
        try:
            GraspLid(w)(fixture=bl)
        except SkillFailure:
            return False
        return True


# ---------------------------------------------------------------- place_into_jug
def jug_opening(w, bl):
    """블렌더 용기: 안쪽 region 중심 xy, 바닥 z, 입구(가장자리 꼭대기) z."""
    from .. import fx as FX

    regs = FX.int_regions(bl)
    p0, px, py, pz = max(regs.values(), key=lambda r: np.linalg.norm(r[1] - r[0]) * np.linalg.norm(r[2] - r[0]))
    c = p0 + (px - p0) / 2 + (py - p0) / 2
    rim = w.floor_below(c[:2] + unit(px - p0)[:2] * np.linalg.norm(px - p0) * 0.62, pz[2] + 0.2)
    rim = max(rim, pz[2])
    return c[:2], p0[2], rim, (p0, px, py, pz)


@skill("place_into_jug")
class PlaceIntoJug(Skill):
    """쥔 물체를 블렌더 용기 입구 위로 옮겨 물체 xy를 용기 중심에 폐루프 정렬하고, 물체 바닥이 입구보다 1.5 cm 위일 때 놓는다."""

    retries = 1

    def precondition(self, w, obj, fixture="blender", **kw):
        if not w.grasped(obj):
            raise SkillFailure("pre_not_holding", obj)
        bl = w.fixture(fixture)
        c, floor, rim, _ = jug_opening(w, bl)
        _ensure_workspace(w, np.r_[c, rim])
        if not w.grasped(obj):
            raise SkillFailure("dropped", "object slipped while moving base")

    def content(self, w, obj, fixture="blender", **kw):
        R = w.R
        bl = w.fixture(fixture)
        c, floor, rim, _ = jug_opening(w, bl)
        lo, hi = w.obj_aabb(obj)
        below = R.eef_pos[2] - lo[2]
        mat = topdown_mat(R.eef_mat[:, 0], ref_x=R.eef_mat[:, 0])
        carry = rim + below + 0.05
        off = w.obj_pos(obj)[:2] - R.eef_pos[:2]
        exy = c - off
        z1 = max(carry, min(R.eef_pos[2], carry + 0.15))
        cap = w.ceiling(exy, rim + 0.05) - HAND_H
        z1 = max(carry, min(z1, cap))
        R.move_ee_path([np.r_[R.eef_pos[:2], z1], np.r_[exy, z1], np.r_[exy, carry]], mat, step_len=0.02, grip=1.0,
                       speed=0.6, stop_fn=lambda: not w.grasped(obj))
        if not w.grasped(obj):
            raise SkillFailure("dropped", "object slipped while carrying")
        e1 = xy_servo(w, obj, c, carry, mat)
        lo, hi = w.obj_aabb(obj)
        below = R.eef_pos[2] - lo[2]
        tgt = np.r_[R.eef_pos[:2], rim + below + 0.012]
        straight_in(w, tgt, mat, step=0.004, max_steps=60, grip=1.0, stop_fn=lambda: obj_touching_env(w, obj))
        e2 = xy_servo(w, obj, c, R.eef_pos[2], mat, iters=2)
        self.dbg = dict(e_above=round(e1, 3), e_drop=round(e2, 3), z_bot=round(float(w.obj_aabb(obj)[0][2] - rim), 3))
        R.gripper(False, n=10)
        R.idle(10, arm=R.arm_cmd(R.eef_pos, mat))
        R.move_ee_path([R.eef_pos + np.array([0, 0, 0.10])], mat, step_len=0.02)

    def effect(self, w, obj, fixture="blender", **kw):
        from robocasa.utils import object_utils as OU

        bl = w.fixture(fixture)
        if w.grasped(obj):
            return False
        if not OU.obj_inside_of(w.env, obj, bl, th=0.01):
            c, floor, rim, _ = jug_opening(w, bl)
            raise SkillFailure("not_inside", f"obj at {np.round(w.obj_pos(obj) - np.r_[c, floor], 3)} rel jug; "
                                             f"{getattr(self, 'dbg', '')}")
        return True

    def on_except(self, w, err, obj, **kw):
        if err.code != "dropped":
            return False
        R = w.R
        R.gripper(False, n=8)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=30)
        try:
            Pick(w)(obj=obj)
        except SkillFailure:
            return False
        return True


# ---------------------------------------------------------------- mug: handle grasp + place under nozzle
def body_verts(w, name):
    """body 충돌 mesh 꼭짓점 (world)."""
    m, d = w.sim.model._model, w.sim.data._data
    out = []
    for g in w.body_geoms(name):
        if m.geom_type[g] != 7:
            continue
        mid = m.geom_dataid[g]
        a, n = m.mesh_vertadr[mid], m.mesh_vertnum[mid]
        out.append(d.geom_xpos[g] + m.mesh_vert[a:a + n] @ d.geom_xmat[g].reshape(3, 3).T)
    return np.concatenate(out) if out else w.obj_bbox(name)


def mug_handle(w, obj):
    """머그 손잡이: 수평 긴 축(손잡이 포함 방향) 중 단면 폭이 좁은 쪽 끝이 손잡이.
    반환 dict(u=손잡이 방향(world, 수평), f=접선(손가락 축), g=잡을 점(바깥 기둥 윗부분), top/bot=기둥 z, out=바깥 끝 거리)."""
    c, M = w.obj_pos(obj), w.obj_mat(obj)
    L = (body_verts(w, obj) - c) @ M
    ext = np.ptp(L, axis=0)
    ax = 0 if ext[0] > ext[1] else 1
    o = 1 - ax

    def width_at(sgn):
        e = L[:, ax].max() if sgn > 0 else L[:, ax].min()
        sel = np.abs(L[:, ax] - 0.8 * e) < 0.006
        return float(np.ptp(L[sel, o])) if sel.sum() > 2 else 1.0

    sgn = 1 if width_at(1) < width_at(-1) else -1
    e = L[:, ax].max() if sgn > 0 else L[:, ax].min()
    bar = L[np.abs(L[:, ax] - e) < 0.012]
    gl = np.zeros(3)
    gl[ax] = e - sgn * 0.009
    gl[o] = float(np.median(bar[:, o]))
    top, bot = float(bar[:, 2].max()), float(bar[:, 2].min())
    gl[2] = top
    u = np.zeros(3)
    u[ax] = sgn
    fl = np.zeros(3)
    fl[o] = 1.0
    uw = M @ u
    return dict(u=unit(np.r_[uw[:2], 0.0]), f=unit(np.r_[(M @ fl)[:2], 0.0]), g=c + M @ gl,
                top=float((c + M @ np.r_[0, 0, top])[2]), bot=float((c + M @ np.r_[0, 0, bot])[2]),
                out=abs(e), width=width_at(sgn))


def rotz(t):
    c, s_ = np.cos(t), np.sin(t)
    return np.array([[c, -s_, 0], [s_, c, 0], [0, 0, 1.0]])


def yaw_of(v):
    return float(np.arctan2(v[1], v[0]))


def wrap(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


@skill("grasp_mug_handle")
class GraspMugHandle(Skill):
    """머그 손잡이 바깥 기둥 윗부분을 위에서 잡는다 (손가락 축 = 접선). 머그가 가벼워(15~25 g) 기울기가 작다.
    want_dir(수평 단위벡터)가 주어지면, 나중에 손잡이가 그 방향을 보도록 손목을 돌릴 양을 고려해 손가락 부호를 고른다."""

    retries = 2

    def precondition(self, w, obj, **kw):
        _ensure_workspace(w, w.obj_pos(obj))

    def content(self, w, obj, want_dir=None, low=0.0, **kw):
        from .controls import choose_mat

        R = w.R
        h = mug_handle(w, obj)
        self.h = h
        down = np.array([0, 0, -1.0])
        dz = (0.0, -0.006, 0.006)[self.attempt % 3]
        lo_, _ = w.obj_aabb(obj)
        gz = h["top"] - 0.011 - low * max(h["top"] - h["bot"] - 0.02, 0.0)
        g = np.r_[h["g"][:2], max(gz + dz, lo_[2] + 0.016)]
        delta = 0.0 if want_dir is None else wrap(yaw_of(want_dir) - yaw_of(h["u"]))
        # 최종(회전 후) 손가락 축 후보 ±f' 중 손목 여유가 큰 쪽 → 지금 잡을 자세는 그걸 -delta 만큼 되돌린 것
        f_fin = rotz(delta) @ h["f"]
        mat_fin, _ = choose_mat(w, down, f_fin)
        f_g = rotz(-delta) @ mat_fin[:, 0]
        mat = frame(down, f_g)
        self.delta = delta
        lo, hi = w.obj_aabb(obj)
        # 옆에 머신·벽이 있으면 손(손가락 축 방향 ±10 cm)이 걸린다 → 손잡이 방향 축으로 기울인 후보 중 충돌 없는 것
        from ..planner import ArmPlanner
        from .controls import rotmat

        P = ArmPlanner(w)
        P.baseline()
        bid = w.body_id(obj)
        cands = []
        for tdeg in (0, 25, -25, 40, -40):
            Rt = rotmat(h["u"], np.deg2rad(tdeg))
            cands.append((tdeg, Rt @ mat))
        chosen = None
        for tdeg, M_ in cands:
            a = M_[:, 2]
            P.allowed = set()
            if P.ik_free(g - a * 0.08, M_, seeds=2) is None:
                continue
            P.allowed = {bid}
            if P.ik_free(g, M_, seeds=2) is None:
                continue
            chosen = (tdeg, M_)
            break
        if chosen is None:
            chosen = cands[self.attempt % len(cands)]
        self.tilt, mat = chosen
        a = mat[:, 2]
        pre = g - a * 0.08
        want = max(pre[2] + 0.03, min(R.eef_pos[2], hi[2] + 0.2))
        safe = max(travel_height(w, [(R.eef_pos, R.eef_pos[2]), (pre[:2], hi[2] + 0.01)], want, ignore=(obj,)), pre[2])
        R.gripper(False, n=6)
        R.move_ee_path([np.r_[R.eef_pos[:2], safe], np.r_[pre[:2], safe], pre], mat, step_len=0.03)
        servo(w, pre, mat, max_steps=40)
        if np.linalg.norm(pre - R.eef_pos) > 0.03:
            raise SkillFailure("approach", f"handle pregrasp not reached {np.linalg.norm(pre - R.eef_pos):.3f} (tilt {self.tilt})")
        straight_in(w, g, mat, step=0.005, max_steps=60, stop_fn=lambda: obj_touching_env(w, obj) and False)
        servo(w, g, mat, max_steps=20, tol=0.003)
        R.gripper(True, n=14)
        if R.gripper_width < 0.003:
            raise SkillFailure("grasp_miss", f"closed on nothing (handle width {h['width']:.3f})")
        R.idle(3, arm=R.arm_cmd(R.eef_pos, mat), grip=1.0)
        R.move_ee_path([R.eef_pos + np.array([0, 0, 0.08])], mat, step_len=0.01, grip=1.0)
        if not w.grasped(obj):
            raise SkillFailure("grasp_slip", "mug dropped while lifting by handle")

    def effect(self, w, obj, **kw):
        return w.grasped(obj)

    def on_except(self, w, err, **kw):
        R = w.R
        R.gripper(False, n=8)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=40)
        return True


def level_keep_yaw(w, obj, mat):
    """쥔 물체 z축을 수직으로 (손목 회전), 손 yaw는 mat 기준."""
    return level_mat(w, obj, mat)


@skill("place_under_nozzle")
class PlaceUnderNozzle(Skill):
    """손잡이를 쥔 머그를 노즐 아래로: 손잡이가 머신 앞(로봇 쪽)을 보게 손목을 돌리고, 머그를 수평으로 세운 뒤
    머신 앞 18 cm에서 '받침 바로 위 ~ 노즐 아래' 높이로 맞춰 수평으로 밀어 넣는다(물체 위치 폐루프).
    받침 위에서 내려놓고 손을 뒤로 뺀다."""

    retries = 0

    def precondition(self, w, obj, fixture, **kw):
        if not w.grasped(obj):
            raise SkillFailure("pre_not_holding", obj)
        align_to_machine(w, fixture, holding=True)
        if not w.grasped(obj):
            raise SkillFailure("dropped", "mug dropped while moving base")

    def geometry(self, w, obj, cm):
        site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
        n = w.fixture_front(cm)
        n = unit(np.r_[n[:2], 0.0])
        tray = w.floor_below(site[:2], site[2] + 0.04, ignore_objs=(obj,))
        # 얇은 받침 판은 ray가 놓칠 때가 있다 → 머신 geom 중 site 아래에 있는 것의 윗면으로 보정
        m = w.sim.model
        for g in range(m.ngeom):
            if not (m.geom_contype[g] or m.geom_conaffinity[g]) or not m.geom(g).name.startswith(cm.naming_prefix):
                continue
            lo_g, hi_g = geom_box(w, g)
            if np.all(lo_g[:2] - 0.005 <= site[:2]) and np.all(site[:2] <= hi_g[:2] + 0.005) and hi_g[2] < site[2] + 0.02:
                tray = max(tray, hi_g[2])
        lo, hi = w.obj_aabb(obj)
        r = 0.045
        pts = [site[:2]] + [site[:2] + r * np.array([np.cos(t), np.sin(t)]) for t in np.linspace(0, 2 * np.pi, 9)[:-1]]
        z0 = max(tray, site[2] + 0.003) + 0.006
        noz = min(w.ceiling(p, z0, ignore_objs=(obj,)) for p in pts)
        return site, n, tray, noz

    def content(self, w, obj, fixture, entry=None, **kw):
        R = w.R
        cm = w.fixture(fixture)
        site, n, tray, noz = self.geometry(w, obj, cm)
        if entry is not None:  # 노즐 앞 막대(스팀 노즐 등)를 피하는 진입 방향 (바깥 방향 단위벡터)
            n = unit(np.r_[np.asarray(entry)[:2], 0.0])
        self.dbg = dict(clear=round(float(noz - tray), 3))
        # 1) 들어 올린 채 손목 회전: 손잡이 → n
        h = mug_handle(w, obj)
        delta = wrap(yaw_of(n) - yaw_of(h["u"]))
        z_carry = max(R.eef_pos[2], tray + 0.25)
        R.move_ee_path([np.r_[R.eef_pos[:2], z_carry]], R.eef_mat.copy(), step_len=0.02, grip=1.0)
        M0 = R.eef_mat.copy()
        k = int(np.ceil(abs(delta) / 0.5))
        for j in range(1, k + 1):
            R.move_ee(R.eef_pos, rotz(delta * j / k) @ M0, tol=0.02, rot_tol=0.05, max_steps=25, grip=1.0)
        mat = level_mat(w, obj)
        R.move_ee(R.eef_pos, mat, tol=0.02, rot_tol=0.03, max_steps=30, grip=1.0)
        if not w.grasped(obj):
            raise SkillFailure("dropped", "mug dropped while rotating")
        h = mug_handle(w, obj)
        self.dbg["handle_err_deg"] = round(float(np.degrees(wrap(yaw_of(h["u"]) - yaw_of(n)))), 1)
        # 2) 높이: 머그 바닥 = 받침 + 여유 (노즐과 머그 윗면 사이도 여유)
        lo, hi = w.obj_aabb(obj)
        bot_off = R.eef_pos[2] - lo[2]
        hgt = float(np.ptp((body_verts(w, obj) - w.obj_pos(obj)) @ w.obj_mat(obj)[:, 2]))  # 머그 자체 높이 (기울기 무관)
        room = noz - tray - hgt
        lift = float(np.clip(room * 0.5, 0.006, 0.025))
        ez = tray + lift + bot_off
        self.dbg.update(room=round(float(room), 3), lift=round(lift, 3))
        # 3) 머신 앞 대기점 → 수평 진입
        off = w.obj_pos(obj)[:2] - R.eef_pos[:2]
        stage = site[:2] + n[:2] * 0.20 - off
        z_tr = max(ez, R.eef_pos[2])
        R.move_ee_path([np.r_[stage, z_tr], np.r_[stage, ez]], mat, step_len=0.02, grip=1.0, speed=0.6)
        mat = level_mat(w, obj)
        servo(w, np.r_[stage, ez], mat, max_steps=30, grip=1.0)
        if not w.grasped(obj):
            raise SkillFailure("dropped", "mug dropped while carrying")
        # 수평 진입: 매 구간 머그 위치 기준으로 목표 갱신
        stuck = 0
        for it in range(40):
            d = site[:2] - w.obj_pos(obj)[:2]
            if np.linalg.norm(d) < 0.006:
                break
            stepv = d if np.linalg.norm(d) < 0.03 else d / np.linalg.norm(d) * 0.03
            tgt = np.r_[R.eef_pos[:2] + stepv, ez]
            before = w.obj_pos(obj)[:2].copy()
            mat = level_mat(w, obj)  # 손잡이에서 머그가 조금씩 처지므로 매번 다시 수평
            servo(w, tgt, mat, max_steps=12, tol=0.003, grip=1.0)
            if np.linalg.norm(w.obj_pos(obj)[:2] - before) < 0.002:
                stuck += 1
                if stuck >= 4:
                    break
            else:
                stuck = 0
        e_in = float(np.linalg.norm(site[:2] - w.obj_pos(obj)[:2]))
        self.dbg.update(e_in=round(e_in, 3), tilt=round(float(np.degrees(np.arccos(np.clip(w.obj_mat(obj)[2, 2], -1, 1)))), 1))
        if kw.get("debug_hold"):
            raise SkillFailure("debug_hold", str(self.dbg))
        # 4) 내려놓기
        z_start = R.eef_pos[2]
        straight_in(w, np.r_[R.eef_pos[:2], ez - lift - 0.008], mat, step=0.002, max_steps=30, grip=1.0,
                    stop_fn=lambda: z_start - R.eef_pos[2] > lift - 0.006 and obj_touching_env(w, obj))
        self.dbg["drop"] = round(float(w.obj_aabb(obj)[0][2] - tray), 3)
        R.gripper(False, n=10)
        # 5) 손 빼기: 손잡이 방향(앞)으로 수평 → 위
        R.move_ee_path([R.eef_pos + n * 0.12, R.eef_pos + n * 0.30 + np.array([0, 0, 0.05])], step_len=0.02, max_steps=60)
        R.go_home(max_steps=80)

    def effect(self, w, obj, fixture, **kw):
        cm = w.fixture(fixture)
        if w.grasped(obj):
            return False
        if not cm.check_receptacle_placement_for_pouring(w.env, obj):
            site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
            raise SkillFailure("misplaced", f"mug {np.round(w.obj_pos(obj) - site, 3)} from site; {getattr(self, 'dbg', '')}")
        return True


def nozzle_entry(w, obj, fixture, angles=(0, 20, -20, 40, -40, 60, -60)):
    """머그를 수평으로 밀어 넣을 방향(머신 바깥 쪽 단위벡터). 머그가 지나갈 원기둥 띠와 손잡이 위 손 영역에
    걸리는 것이 없는 방향을 정면부터 차례로 찾는다 (위로 쏜 ray)."""
    cm = w.fixture(fixture)
    site, n, tray, noz = PlaceUnderNozzle.geometry(None, w, obj, cm)
    c, M = w.obj_pos(obj), w.obj_mat(obj)
    L = (body_verts(w, obj) - c) @ M
    ext = np.ptp(L, axis=0)
    r_m = float(min(ext[0], ext[1])) / 2 + 0.005
    h = float(ext[2])
    hd = mug_handle(w, obj)
    lift = float(np.clip((noz - tray - h) * 0.5, 0.006, 0.025))
    z_lo, z_top = tray + 0.004, tray + lift + h + 0.003
    best = None
    for ang in angles:
        d = rotz(np.deg2rad(ang)) @ n
        t = np.cross([0, 0, 1.0], d)
        bad = 0
        for sdist in np.arange(0.02, 0.22, 0.02):
            ctr = site[:2] + d[:2] * sdist
            pts = [ctr] + [ctr + r_m * np.array([np.cos(a), np.sin(a)]) for a in np.linspace(0, 2 * np.pi, 9)[:-1]]
            bad += 100 * sum(w.ceiling(p, z_lo, ignore_objs=(obj,)) < z_top for p in pts)  # 머그 띠 막힘이 우선
            # 손: 손잡이 위 (반지름 방향 ±3 cm, 접선 ±10 cm), 손잡이 윗면 + 1.5 cm ~ + 12 cm
            hc = ctr + d[:2] * (hd["out"] - 0.009)
            hz = z_top - 0.01
            for a_ in (-0.03, 0.0, 0.03):
                for b_ in (-0.09, -0.045, 0.0, 0.045, 0.09):
                    p = hc + d[:2] * a_ + t[:2] * b_
                    bad += w.ceiling(p, hz, ignore_objs=(obj,)) < hz + 0.11
        if best is None or bad < best[0]:
            best = (bad, ang, d)
        if bad == 0:
            break
    w.R.log("nozzle_entry", f"angle {best[1]} blocked {best[0]}")
    return best[2]


def align_to_machine(w, fixture, holding=False):
    """base를 머신 정면(받침 site 앞 0.55 m, 머신을 바라보게)으로. 쥔 상태면 팔을 접지 않는다(손잡이로 든 머그가 흔들려 빠짐)."""
    R = w.R
    cm = w.fixture(fixture)
    site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
    n = w.fixture_front(cm)
    sb = R.world_to_base(site)
    nh = n[:2] / (np.linalg.norm(n[:2]) + 1e-9)
    facing = np.dot(R.base_mat[:2, 0], -nh)
    if facing >= 0.9 and 0.47 <= sb[0] <= 0.62 and abs(sb[1]) <= 0.08:
        return False
    from .nav import Navigate

    goal = site[:2] + nh * 0.55
    yaw = float(np.arctan2(-nh[1], -nh[0]))
    if facing < 0.9 or np.linalg.norm(goal - R.base_pos[:2]) > 0.6:
        Navigate(w)(fixture=cm)
    if holding:  # go_home은 빠르게 휘둘러 손잡이로 든 머그가 빠진다 → 손을 천천히 몸 쪽·위로
        to_b = R.base_pos[:2] - R.eef_pos[:2]
        tb = to_b / (np.linalg.norm(to_b) + 1e-9) * min(0.15, max(np.linalg.norm(to_b) - 0.35, 0.0))
        R.move_ee_path([R.eef_pos + np.r_[tb, 0.05]], R.eef_mat.copy(), step_len=0.01, grip=1.0, speed=0.5)
    else:
        R.go_home(max_steps=60)
    R.move_base(goal, yaw, max_steps=400)
    R.log("align_to_machine", f"site_b {np.round(R.world_to_base(site), 2)}")
    return True
