"""물체 조작 skill: pick, place."""
import numpy as np

from ..robot import SkillFailure
from ..skill import Skill, skill

HAND_H = 0.16  # grip site에서 손목 위까지 높이 (천장 여유)
GRIPPER_MAX_W = 0.075
RIM_CATS = ("mug", "cup", "bowl", "pot", "glass", "colander", "tupperware", "jar", "pitcher", "measuring_cup")  # 손가락 최대 벌림 약 0.078
REACH = 0.95  # base 중심에서 eef 수평 도달 한계(근사)


def topdown_mat(finger_axis, ref_x=None):
    """eef z=아래, x=손가락 축. ref_x와 가까운 방향으로 부호 선택(손목 회전 최소화)."""
    f = np.array([finger_axis[0], finger_axis[1], 0.0])
    f /= np.linalg.norm(f) + 1e-9
    if ref_x is not None and np.dot(f, ref_x) < 0:
        f = -f
    z = np.array([0, 0, -1.0])
    y = np.cross(z, f)
    return np.stack([f, y, z], axis=1)


def front_mat(approach, finger_axis=(0, 0, 1)):
    """eef z=approach(수평), x=손가락 축."""
    z = np.asarray(approach, float)
    z /= np.linalg.norm(z)
    x = np.asarray(finger_axis, float)
    x = x - np.dot(x, z) * z
    x /= np.linalg.norm(x)
    return np.stack([x, np.cross(z, x), z], axis=1)


def torso_for(z):
    """torso 0에서 top-down은 z 0.8~1.3 m에 모두 닿는다(tests/debug_reach.py). 그보다 높을 때만 올린다."""
    return float(np.clip(z - 1.2, 0.0, 0.34)) if z > 1.3 else 0.0


def _ensure_workspace(w, point):
    """작업 지점이 팔 작업 영역 밖이면 approach(base 이동)·torso 높이로 맞춘다. 그래도 멀면 pre_unreachable."""
    from .nav import Approach

    tq = torso_for(np.asarray(point)[2])
    if abs(tq - w.R.torso_q) > 0.03:
        w.R.set_torso(tq)

    p_b = w.R.world_to_base(np.asarray(point))
    if abs(p_b[1]) > 0.3 or p_b[0] > 0.75 or p_b[0] < 0.36:
        Approach(w)(point=np.asarray(point))
    d = np.linalg.norm(np.asarray(point)[:2] - w.R.base_pos[:2])
    if d > REACH:
        raise SkillFailure("pre_unreachable", f"{d:.2f}m from base")


def travel_height(w, pts, want, ignore=()):
    """pts(xy 목록) 위를 지날 높이: want 이하로, 각 점 위 천장 - HAND_H 이하."""
    caps = [w.ceiling(p[:2], z0, ignore_objs=ignore) - HAND_H for p, z0 in pts]
    return min([want] + caps)


def holding(w):
    return w.R.gripper_width > 0.004 and w.R.grip > 0


@skill("pick")
class Pick(Skill):
    """top-down grasp. obj: env.objects 키."""

    retries = 2

    def precondition(self, w, obj, **kw):
        if obj not in w.env.objects and obj not in w.names("body", obj):
            raise SkillFailure("pre_unknown_obj", obj)
        _ensure_workspace(w, w.obj_pos(obj))

    def grasp_plan(self, w, obj, mode="center"):
        M = w.obj_mat(obj)
        hs = w.obj_half_size(obj)
        lo, hi = w.obj_aabb(obj)
        center = (lo + hi) / 2  # bbox 중심 (body 원점과 다를 수 있음)
        axes = [(M[:, i], hs[i]) for i in range(3) if abs(M[2, i]) < 0.7]
        if len(axes) < 2:
            axes = [(np.array([1.0, 0, 0]), hs[0]), (np.array([0, 1.0, 0]), hs[1])]
        axes.sort(key=lambda a: a[1])
        height = hi[2] - lo[2]
        if mode == "rim":
            # 넓은 열린 그릇(머그·볼): 로봇 쪽 가장자리 벽을 집는다. 손가락 축 = 반지름 방향
            to_robot = w.R.base_pos[:2] - center[:2]
            to_robot /= np.linalg.norm(to_robot) + 1e-9
            r = float(np.mean([a[1] for a in axes]))
            xy = center[:2] + to_robot * (r - 0.012)
            return xy, hi[2] - 0.025, np.r_[to_robot, 0.0], 0.01, hi[2]
        if mode == "handle":
            # 냄비·팬 손잡이: 긴 축의 끝(bbox 중심이 body 원점에서 치우친 쪽)을 손잡이 폭 방향으로 잡는다
            long_ax, long_half = axes[-1]
            d = np.dot(center[:2] - w.obj_pos(obj)[:2], long_ax[:2])
            u = np.r_[long_ax[:2] * (1 if d >= 0 else -1), 0.0]
            u /= np.linalg.norm(u) + 1e-9
            p = center + u * (long_half - 0.04)
            top_h = w.floor_below(p[:2], hi[2] + 0.05)  # 손잡이 윗면
            return p[:2], top_h - 0.012, np.r_[-u[1], u[0], 0.0], 0.015, hi[2]
        ax, half = axes[0] if self.attempt == 0 or 2 * axes[1][1] > GRIPPER_MAX_W else axes[1]
        if height < 0.14:  # 낮은 물체(과일·고기 등)는 가운데(가장 넓은) 높이에서 잡아야 덜 미끄러진다
            grasp_z = max(lo[2] + 0.012, min(lo[2] + height * 0.5, hi[2] - 0.015))
        else:  # 키 큰 물체는 윗부분
            grasp_z = hi[2] - 0.04
        # 기울어진 물체(손잡이가 들린 주걱 등): 잡는 지점 바로 위 실제 표면보다 높으면 허공을 잡는다
        surf = w.floor_below(center[:2], hi[2] + 0.05)  # 물체 포함 첫 표면
        if surf > lo[2]:
            grasp_z = min(grasp_z, surf - 0.012)
        # 손가락이 내려갈 자리(물체 양옆)에 다른 것(토스터 슬롯, 그릇 벽 등)이 있으면 그 위에서 잡는다
        ax_h = np.r_[ax[:2], 0.0] / (np.linalg.norm(ax[:2]) + 1e-9)
        perp = np.r_[-ax_h[1], ax_h[0], 0.0]
        floor = -1.0
        for sgn in (-1, 1):
            for t in (-0.01, 0.0, 0.01):
                p = center + ax_h * sgn * (half + 0.012) + perp * t
                floor = max(floor, w.floor_below(p[:2], hi[2] + 0.05, ignore_objs=(obj,)))
        fingertip = 0.008  # grip site에서 손끝까지 대략 여유
        thin = height < 0.03  # 주걱·칼 손잡이처럼 얇고 납작한 물체: 손끝이 바닥에 거의 닿게 내려가야 잡힌다
        grasp_z = max(grasp_z, floor + (0.009 if thin else 0.012 + fingertip))
        if grasp_z > hi[2] - 0.01:
            grasp_z = hi[2] - 0.01
        return center[:2], grasp_z, ax, half, hi[2]

    def front_plan(self, w, obj):
        """앞에서 수평으로 들어가 잡을 계획: (접근 방향 a, 손가락 축 f, 잡는 점 g, 손가락 방향 폭)."""
        R = w.R
        lo, hi = w.obj_aabb(obj)
        c = (lo + hi) / 2
        a = np.r_[c[:2] - R.base_pos[:2], 0.0]
        a /= np.linalg.norm(a) + 1e-9
        f = np.array([-a[1], a[0], 0.0])
        P = w.obj_bbox(obj)
        width = float(np.ptp(P @ f))
        floor = w.floor_below(c[:2], lo[2] + 0.02, ignore_objs=(obj,))
        gz = max(c[2], floor + 0.018)  # 손가락이 선반 바닥에 걸리지 않을 높이
        return a, f, np.r_[c[:2], gz], width

    def overhead_blocked(self, w, obj):
        lo, hi = w.obj_aabb(obj)
        c = (lo + hi) / 2
        return w.ceiling(c[:2], hi[2] + 0.01, ignore_objs=(obj,)) - hi[2] < HAND_H + 0.05

    def content_front(self, w, obj, **kw):
        """위가 막힌 칸(벽장·냉장고 선반) 안의 물체: 수평으로 들어가 잡고, 조금 들어 수평으로 빼낸다."""
        R = w.R
        a, f, g, width = self.front_plan(w, obj)
        if width > GRIPPER_MAX_W + 0.005:
            raise SkillFailure("too_wide", f"front grasp width {width:.3f}")
        mat = np.stack([f, np.cross(a, f), a], axis=1)
        lo, hi = w.obj_aabb(obj)
        depth = float(np.ptp(w.obj_bbox(obj) @ a)) / 2
        out = g - a * (depth + 0.22)
        R.gripper(False, n=5)
        up = np.r_[R.eef_pos[:2], max(R.eef_pos[2], g[2])]
        R.move_ee_path([up, np.r_[out[:2], up[2]], out], mat, step_len=0.03)
        if np.linalg.norm(out - R.eef_pos) > 0.04:
            raise SkillFailure("approach", f"front pregrasp not reached: err {np.linalg.norm(out - R.eef_pos):.3f}m, "
                               f"base-frame {np.round(R.world_to_base(out), 2)}")
        R.move_ee_path([g], mat, step_len=0.01, tol=0.008)
        R.gripper(True, n=12)
        if R.gripper_width < 0.004:
            raise SkillFailure("grasp_miss", "gripper closed on nothing (front)")
        R.idle(3, arm=R.arm_cmd(R.eef_pos, mat), grip=1.0)
        room = w.ceiling(g[:2], hi[2] + 0.005, ignore_objs=(obj,)) - hi[2]
        lift = float(np.clip(room - 0.01, 0.005, 0.03))
        R.move_ee_path([R.eef_pos + np.r_[0, 0, lift]], mat, step_len=0.005, grip=1.0)
        R.move_ee_path([R.eef_pos - a * (depth + 0.25)], mat, step_len=0.01, grip=1.0)
        if not w.grasped(obj):
            raise SkillFailure("grasp_slip", "object dropped while pulling out (front)")
        R.move_ee_path([R.eef_pos + np.r_[0, 0, 0.05]], mat, step_len=0.01, grip=1.0)

    def grasp_candidates(self, w, obj, mode):
        """(잡는 점 g, 자세 mat) 후보: 손가락 축 두 방향 × 로봇 쪽 기울기 4단계."""
        xy, gz, ax, half, top = self.grasp_plan(w, obj, mode)
        g = np.r_[xy, gz]
        out = []
        for tilt in (0.0, 0.35, 0.7, 1.0):
            for sgn in (1, -1):
                f = np.r_[ax[:2], 0.0] * sgn
                f /= np.linalg.norm(f) + 1e-9
                h = np.cross(np.array([0, 0, 1.0]), f)
                if np.dot(h[:2], xy - w.R.base_pos[:2]) < 0:
                    h = -h
                a = np.array([0, 0, -1.0]) * np.cos(tilt) + h * np.sin(tilt)
                out.append((g, np.stack([f, np.cross(a, f), a], axis=1), tilt))
        return out, top

    def content_planned(self, w, obj, mode, lift=0.15):
        """충돌 검사 IK로 접근 자세를 고르고, RRT 경로로 pregrasp까지 간 뒤 직선으로 잡는다."""
        from ..planner import ArmPlanner

        R = w.R
        P = ArmPlanner(w)
        P.baseline()
        cands, top = self.grasp_candidates(w, obj, mode)
        bid = w.body_id(obj)
        R.gripper(False, n=5)
        P.baseline()
        found_ik = False
        path = None
        for g, mat, tilt in cands:
            pre = g - mat[:, 2] * 0.08
            P.allowed = set()
            qp = P.ik_free(pre, mat, seeds=4)
            if qp is None:
                continue
            P.allowed = {bid}
            qg = P.ik(g, mat, qp)
            if qg is None or P.in_collision(qg):
                continue
            found_ik = True
            P.allowed = set()
            path = P.plan(P.q_now(), qp, iters=2500)
            if path is not None:
                break
        if not found_ik:
            raise SkillFailure("no_ik", "no collision-free grasp pose")
        if path is None:
            raise SkillFailure("no_path", "no arm path to any pregrasp")
        P.execute(path, grip=-1.0)
        if np.linalg.norm(R.eef_pos - pre) > 0.03:
            raise SkillFailure("approach", f"planned pregrasp not reached: err {np.linalg.norm(R.eef_pos - pre):.3f}")
        R.move_ee_path([g], mat, step_len=0.008, tol=0.008)
        R.gripper(True, n=12)
        if R.gripper_width < 0.004:
            raise SkillFailure("grasp_miss", "gripper closed on nothing (planned)")
        R.idle(3, arm=R.arm_cmd(R.eef_pos, mat), grip=1.0)
        # 짧게 들고(선반 여유만큼) 다시 경로 계획으로 빼낸다
        lo, hi = w.obj_aabb(obj)
        room = w.ceiling(g[:2], hi[2] + 0.005, ignore_objs=(obj,)) - hi[2]
        R.move_ee_path([R.eef_pos + np.r_[0, 0, float(np.clip(room - 0.015, 0.01, 0.05))]], mat, step_len=0.005, grip=1.0)
        back = R.eef_pos - mat[:, 2] * 0.0
        out = R.base_to_world(np.r_[0.35, R.world_to_base(R.eef_pos)[1] * 0.5, R.world_to_base(R.eef_pos)[2]])
        P.baseline()  # 쥔 물체-손 접촉, 물체-선반 접촉은 무시
        P.allowed = {bid}
        ok, why = P.go(out, mat, grip=1.0)
        if not w.grasped(obj):
            raise SkillFailure("grasp_slip", f"object dropped while pulling out (planned, {why})")

    def content(self, w, obj, lift=0.15, mode=None, **kw):
        R = w.R
        if mode is None:
            hs = sorted(w.obj_half_size(obj)[:2])
            hollow = any(k in w.obj_cat(obj) for k in RIM_CATS)
            mode = "rim" if hollow and 2 * hs[0] > GRIPPER_MAX_W else "center"
            # 위가 막힌 칸 안이고 앞에서 잡을 수 있는 폭이면 front (첫 시도), 실패하면 기존 방식(기울인 접근)으로
            if self.attempt == 0 and self.overhead_blocked(w, obj):
                _, _, _, width = self.front_plan(w, obj)
                if width <= GRIPPER_MAX_W + 0.005:
                    mode = "front"
        self.mode = mode
        if mode == "front":
            return self.content_front(w, obj, **kw)
        # 위가 막혔거나 이전 시도에서 손이 못 갔으면: 충돌 검사하는 경로 계획으로 접근
        if mode != "handle" and (getattr(self, "last_code", None) in ("approach", "blocked_overhead")
                                 or (self.attempt == 0 and self.overhead_blocked(w, obj))):
            return self.content_planned(w, obj, mode, lift=lift)
        xy, gz, ax, half, top = self.grasp_plan(w, obj, mode)
        mat = topdown_mat(ax, ref_x=R.eef_mat[:, 0])
        # 위가 막혀 손이 못 내려온 적이 있으면 손가락 축을 중심으로 기울여서(로봇 쪽에서 비스듬히) 접근
        tilt = 0.6 if getattr(self, "last_code", None) in ("approach", "blocked_overhead") else 0.0
        if tilt:
            f = mat[:, 0]
            h = np.cross(np.array([0, 0, 1.0]), f)
            if np.dot(h[:2], xy - R.base_pos[:2]) < 0:
                h = -h
            a = np.array([0, 0, -1.0]) * np.cos(tilt) + h * np.sin(tilt)
            mat = np.stack([f, np.cross(a, f), a], axis=1)
        a = mat[:, 2]
        g = np.r_[xy, gz]
        pre = g - a * (top + 0.06 - gz) / max(-a[2], 0.3)
        want = max(pre[2] + 0.04, min(R.eef_pos[2], top + 0.25))
        safe_z = travel_height(w, [(R.eef_pos, R.eef_pos[2]), (pre[:2], top + 0.02)], want, ignore=(obj,))
        if safe_z < pre[2] - 0.02:
            if not tilt:
                raise SkillFailure("blocked_overhead", f"ceiling too low over object: travel {safe_z:.2f} top {top:.2f}")
            safe_z = pre[2]
        R.gripper(False, n=5)
        R.move_ee_path([np.r_[R.eef_pos[:2], safe_z], np.r_[pre[:2], safe_z]], mat, step_len=0.04)
        R.move_ee(pre, mat, tol=0.01, max_steps=80)
        if np.linalg.norm(pre - R.eef_pos) > 0.035:
            d_base = np.linalg.norm(xy - R.base_pos[:2])
            raise SkillFailure("approach", f"pregrasp not reached (tilt {tilt}): err {np.linalg.norm(pre - R.eef_pos):.3f}m, "
                               f"obj {d_base:.2f}m from base, z {pre[2]:.2f}, base-frame {np.round(R.world_to_base(pre), 2)}")
        R.move_ee_path([g], mat, step_len=0.01, tol=0.008)
        R.gripper(True, n=12)
        if R.gripper_width < 0.004:
            raise SkillFailure("grasp_miss", f"gripper closed on nothing ({mode})")
        R.idle(3, arm=R.arm_cmd(R.eef_pos, mat), grip=1.0)
        R.move_ee_path([np.r_[R.eef_pos[:2], gz + lift]], mat, step_len=0.01)
        if not w.grasped(obj):
            raise SkillFailure("grasp_slip", f"object dropped while lifting ({mode})")

    def effect(self, w, obj, **kw):
        return w.grasped(obj)

    def on_except(self, w, err, obj, **kw):
        R = w.R
        self.last_code = err.code
        R.gripper(False, n=8)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.10]), max_steps=40)
        return True


def obj_touching_env(w, obj):
    """obj가 gripper 아닌 다른 geom과 닿아 있는지."""
    sim = w.sim
    if obj in w.env.objects:
        o = w.env.objects[obj]
        ogeoms = {sim.model.geom_name2id(g) for g in o.contact_geoms if g in sim.model._geom_name2id}
    else:
        ogeoms = set(w.body_geoms(obj))
    grip = w.R.robot.gripper["right"]
    ggeoms = {sim.model.geom_name2id(g) for g in grip.contact_geoms if g in sim.model._geom_name2id}
    for i in range(sim.data.ncon):
        c = sim.data.contact[i]
        a, b = c.geom1, c.geom2
        if a in ogeoms and b not in ogeoms and b not in ggeoms:
            return True
        if b in ogeoms and a not in ogeoms and a not in ggeoms:
            return True
    return False


@skill("place")
class Place(Skill):
    """잡은 obj를 target(world xyz: 물체 body가 갈 xy, 놓일 바닥 높이 z)에 내려놓는다.

    mode="top": 위에서 내려놓기.  mode="front": 앞에서 수평으로 밀어 넣기(캐비닛·냉장고 칸 등 천장이 있는 곳).
    front 모드는 entry(fixture 안쪽 방향 단위벡터)가 필요하다.
    """

    retries = 1  # 옮기다 떨어뜨리면 on_except에서 다시 집고 한 번 더

    def precondition(self, w, obj, target, **kw):
        if not w.grasped(obj):
            raise SkillFailure("pre_not_holding", obj)
        _ensure_workspace(w, target)
        if not w.grasped(obj):  # base 이동 중 떨어뜨림 → except에서 다시 집기
            raise SkillFailure("dropped", "object slipped out while moving the base")

    def on_except(self, w, err, obj, target, **kw):
        if err.code != "dropped":
            return False
        R = w.R
        R.gripper(False, n=8)
        R.move_ee(R.eef_pos + np.array([0, 0, 0.08]), max_steps=30)
        try:
            Pick(w)(obj=obj)
        except SkillFailure:
            return False
        return True

    def content(self, w, obj, target, mode="top", entry=None, clearance=0.08, drop=0.015, entry_dz=0.035, level=False, **kw):
        R = w.R
        target = np.asarray(target, float)
        lo, hi = w.obj_aabb(obj)
        below = R.eef_pos[2] - lo[2]  # eef에서 물체 바닥까지
        if below > 0.4 or not w.grasped(obj):  # 물체가 이미 손에서 빠져 바닥 쪽에 있음
            raise SkillFailure("dropped", f"object not in hand (eef-to-bottom {below:.2f} m)")
        # keep_orient: 비스듬히 잡은 물체(막힌 칸에서 꺼낸 머그 등)는 손 자세를 바꾸지 않고 그대로 내려놓는다
        mat = R.eef_mat.copy() if kw.get("keep_orient") else topdown_mat(R.eef_mat[:, 0], ref_x=R.eef_mat[:, 0])
        if level:
            # 쥔 물체가 기울어 있으면 손목을 돌려 물체를 똑바로 세운다 (rim grasp한 머그 등)
            Mo = w.obj_mat(obj)
            yaw = np.arctan2(Mo[1, 0], Mo[0, 0])
            c, s_ = np.cos(yaw), np.sin(yaw)
            Mo_des = np.array([[c, -s_, 0], [s_, c, 0], [0, 0, 1.0]])
            mat = Mo_des @ Mo.T @ R.eef_mat
            R.move_ee(R.eef_pos, mat, tol=0.01, rot_tol=0.03, max_steps=40, grip=1.0)
            lo, hi = w.obj_aabb(obj)
            below = R.eef_pos[2] - lo[2]
        off = (w.obj_pos(obj) - R.eef_pos)[:2]  # body가 target에 오도록 eef 위치 보정
        exy = target[:2] - off
        if mode == "top":
            want = max(target[2] + below + clearance, min(R.eef_pos[2], target[2] + below + 0.25))
            travel_z = travel_height(w, [(R.eef_pos, R.eef_pos[2]), (exy, target[2] + 0.02)], want, ignore=(obj,))
            travel_z = max(travel_z, target[2] + below + 0.03)
            R.move_ee_path([np.r_[R.eef_pos[:2], travel_z], np.r_[exy, travel_z]], mat, step_len=0.02, grip=1.0, speed=0.6,
                           stop_fn=lambda: not w.grasped(obj))
            if not w.grasped(obj):
                raise SkillFailure("dropped", "object slipped out while carrying")
            # 물체 위치로 직접 미세 정렬 (팔 추종 오차·쥔 위치 오차 보정)
            for _ in range(4):
                d = target[:2] - w.obj_pos(obj)[:2]
                if np.linalg.norm(d) < 0.006:
                    break
                exy = R.eef_pos[:2] + d
                R.move_ee(np.r_[exy, travel_z], mat, tol=0.004, max_steps=30, grip=1.0)
            e1 = np.linalg.norm(w.obj_pos(obj)[:2] - target[:2])
            held_above = bool(w.grasped(obj))
            R.move_ee_path([np.r_[exy, target[2] + below + drop]], mat, step_len=0.008, grip=1.0,
                           stop_fn=lambda: obj_touching_env(w, obj))
            self.dbg = dict(held_above=held_above, travel_z=round(float(travel_z), 3), err_above=round(float(e1), 3),
                            err_down=round(float(np.linalg.norm(R.eef_pos[:2] - exy)), 3),
                            z_left=round(float(R.eef_pos[2] - (target[2] + below + drop)), 3),
                            obj_off=round(float(np.linalg.norm(w.obj_pos(obj)[:2] - target[:2])), 3))
        else:
            e = np.r_[np.asarray(entry, float)[:2], 0.0]
            e /= np.linalg.norm(e)
            z = target[2] + below + entry_dz  # 앞 턱(lip)을 넘을 여유
            if z > 1.3:  # 높은 곳(벽장)은 torso를 올려서 팔꿈치가 문틀에 걸리지 않게
                R.set_torso(float(np.clip(z - 1.15, 0.0, 0.34)))
            outside = np.r_[exy, z] - e * 0.35
            up = np.r_[R.eef_pos[:2], max(R.eef_pos[2], z)]
            R.move_ee_path([up, np.r_[outside[:2], max(up[2], z)], outside], mat, step_len=0.03, grip=1.0,
                           stop_fn=lambda: not w.grasped(obj))
            if not w.grasped(obj):
                raise SkillFailure("dropped", "object slipped out while carrying")
            R.move_ee_path([np.r_[exy, z]], mat, step_len=0.01, grip=1.0)
            e1 = np.linalg.norm(R.eef_pos[:2] - exy)
            R.move_ee_path([np.r_[exy, target[2] + below + drop]], mat, step_len=0.008, grip=1.0,
                           stop_fn=lambda: obj_touching_env(w, obj))
        if kw.get("debug_hold"):
            raise SkillFailure("debug_hold", "stopped before release")
        if mode != "top":
            self.dbg = dict(tgt_base=np.round(R.world_to_base(np.r_[exy, z]), 2).tolist(), torso=round(R.torso_q, 2), err_in=round(float(e1), 3), obj_off=round(float(np.linalg.norm(w.obj_pos(obj)[:2] - target[:2])), 3),
                            held=bool(w.grasped(obj)))
        R.gripper(False, n=10)
        if mode == "top":
            R.move_ee_path([R.eef_pos + np.array([0, 0, 0.12])], step_len=0.02)
        else:
            R.move_ee_path([R.eef_pos + np.array([0, 0, 0.02]), R.eef_pos + np.array([0, 0, 0.02]) - e * 0.35],
                           step_len=0.02)

    def effect(self, w, obj, target, tol=0.06, **kw):
        if w.grasped(obj):
            return False
        d = np.linalg.norm(w.obj_pos(obj)[:2] - np.asarray(target)[:2])
        if d > tol:
            raise SkillFailure("misplaced", f"object {d:.3f} m from target xy; {getattr(self, 'dbg', '')}")
        return True


@skill("retreat")
class Retreat(Skill):
    """놓은 뒤 손을 물체에서 떼기: 조금 올리고(천장 고려) base 쪽으로 수평으로 뺀 뒤 home 자세."""

    retries = 0

    def content(self, w, away_from=None, dist=0.30, **kw):
        R = w.R
        top = min(R.eef_pos[2] + 0.06, w.ceiling(R.eef_pos[:2], R.eef_pos[2]) - HAND_H)
        R.move_ee_path([np.r_[R.eef_pos[:2], max(top, R.eef_pos[2])]], step_len=0.02, max_steps=40)
        to_base = R.base_pos[:2] - R.eef_pos[:2]
        n = np.linalg.norm(to_base)
        back = R.eef_pos[:2] + to_base / max(n, 1e-6) * min(dist, max(n - 0.15, 0.0))
        R.move_ee_path([np.r_[back, R.eef_pos[2]]], step_len=0.03, max_steps=60)
        R.go_home(max_steps=80)

    def effect(self, w, away_from=None, **kw):
        if away_from is None:
            return True
        return np.linalg.norm(w.R.eef_pos - w.obj_pos(away_from)) > 0.25
