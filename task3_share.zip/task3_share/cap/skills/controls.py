"""소형 가전 조작 skill: turn_knob, turn_lever, rotate_spout, press_button, push_lever.

공통 원리 (GT 폐루프)
- 회전형(knob / sink handle / spout): 부품을 잡고, GT joint 축(anchor, axis)을 중심으로 eef pose 전체를
  강체 회전시킨다. 목표 회전각은 "현재 joint 값 + lead" 로 매 step 갱신 → joint가 안 따라오면(미끄러짐) 멈춤 감지.
  손목(joint7) 한계에 걸리면 놓고 다시 잡는다(regrasp).
- 버튼: 버튼 geom의 법선(가장 얇은 축) 방향으로 닫힌 손가락 끝을 밀어 넣고, 상태가 바뀌면 바로 물러난다.
- 레버(토스터 lever, 전기주전자 switch): 손가락 끝을 레버 위에 올리고 joint 방향(아래)으로 민다.
"""
import numpy as np
import robosuite.utils.transform_utils as T

from ..robot import SkillFailure
from ..skill import Skill, skill

Q7_LIM = 2.897
Q7_MARGIN = 0.2
Q7_HOME = 0.70  # 초기(home) 자세의 joint7 값
REACH = 0.95
PRE_TOL = 0.045  # 접근 시작점 허용 오차 (최종 접촉점은 따로 확인)


# ---------------------------------------------------------------- 기하 헬퍼
def unit(v):
    v = np.asarray(v, float)
    return v / (np.linalg.norm(v) + 1e-9)


def rotmat(axis, ang):
    a = unit(axis)
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * K @ K


def frame(z, x):
    """eef 자세: z=접근 방향, x=손가락 축."""
    z = unit(z)
    x = np.asarray(x, float) - np.dot(x, z) * z
    if np.linalg.norm(x) < 1e-6:
        x = np.cross(z, [0, 0, 1.0]) if abs(z[2]) < 0.9 else np.array([1.0, 0, 0])
    x = unit(x)
    return np.stack([x, np.cross(z, x), z], axis=1)


def geom_info(w, name):
    m, d = w.sim.model, w.sim.data
    g = m.geom_name2id(name)
    return np.array(d.geom_xpos[g]), np.array(d.geom_xmat[g]).reshape(3, 3), np.array(m.geom_size[g]), int(m.geom_type[g])


def geom_half_extents(size, gtype):
    """box: size, cylinder/capsule: (r, r, h)."""
    if gtype in (3, 5):
        return np.array([size[0], size[0], size[1]])
    if gtype == 2:
        return np.array([size[0]] * 3)
    return np.array(size[:3])


def q7(w):
    idx = w.R.robot._ref_joint_pos_indexes[6]
    return float(w.sim.data.qpos[idx])


def touching(w, geom):
    return w.env.check_contact(w.R.robot.gripper["right"], geom)


def has_geom(w, name):
    try:
        w.sim.model.geom_name2id(name)
        return True
    except Exception:  # noqa: BLE001
        return False


def has_joint(w, name):
    return name in w.sim.model.joint_names


def retreat(w, back_dir, dist=0.10, up=0.0, grip_open=True, n_open=6):
    """그리퍼를 열고 back_dir 방향으로 물러난다."""
    R = w.R
    if grip_open:
        R.gripper(False, n=n_open)
    tgt = R.eef_pos + unit(back_dir) * dist + np.array([0, 0, up])
    R.move_ee_path([tgt], R.eef_mat.copy(), step_len=0.02, max_steps=60)


def align_base(w, target, fwd_min=0.50, fwd_max=0.85, lat_tol=0.15):
    """target이 팔이 편하게 닿는 범위(base 기준 전방 fwd_min~fwd_max, 좌우 lat_tol)를 벗어나면
    base를 평행이동 (yaw 유지). 너무 가까우면 뒤로 물러난다 (팔을 접어 접근하면 관절 한계에 걸림)."""
    R = w.R
    tb = R.world_to_base(target)
    dx = dy = 0.0
    if tb[0] < fwd_min:
        dx = tb[0] - fwd_min
    elif tb[0] > fwd_max:
        dx = min(tb[0] - fwd_max, 0.10)
    if abs(tb[1]) > lat_tol:
        dy = tb[1] - np.sign(tb[1]) * 0.05
    if abs(dx) < 0.02 and abs(dy) < 0.02:
        return False
    R.go_home(max_steps=80)
    goal = R.base_pos[:2] + R.base_mat[:2, :2] @ np.array([dx, dy])
    R.move_base(goal, R.base_yaw, max_steps=400)
    R.log("align_base", f"dx {dx:.2f} dy {dy:.2f}")
    return True


def torso_q(w):
    return float(w.sim.data.qpos[w.sim.model.get_joint_qpos_addr("mobilebase0_joint_torso_height")])


def set_torso(w, h, max_steps=40):
    """몸통(torso) 높이 조절 (0~0.34). 높은 곳을 위에서 접근할 때 사용."""
    R = w.R
    h = float(np.clip(h, 0.0, 0.33))
    for _ in range(max_steps):
        e = h - torso_q(w)
        if abs(e) < 0.01:
            break
        R.step(arm=R.arm_cmd(R.eef_pos, R.eef_mat), torso=float(np.clip(e * 20, -1, 1)))


def open_to(w, width, n_max=20):
    """그리퍼를 width(m) 정도만 연다 (닫았다가 조금씩 연 뒤 유지)."""
    R = w.R
    width = min(width, 0.078)
    if width > 0.07:
        R.gripper(False, n=10)
        return
    R.gripper(True, n=8)
    for _ in range(n_max):
        if R.gripper_width >= width:
            break
        R.step(arm=R.arm_cmd(R.eef_pos, R.eef_mat), grip=-1.0)
    R.step(arm=R.arm_cmd(R.eef_pos, R.eef_mat), grip=0.0)


def move_to_pre(w, pre, mat, max_steps=150, via_back=0.0):
    """현재 위치에서 pre(접근 시작점)로 직선 경로.
    via_back>0이면 pre 높이에서 접근 방향 반대(수평)로 via_back 떨어진 점을 먼저 거친다
    (spout 팔처럼 위에서 앞으로 튀어나온 물체 아래로 들어가기 위함)."""
    R = w.R
    if via_back > 0:
        zh = np.array([mat[0, 2], mat[1, 2], 0.0])
        if np.linalg.norm(zh) > 0.3:
            via = pre - unit(zh) * via_back
            if np.dot(R.eef_pos - pre, unit(zh)) < -via_back * 0.5:  # 아직 via보다 로봇 쪽일 때만
                R.move_ee_path([via], mat, step_len=0.03, max_steps=max_steps)
    R.move_ee_path([pre], mat, step_len=0.03, max_steps=max_steps)
    R.move_ee(pre, mat, tol=0.012, rot_tol=0.12, max_steps=80)
    if np.linalg.norm(pre - R.eef_pos) < PRE_TOL:
        servo(w, pre, mat, max_steps=40)  # 정밀 정렬
        return True
    return False


def straight_in(w, target, mat, step=0.004, max_steps=120, stop_fn=None, grip=None, ki=0.15):
    """현재 위치에서 target까지 직선을 따라 천천히 (매 step 목표를 step만큼 전진).
    OSC의 정상상태 오차(특히 높이 1~2 cm)를 적분항으로 보정한다."""
    R = w.R
    a = R.eef_pos.copy()
    L = np.linalg.norm(target - a)
    n = max(1, int(np.ceil(L / step)))
    integ = np.zeros(3)
    for i in range(max_steps):
        k = min(n, i + 1)
        tgt = a + (target - a) * k / n
        if stop_fn is not None and stop_fn():
            return True
        err = tgt - R.eef_pos
        integ = np.clip(integ + ki * err, -0.03, 0.03)
        R.step(arm=R.arm_cmd(tgt + integ, mat, max_dpos=0.5), grip=grip)
        if k == n and np.linalg.norm(target - R.eef_pos) < 0.004:
            return True
    return False


def servo(w, target, mat, max_steps=40, tol=0.003, ki=0.2, grip=None):
    """한 점에 정밀 정렬 (적분항 포함)."""
    R = w.R
    integ = np.zeros(3)
    for _ in range(max_steps):
        err = target - R.eef_pos
        if np.linalg.norm(err) < tol:
            return True
        integ = np.clip(integ + ki * err, -0.03, 0.03)
        R.step(arm=R.arm_cmd(target + integ, mat, max_dpos=0.5), grip=grip)
    return np.linalg.norm(target - R.eef_pos) < tol * 2


# ---------------------------------------------------------------- grasp & rotate 핵심
def natural_mat(w, z):
    """home 자세에서 접근축만 z로 최소 회전한 자세 (손목 비틀림 최소)."""
    R = w.R
    Mh = R.base_mat @ R.home_mat_b
    zh = Mh[:, 2]
    z = unit(z)
    ax = np.cross(zh, z)
    s_, c_ = np.linalg.norm(ax), float(np.dot(zh, z))
    if s_ < 1e-6:
        return Mh if c_ > 0 else rotmat(Mh[:, 0], np.pi) @ Mh
    return rotmat(ax, np.arctan2(s_, c_)) @ Mh


def choose_mat(w, z, f, need_q7=0.0):
    """손가락 축 f/-f 중 선택. need_q7: 잡은 뒤 필요한 q7 변화량(부호 포함).
    home 자세 대비 손목 회전량으로 q7을 예측하고, 회전 여유가 있으면서 덜 비트는 쪽."""
    N = natural_mat(w, z)
    q7h = Q7_HOME
    best = None
    for sgn in (1.0, -1.0):
        M = frame(z, sgn * np.asarray(f, float))
        ang = np.arctan2(np.dot(np.cross(N[:, 0], M[:, 0]), M[:, 2]), np.dot(N[:, 0], M[:, 0]))
        pred = q7h + ang
        end = pred + need_q7
        lim = Q7_LIM - Q7_MARGIN
        over = max(0.0, abs(pred) - lim) * 3 + max(0.0, abs(end) - lim)
        score = -over - 0.2 * abs(ang)
        if best is None or score > best[0]:
            best = (score, M, pred)
    return best[1], best[2]


def grasp_and_rotate(w, joint, grasp_pt, z_dir, f_dir, q_goal, done, lead=0.25, max_steps=300,
                     pre_dist=0.08, close_n=14, use_q7=True, tag="rot", open_w=0.04, max_slip=0.6, omega=None, stall_n=30, via_back=0.0):
    """부품을 잡고 joint 축 둘레로 회전. 한 번의 grasp 구간만 수행. 반환: 종료 사유."""
    R = w.R
    anchor, a = w.joint_anchor_axis(joint)
    mat = frame(z_dir, f_dir)
    q_start = w.joint_q(joint)
    sgn = np.sign(q_goal - q_start)
    zq = float(np.dot(a, unit(z_dir)))  # 회전 1 rad 당 q7 변화량
    room = np.inf
    mat, pred7 = choose_mat(w, z_dir, f_dir, need_q7=zq * (q_goal - q_start) if use_q7 else 0.0)
    if use_q7 and abs(zq) > 0.3:
        lim = Q7_LIM - Q7_MARGIN
        room7 = (lim - pred7) if zq * sgn > 0 else (pred7 + lim)
        room = max(room7, 0.05) / abs(zq)
    pre = grasp_pt - unit(z_dir) * pre_dist
    open_to(w, open_w)
    if not move_to_pre(w, pre, mat, via_back=via_back):
        raise SkillFailure("approach", f"{tag}: pregrasp not reached ({np.linalg.norm(pre - R.eef_pos):.3f})")
    straight_in(w, grasp_pt, mat, step=0.005, max_steps=80)
    if np.linalg.norm(grasp_pt - R.eef_pos) > 0.015:
        R.move_ee(grasp_pt, mat, tol=0.006, max_steps=30)
    if np.linalg.norm(grasp_pt - R.eef_pos) > 0.02:
        e = np.linalg.norm(grasp_pt - R.eef_pos)
        retreat(w, -unit(z_dir), dist=0.07, grip_open=False)
        raise SkillFailure("approach", f"{tag}: grasp point not reached ({e:.3f})")
    R.gripper(True, n=close_n)
    if R.gripper_width < 0.002:
        R.log(tag, "grasp_miss")
        open_to(w, open_w)
        retreat(w, -unit(z_dir), dist=0.07, grip_open=False)
        return "miss"
    q0 = w.joint_q(joint)
    P0, M0 = R.eef_pos.copy(), R.eef_mat.copy()
    q7_0 = q7(w)
    ramp = 0.0
    last_chk, last_q = R.steps, q0
    reason = "steps"
    for i in range(max_steps):
        q = w.joint_q(joint)
        if done(q):
            reason = "done"
            break
        rem = q_goal - q
        if np.sign(rem) != sgn:
            reason = "done"
            break
        if use_q7 and abs(zq) > 0.3:
            # 손목 한계 근처면 regrasp
            if abs(q7(w)) > Q7_LIM - Q7_MARGIN and np.sign(q7(w) - q7_0) == np.sign(zq * sgn):
                reason = "wrist_limit"
                break
        rel = R.eef_mat @ M0.T
        e_rot = float(np.dot(T.quat2axisangle(T.mat2quat(rel)), a))  # 잡은 뒤 eef가 a 둘레로 돈 각
        slip = sgn * (e_rot - (q - q0))
        if slip > max_slip:
            reason = "slip"
            break
        if abs(e_rot) > room - 0.05:
            reason = "wrist_limit"
            break
        # eef 자신의 현재 각 기준으로 lead만큼 앞서 명령 → OSC 회전 오차가 일정하게 유지되어 토크가 계속 걸림
        if omega is None:
            th = e_rot + sgn * min(lead, abs(rem) + 0.1)
        else:
            # 느린 ramp: knob 관성(armature)이 큰 경우 급가속하면 손가락이 벌어지며 미끄러진다
            ramp = ramp + sgn * omega
            lim_ = (q - q0) + sgn * lead
            ramp = min(ramp, lim_) if sgn > 0 else max(ramp, lim_)
            th = ramp
        if abs(th) > room:
            th = np.sign(th) * room
        Rm = rotmat(a, th)
        pos = anchor + Rm @ (P0 - anchor)
        R.step(arm=R.arm_cmd(pos, Rm @ M0), grip=1.0)
        if R.steps - last_chk >= stall_n:
            if abs(w.joint_q(joint) - last_q) < 0.02:
                reason = "stall"
                break
            last_chk, last_q = R.steps, w.joint_q(joint)
    R.log(tag, f"seg {reason} q {q0:.2f}->{w.joint_q(joint):.2f}")
    open_to(w, open_w)
    retreat(w, -unit(z_dir), dist=0.07, grip_open=False)
    return reason


def tab_frame(w, geom, axis, neighbors=()):
    """knob 손잡이(tab) geom: (중심, 축 방향 깊이, 손가락 축, 손가락 방향 반폭).
    손가락 축은 기본적으로 얇은 방향. 단, 손바닥(손가락 축 방향으로 넓음)이 이웃 knob 쪽으로 향하면
    tab의 긴 방향 양 끝을 집는다 (그리퍼 최대 벌림 안일 때)."""
    p, M, size, gt = geom_info(w, geom)
    he = geom_half_extents(size, gt)
    al = [abs(np.dot(M[:, i], axis)) for i in range(3)]
    dep = int(np.argmax(al))
    others = sorted([i for i in range(3) if i != dep], key=lambda i: he[i])
    thin, long_ = others
    choice = thin
    nb = [np.asarray(q) - p for q in neighbors if 0.02 < np.linalg.norm(np.asarray(q) - p) < 0.16]
    if False and nb and 2 * he[long_] + 0.025 < 0.075:  # (비활성: 손가락 축 둘레로 기울이는 방식으로 대체)
        d = min(nb, key=np.linalg.norm)
        d = unit(d - np.dot(d, axis) * axis)
        if abs(np.dot(M[:, thin], d)) > abs(np.dot(M[:, long_], d)) + 0.2:
            choice = long_
    return p, he[dep], M[:, choice], he[choice]


def tilt_about(w, z_axis, f, tilt):
    """접근축 z_axis(회전축과 평행)를 손가락 축 f 둘레로 tilt만큼 기울인다.
    f가 수평이면 아래로(pitch), f가 수직이면 로봇 몸 쪽으로(yaw). 손가락 끝 두 개가 면에서 같은 거리를 유지."""
    z_axis, f = unit(z_axis), unit(f)
    f = unit(f - np.dot(f, z_axis) * z_axis)
    best = None
    for sg in (1.0, -1.0):
        z = rotmat(f, sg * tilt) @ z_axis
        if abs(f[2]) < 0.7:
            score = -z[2]  # 아래로
        else:
            score = float(np.dot(w.R.base_mat[:, 0], z))  # base 정면 방향과 가까운 쪽
        if best is None or score > best[0]:
            best = (score, z)
    return best[1]


def ray_dist(w, pnt, vec):
    """충돌 geom(group 0)까지 광선 거리 (없으면 inf)."""
    import mujoco

    gid = np.array([-1], dtype=np.int32)
    grp = np.array([1, 0, 0, 0, 0, 0], dtype=np.uint8)
    d = mujoco.mj_ray(w.sim.model._model, w.sim.data._data, np.asarray(pnt, float), unit(vec), grp, 1, -1, gid)
    return np.inf if d < 0 else float(d)


def palm_blocked(w, p, n, f, depth=0.12, protrude=0.03, spans=(0.0, 0.03, 0.06, 0.09), thick=(-0.035, 0.0, 0.035)):
    """접촉점 p, 바깥 법선 n, 손가락 축 f 일 때 손바닥 영역(폭 ±9cm, 두께 ±3cm) 샘플 광선이
    protrude 이상 튀어나온 물체에 막히는 정도 (작을수록 좋음)."""
    cost = 0.0
    g = unit(np.cross(n, f))
    for s_ in spans:
        for sg in ((1, -1) if s_ > 0 else (1,)):
            for t_ in thick:
                if s_ == 0 and t_ == 0:
                    continue
                q = p + n * depth + f * s_ * sg + g * t_
                d = ray_dist(w, q, -n)
                if d < depth - protrude:
                    cost += (depth - protrude - d) + 0.01
    return cost


def best_finger_axis(w, p, n, f0, n_cand=4):
    """f0을 n 둘레로 0/45/90/135도 돌린 후보 중 손바닥이 덜 막히는 축."""
    best = None
    for k in range(n_cand):
        f = rotmat(n, k * np.pi / n_cand) @ f0
        c = palm_blocked(w, p, n, f) + 0.002 * k
        if best is None or c < best[0]:
            best = (c, f)
    return best[1]


def best_press_pose(w, p, n, f0, tilts=(0, 30, 50), n_cand=4):
    """누르는 접근 방향 z(= -n을 아래로 tilt 기울임)와 손가락 축 f 후보 중 광선으로 덜 막히는 것.
    반환 (cost, z, f). 바깥 법선 n이 수평에 가까울 때만 기울인다."""
    out = []
    horiz = abs(n[2]) < 0.5
    for tdeg in (tilts if horiz else (0,)):
        b = np.deg2rad(tdeg)
        if tdeg:
            nh = unit([n[0], n[1], 0.0])
            nn = unit(nh * np.cos(b) + np.array([0, 0, 1.0]) * np.sin(b))  # 손은 위쪽 뒤에서
        else:
            nn = n
        for k in range(n_cand):
            f = rotmat(nn, k * np.pi / n_cand) @ (f0 - np.dot(f0, nn) * nn)
            f = unit(f)
            # 중간 높이(어깨 높이 근처)에서 수평으로 곧게 뻗으면 joint4/6 한계 → 약간 기울인 자세 선호
            pref = (0.02 if tdeg == 0 else (0.0 if tdeg == 30 else 0.01)) if p[2] < 1.35 else 0.0005 * tdeg
            c = palm_blocked(w, p, nn, f) + 0.002 * k + pref
            out.append((c, -nn, f))
    out.sort(key=lambda x: x[0])
    return out[0]


def neighbor_parts(w, fx, geom, key="knob"):
    """같은 fixture의 다른 knob/버튼 geom 위치."""
    p = fx.naming_prefix
    out = []
    for n in w.names("geom", p):
        if n != geom and key in n[len(p):] and n.endswith("_main"):
            out.append(w.geom_pos(n))
    return out


def approach_dir_for_axis(w, anchor, axis, tilt=None):
    """회전축과 평행하고 로봇 쪽에서 부품 쪽으로 향하는 접근 방향.
    축이 수평이면 아래로 tilt(rad)만큼 기울인다: 수평으로 곧게 뻗으면 손목(joint6) 한계에 걸린다."""
    a = unit(axis)
    to = anchor - w.R.base_to_world(w.R.home_b)
    z = a if np.dot(a, to) > 0 else -a
    if abs(z[2]) < 0.5:
        if tilt is None:
            h = anchor[2]
            tilt = np.deg2rad(30 if h > 1.0 else (40 if h > 0.88 else 50))
        zh = unit([z[0], z[1], 0.0])
        z = unit(zh * np.cos(tilt) + np.array([0, 0, -1.0]) * np.sin(tilt))
    return z


# ---------------------------------------------------------------- turn_knob
def knob_names(w, fx, knob):
    """(joint, geom). stove: knob=front_left 등, toaster oven: temp/time/function/doneness."""
    p = fx.naming_prefix
    for jn in (f"{p}knob_{knob}_joint", f"{p}{knob}_joint", f"{p}knob_{knob}"):
        if has_joint(w, jn):
            g = jn[:-len("_joint")] + "_main" if jn.endswith("_joint") else jn + "_main"
            return jn, g
    raise SkillFailure("pre_no_knob", f"{fx.name}:{knob}")


def knob_goal(w, fx, joint, target):
    """target: 'on' | 'off' | float(정규화 0..1). 반환 (q_goal, done_fn)."""
    lo, hi = w.joint_range(joint)
    if target == "off":
        return lo + 0.0, (lambda q: (q % (2 * np.pi)) < 0.2 or (q % (2 * np.pi)) > 2 * np.pi - 0.2)
    if target == "on":
        g = min(1.0, hi - 0.2)
        return g, (lambda q: 0.6 <= (q % (2 * np.pi)) <= 2 * np.pi - 0.6)
    frac = float(target)
    g = lo + frac * (hi - lo)
    q0 = w.joint_q(joint)
    if g >= q0:
        return g, (lambda q: q >= g - 0.04 * (hi - lo))
    return g, (lambda q: q <= g + 0.04 * (hi - lo))


@skill("turn_knob")
class TurnKnob(Skill):
    """knob 잡고 GT 축 둘레로 회전. target: on/off/정규화 값."""

    retries = 1
    max_segments = 5

    def precondition(self, w, fixture, knob, target, **kw):
        fx = w.fixture(fixture)
        jn, g = knob_names(w, fx, knob)
        if not has_geom(w, g):
            raise SkillFailure("pre_no_knob_geom", g)
        d = np.linalg.norm(w.geom_pos(g)[:2] - w.R.base_pos[:2])
        if d > REACH + 0.25:
            raise SkillFailure("pre_unreachable", f"knob {d:.2f}m from base")

    def content(self, w, fixture, knob, target, **kw):
        fx = w.fixture(fixture)
        jn, g = knob_names(w, fx, knob)
        q_goal, done = knob_goal(w, fx, jn, target)
        R = w.R
        if self.attempt == 0:
            _, a0 = w.joint_anchor_axis(jn)
            topdown = abs(a0[2]) > 0.7
            align_base(w, w.geom_pos(g), fwd_min=0.42 if topdown else 0.52)
        reasons = []
        for seg in range(self.max_segments):
            if done(w.joint_q(jn)):
                return
            anchor, a = w.joint_anchor_axis(jn)
            za = approach_dir_for_axis(w, anchor, a, 0.0)
            p, hdep, f, hthin = tab_frame(w, g, a, neighbor_parts(w, fx, g))
            depth = np.dot(p - anchor, a)
            on_axis = anchor + a * depth
            zaxis = a if np.dot(a, za) > 0 else -a
            if abs(za[2]) < 0.5:
                h = anchor[2]
                tilt = np.deg2rad(30 if h > 1.0 else (40 if h > 0.88 else 50)) + 0.17 * self.attempt
                z = tilt_about(w, za, f, tilt)
            else:
                # 위에서 잡는 knob(stovetop): 옆 냄비 등에 손바닥이 걸리지 않는 (손가락 축, 기울기) 조합을 광선으로 고른다
                z, f, hthin = self.topdown_pose(w, g, a, za, on_axis, f, hthin)
            # 축 위, tab 바깥쪽 끝에서 조금 안쪽 (손가락 패드가 knob 원판에 닿지 않게)
            grasp = on_axis - zaxis * (min(hdep, 0.012) * 0.5 + self.attempt * 0.003)
            if seg > 0:
                R.go_home(max_steps=80)  # regrasp 전 팔 자세 초기화 (꼬인 자세에서 접근하면 실패가 잦음)
            r = grasp_and_rotate(w, jn, grasp, z, f, q_goal, done, lead=0.5, omega=0.03, stall_n=50, tag="turn_knob",
                                 via_back=0.15 if (abs(za[2]) < 0.5 and anchor[2] < 1.0) else 0.0,
                                 open_w=2 * hthin + 0.025)
            reasons.append(r)
            if r == "stall" and len(reasons) >= 2 and reasons[-2] == "stall":
                raise SkillFailure("slip", f"knob not following ({reasons})")
        if not done(w.joint_q(jn)):
            raise SkillFailure("not_reached", f"q={w.joint_q(jn):.2f} goal={q_goal:.2f} {reasons}")

    def topdown_pose(self, w, g, a, za, pt, f_thin, h_thin):
        p, M, size, gt = geom_info(w, g)
        he = geom_half_extents(size, gt)
        al = [abs(np.dot(M[:, i], a)) for i in range(3)]
        dep = int(np.argmax(al))
        oth = sorted([i for i in range(3) if i != dep], key=lambda i: he[i])
        choices = [(f_thin, h_thin, 0.0)]
        if 2 * he[oth[1]] + 0.025 < 0.075:
            choices.append((M[:, oth[1]], he[oth[1]], 0.03))
        hdir = pt - w.R.base_pos
        hdir[2] = 0
        hdir = unit(hdir)
        best = None
        for f, hw, bias in choices:
            for tdeg in (0, 25, 40):
                tb = np.deg2rad(tdeg)
                z = unit(za * np.cos(tb) + hdir * np.sin(tb))
                ff = unit(f - np.dot(f, z) * z)
                c = palm_blocked(w, pt, -z, ff, protrude=0.025) + bias + 0.0004 * tdeg
                if best is None or c < best[0]:
                    best = (c, z, ff, hw)
        return best[1], best[2], best[3]

    def effect(self, w, fixture, knob, target, **kw):
        fx = w.fixture(fixture)
        jn, _ = knob_names(w, fx, knob)
        if hasattr(fx, "is_burner_on") and target in ("on", "off"):
            return fx.is_burner_on(w.env, knob) == (target == "on")
        return knob_goal(w, fx, jn, target)[1](w.joint_q(jn))

    def on_except(self, w, err, **kw):
        R = w.R
        R.gripper(False, n=6)
        R.move_ee(R.eef_pos - R.eef_mat[:, 2] * 0.08, max_steps=40)
        R.go_home(max_steps=100)
        return True


# ---------------------------------------------------------------- turn_lever (sink handle) / rotate_spout
def lever_grasp(w, joint, geom, top_frac=0.75):
    """레버형 부품의 작용점(tip)·막대 방향(L)·+회전 시 이동 방향(t)·축.
    막대가 축과 수직이면 막대 끝 쪽, 축과 나란한 paddle 형이면 로봇 쪽 끝을 작용점으로 쓴다."""
    anchor, a = w.joint_anchor_axis(joint)
    a = unit(a)
    p, M, size, gt = geom_info(w, geom)
    he = geom_half_extents(size, gt)
    long_i = int(np.argmax(he))
    L = M[:, long_i]
    if abs(np.dot(L, a)) > 0.7:
        home = w.R.base_to_world(w.R.home_b)
        if np.dot(L, home - p) < 0:
            L = -L
        tip = p + L * he[long_i] * 0.5
        r = tip - anchor
        r = r - np.dot(r, a) * a
        L = unit(r)
    else:
        if np.dot(L, p - anchor) < 0:
            L = -L
        tip = p + L * he[long_i] * (2 * top_frac - 1)
        r = tip - anchor
        r = r - np.dot(r, a) * a
    t = unit(np.cross(a, r))  # +회전 시 이동 방향
    return tip, L, t, a, anchor


@skill("turn_lever")
class TurnLever(Skill):
    """싱크 수전 handle(on/off 레버)을 잡고 축 둘레로 돌린다."""

    retries = 1

    def names(self, w, fx):
        p = fx.naming_prefix
        return f"{p}handle_joint", f"{p}handle_main"

    def precondition(self, w, fixture, target, **kw):
        fx = w.fixture(fixture)
        jn, g = self.names(w, fx)
        if not (has_joint(w, jn) and has_geom(w, g)):
            raise SkillFailure("pre_no_handle", fx.name)

    def goal(self, w, jn, target):
        lo, hi = w.joint_range(jn)
        if target == "on":
            return hi, (lambda q: 0.44 < (q % (2 * np.pi)) < np.pi)
        return lo, (lambda q: not (0.30 < (q % (2 * np.pi)) < np.pi))

    def content(self, w, fixture, target, **kw):
        fx = w.fixture(fixture)
        jn, g = self.names(w, fx)
        q_goal, done = self.goal(w, jn, target)
        if done(w.joint_q(jn)):
            return
        if self.attempt == 0:
            align_base(w, w.geom_pos(g), fwd_min=0.52)
        self.push_lever_arc(w, jn, g, q_goal, done)
        if not done(w.joint_q(jn)):
            raise SkillFailure("not_reached", f"q={w.joint_q(jn):.2f}")

    def push_lever_arc(self, w, jn, g, q_goal, done):
        """handle 끝부분 옆면을 닫은 손가락으로 밀어 호를 따라 돌린다.
        잡지 않으므로 손바닥(손가락 축 방향으로 넓음)을 handle 막대 방향(세로)으로 세워 옆의 spout과 안 부딪히게 한다."""
        R = w.R
        tip, L, t, a, anchor = lever_grasp(w, jn, g, top_frac=0.8 - 0.1 * self.attempt)
        sgn = 1.0 if q_goal > w.joint_q(jn) else -1.0
        push = t * sgn  # 이동 방향
        p, M, size, gt = geom_info(w, g)
        he = geom_half_extents(size, gt)
        half_t = float(np.abs(M.T @ push) @ he)
        gap = half_t + 0.018
        start = tip - push * gap
        gap_ang = gap / max(np.linalg.norm(tip - anchor), 0.03)
        z = approach_dir_for_axis(w, anchor, a, np.deg2rad([30, 45][self.attempt % 2]))
        mat = choose_mat(w, z, L)[0]
        R.gripper(True, n=6)
        pre = start - z * 0.08
        if not move_to_pre(w, pre, mat, via_back=0.18):
            raise SkillFailure("approach", f"turn_lever: pregrasp not reached ({np.linalg.norm(pre - R.eef_pos):.3f})")
        straight_in(w, start, mat, step=0.005, max_steps=60, grip=1.0)
        if np.linalg.norm(start - R.eef_pos) > 0.02:
            e = np.linalg.norm(start - R.eef_pos)
            R.move_ee(R.eef_pos - z * 0.06, mat, max_steps=30)
            raise SkillFailure("approach", f"turn_lever: push start not reached ({e:.3f})")
        q0 = w.joint_q(jn)
        P0 = R.eef_pos.copy()
        th = 0.0
        last_chk, last_q = R.steps, q0
        for i in range(220):
            q = w.joint_q(jn)
            if done(q):
                break
            # 목표 각: 현재 handle 각 + lead (밀면서 호를 따라감)
            th = min(max(th + 0.012, 0.0), (q - q0) * sgn + gap_ang + 0.3)
            tgt = anchor + rotmat(a, sgn * th) @ (P0 - anchor)
            R.step(arm=R.arm_cmd(tgt, mat, max_dpos=0.6), grip=1.0)
            if R.steps - last_chk >= 50:
                if abs(w.joint_q(jn) - last_q) < 0.01:
                    break
                last_chk, last_q = R.steps, w.joint_q(jn)
        R.log("turn_lever", f"push q {q0:.2f}->{w.joint_q(jn):.2f}")
        # 밀던 반대쪽으로 살짝 떼고 뒤로
        R.move_ee_path([R.eef_pos - push * 0.02, R.eef_pos - push * 0.02 - z * 0.08], mat, step_len=0.02,
                       max_steps=40, grip=1.0)

    def effect(self, w, fixture, target, **kw):
        fx = w.fixture(fixture)
        on = fx.get_handle_state(w.env)["water_on"]
        return on == (target == "on")

    def on_except(self, w, err, **kw):
        R = w.R
        R.gripper(False, n=6)
        R.move_ee(R.eef_pos - R.eef_mat[:, 2] * 0.08, max_steps=40)
        R.go_home(max_steps=100)
        return True


@skill("rotate_spout")
class RotateSpout(Skill):
    """싱크 spout를 잡고 수직축 둘레로 left/right/center 로 돌린다."""

    retries = 1

    def names(self, w, fx):
        p = fx.naming_prefix
        return f"{p}spout_joint", f"{p}spout_main"

    def goal(self, w, jn, direction):
        lo, hi = w.joint_range(jn)
        if direction == "right":
            g = min(hi - 0.03, np.pi / 6 + 0.35)
            return g, (lambda q: np.pi / 6 + 0.06 <= (q % (2 * np.pi)) <= np.pi)
        if direction == "left":
            g = max(lo + 0.03, -np.pi / 6 - 0.35)
            return g, (lambda q: np.pi <= (q % (2 * np.pi)) <= 2 * np.pi - np.pi / 6 - 0.06)
        return 0.0, (lambda q: abs(((q + np.pi) % (2 * np.pi)) - np.pi) < np.pi / 6 - 0.08)

    def grasp_point(self, w, g, anchor, frac_shift=0.0):
        """spout body의 충돌 geom 중 축에서 충분히 먼(최대 거리의 60% 이상) 것 가운데 가장 낮은 것.
        (곧은 spout는 몸통 중심, gooseneck은 내려오는 출수구 쪽)"""
        m = w.sim.model
        body = m.body(m.geom_bodyid[m.geom_name2id(g)]).name
        cands = []
        for gid in w.geoms_of_body_tree(body):
            if m.geom_contype[gid] == 0 and m.geom_conaffinity[gid] == 0:
                continue
            pos = np.array(w.sim.data.geom_xpos[gid])
            d = np.linalg.norm((pos - anchor)[:2])
            cands.append((d, pos, float(m.geom_size[gid][0])))
        maxd = max(c[0] for c in cands)
        if maxd < 0.05:
            raise SkillFailure("pre_spout_geom", "spout too short")
        ok = [c for c in cands if c[0] >= (0.6 + frac_shift) * maxd] or [max(cands, key=lambda c: c[0])]
        d, pos, rad = min(ok, key=lambda c: c[1][2])
        return pos, min(rad, 0.025)

    def precondition(self, w, fixture, direction, **kw):
        fx = w.fixture(fixture)
        jn, g = self.names(w, fx)
        if not (has_joint(w, jn) and has_geom(w, g)):
            raise SkillFailure("pre_no_spout", fx.name)

    def content(self, w, fixture, direction, **kw):
        fx = w.fixture(fixture)
        jn, g = self.names(w, fx)
        q_goal, done = self.goal(w, jn, direction)
        if done(w.joint_q(jn)):
            return
        anchor, a = w.joint_anchor_axis(jn)
        grasp, rad = self.grasp_point(w, g, anchor, frac_shift=0.1 * self.attempt)
        t = unit(np.cross(a, grasp - anchor))
        # 로봇 쪽에서 비스듬히(아래 45도) 접근: 위에서 수직으로 접근하면 높이 때문에 팔이 닿지 않는다
        h = grasp - w.R.base_pos
        h[2] = 0
        tilt = np.deg2rad([45, 60][self.attempt % 2])
        z = unit(unit(h) * np.cos(tilt) + np.array([0, 0, -1.0]) * np.sin(tilt))
        if self.attempt == 0:
            align_base(w, grasp, fwd_min=0.50)
        rr = grasp_and_rotate(w, jn, grasp, z, t, q_goal, done, lead=0.3, omega=0.02, stall_n=50, max_steps=250,
                              pre_dist=0.08, use_q7=True, tag="rotate_spout", open_w=2 * rad + 0.03)
        if not done(w.joint_q(jn)):
            raise SkillFailure("not_reached" if rr != "stall" else "slip", f"q={w.joint_q(jn):.2f} ({rr})")

    def effect(self, w, fixture, direction, **kw):
        fx = w.fixture(fixture)
        return fx.get_handle_state(w.env)["spout_ori"] == direction

    def on_except(self, w, err, **kw):
        R = w.R
        R.gripper(False, n=6)
        R.move_ee(R.eef_pos - R.eef_mat[:, 2] * 0.08, max_steps=40)
        R.go_home(max_steps=100)
        return True


# ---------------------------------------------------------------- press_button
def button_geoms(w, fx, button):
    p = fx.naming_prefix
    names = [n for n in w.names("geom", p) if button in n[len(p):]]
    return names


@skill("press_button")
class PressButton(Skill):
    """버튼 geom 법선 방향으로 닫힌 손가락 끝을 밀어 넣고 상태가 바뀌면 물러난다.
    microwave: button=start_button|stop_button, coffee machine: button=start_button."""

    retries = 2

    def state(self, w, fx):
        return bool(fx.get_state()["turned_on"])

    def want(self, button):
        return "stop" not in button

    def button_frame(self, w, g):
        p, M, size, gt = geom_info(w, g)
        he = geom_half_extents(size, gt)
        n = M[:, int(np.argmin(he))]
        # 버튼에 slide joint가 있으면 그 축(눌리는 방향)의 반대가 법선
        m = w.sim.model
        best = None
        for j in range(m.njnt):
            jn = m.joint(j).name
            if m.jnt_type[j] == 2 and "button" in jn.lower():
                anc, ax = w.joint_anchor_axis(jn)
                d = np.linalg.norm(anc - p)
                if d < 0.03 and (best is None or d < best[0]):
                    best = (d, ax)
        if best is not None:
            n = -unit(best[1])
        if np.dot(n, w.R.base_pos + np.array([0, 0, 1.2]) - p) < 0:  # 바깥(로봇 쪽) 법선
            n = -n
        return p, n

    def plan(self, w, fx, button):
        """후보 (geom, 손가락축, 막힘 비용) — 막힘이 적고 가까운 버튼 순."""
        names = button_geoms(w, fx, button)
        if not names:
            raise SkillFailure("pre_no_button", f"{fx.name}:{button}")
        out = []
        for g in names:
            p, n = self.button_frame(w, g)
            f0 = np.cross(n, [0, 0, 1.0])
            f0 = unit(f0) if np.linalg.norm(f0) > 0.3 else w.R.base_mat[:, 1]
            c, z, f = best_press_pose(w, p, n, f0)
            out.append((c + 0.05 * np.linalg.norm(p - w.R.eef_pos), g, (z, f)))
        out.sort(key=lambda x: x[0])
        return out

    def pick_geom(self, w, fx, button):
        pl = self.plan(w, fx, button)
        return pl[self.attempt % len(pl)][1]

    def precondition(self, w, fixture, button, **kw):
        fx = w.fixture(fixture)
        self.pick_geom(w, fx, button)

    def content(self, w, fixture, button, **kw):
        R = w.R
        fx = w.fixture(fixture)
        if self.state(w, fx) == self.want(button):
            return
        pl = self.plan(w, fx, button)
        _, g, (z, f) = pl[self.attempt % len(pl)]
        p, n = self.button_frame(w, g)
        if self.attempt == 0:
            align_base(w, p, fwd_min=0.52 if p[2] < 1.3 else 0.36)
            pl = self.plan(w, fx, button)
            _, g, (z, f) = pl[0]
            p, n = self.button_frame(w, g)
        R.log("press_button", f"{g} tilt {np.degrees(np.arccos(np.clip(np.dot(z, -n), -1, 1))):.0f}")
        mat = choose_mat(w, z, f)[0]
        n = -z  # 접근 방향 기준으로 밀고 물러남
        R.gripper(True, n=6)
        pre = p + n * 0.10
        if not move_to_pre(w, pre, mat):
            raise SkillFailure("approach", f"button pre not reached ({np.linalg.norm(pre - R.eef_pos):.3f})")
        hit = lambda: touching(w, g) or self.state(w, fx) == self.want(button)  # noqa: E731
        straight_in(w, p - n * 0.02, mat, step=0.004, max_steps=90, stop_fn=hit, grip=1.0)
        for _ in range(3):
            if self.state(w, fx) == self.want(button):
                break
            R.step(arm=R.arm_cmd(p - n * 0.03, mat), grip=1.0)
        pressed = self.state(w, fx) == self.want(button)
        # 0.15 m 이상 물러남 (성공 조건 gripper_button_far)
        R.move_ee_path([p + n * 0.22], mat, step_len=0.03, max_steps=60, grip=1.0)
        if not pressed:
            raise SkillFailure("no_press", f"state not changed (touch={touching(w, g)})")

    def effect(self, w, fixture, button, **kw):
        fx = w.fixture(fixture)
        return self.state(w, fx) == self.want(button)

    def on_except(self, w, err, **kw):
        R = w.R
        R.move_ee(R.eef_pos - R.eef_mat[:, 2] * 0.08, max_steps=40)
        return True


# ---------------------------------------------------------------- push_lever
@skill("push_lever")
class PushLever(Skill):
    """토스터 lever / 전기주전자 switch: 손가락 끝을 위에 올리고 joint 방향(아래)으로 누른다."""

    retries = 2

    def parts(self, w, fx, slot_pair=0):
        """(joint, geom, state_fn)."""
        from robocasa.models.fixtures import ElectricKettle, Toaster

        p = fx.naming_prefix
        if isinstance(fx, ElectricKettle):
            return f"{p}switch_joint", f"{p}switch_main", (lambda: bool(fx.get_state(w.env)["turned_on"]))
        if isinstance(fx, Toaster):
            jn = fx._joint_names.get(f"lever_{slot_pair}")
            g = jn[:-len("_joint")] + "_handle"
            return jn, g, (lambda: bool(fx.get_state(w.env, slot_pair=slot_pair)["turned_on"]))
        raise SkillFailure("pre_unsupported", type(fx).__name__)

    def precondition(self, w, fixture, slot_pair=0, **kw):
        fx = w.fixture(fixture)
        jn, g, _ = self.parts(w, fx, slot_pair)
        if not (has_joint(w, jn) and has_geom(w, g)):
            raise SkillFailure("pre_no_lever", f"{jn} {g}")

    def content(self, w, fixture, slot_pair=0, **kw):
        R = w.R
        fx = w.fixture(fixture)
        jn, g, on = self.parts(w, fx, slot_pair)
        if on():
            return
        p, M, size, gt = geom_info(w, g)
        he = geom_half_extents(size, gt)
        anchor, a = w.joint_anchor_axis(jn)
        jtype = w.sim.model.jnt_type[w.sim.model.joint_name2id(jn)]
        if jtype == 2:  # slide
            push = unit(a)
        else:  # hinge: geom 중심의 +회전 접선
            push = unit(np.cross(a, p - anchor))
        # 바깥 방향: fixture 중심에서 레버로 (수평)
        if hasattr(fx, "check_slot_contact"):  # 토스터: lever는 앞면에 있으므로 fixture 정면 방향
            out = w.fixture_front(fx)
        else:  # 전기주전자: 몸통 중심 → switch (손잡이 쪽)
            out = p - np.asarray(fx.pos)
        out[2] = 0
        out = unit(out)
        to_robot = R.base_pos - p
        to_robot[2] = 0
        to_robot = unit(to_robot)
        side = np.dot(out, to_robot) < 0.2
        if side or (self.attempt >= 1 and np.dot(out, to_robot) < 0.5):
            # 손잡이가 옆/뒤를 향하면 로봇 쪽으로 접근 방향을 돌린다 (최대 약 45도)
            out = unit(out + 0.8 * to_robot)
        # 레버 윗면 높이 (push 반대 방향 extent)
        ext = np.abs(M.T @ push) @ he
        top = p - push * ext
        if self.attempt == 0:
            align_base(w, p, fwd_min=0.40)
        # 수평 접근(바깥→안), 손가락 축은 수평/접선 방향, 살짝 아래로 기울임
        tilts = [35, 20, 50] if hasattr(fx, "check_slot_contact") else ([10, 20, 35] if side else [20, 35, 10])
        tilt = np.deg2rad(tilts[self.attempt % 3])
        z = unit(-out * np.cos(tilt) + push * np.sin(tilt))
        f = np.cross(out, [0, 0, 1.0])
        mat = choose_mat(w, z, f)[0]
        clear = 0.012
        tip_in = 0.004  # grip site에서 손끝까지 대략
        start = top - push * clear + out * (0.006 - tip_in)
        pre = start - z * 0.09
        R.log("push_lever", f"{g} start {np.round(start, 3).tolist()} z {np.round(z, 2).tolist()}")
        R.gripper(True, n=6)
        if not move_to_pre(w, pre, mat):
            raise SkillFailure("approach", f"lever pre not reached ({np.linalg.norm(pre - R.eef_pos):.3f})")
        straight_in(w, start, mat, step=0.005, max_steps=80, grip=1.0)
        if np.linalg.norm(start - R.eef_pos) > 0.03:
            raise SkillFailure("approach", f"lever start not reached ({np.linalg.norm(start - R.eef_pos):.3f})")
        lo, hi = w.joint_range(jn)
        travel = abs(hi - lo) if jtype == 2 else abs(hi - lo) * np.linalg.norm(p - anchor)
        end = start + push * (travel + clear + 0.02)
        straight_in(w, end, mat, step=0.004, max_steps=120, grip=1.0, stop_fn=on)
        for _ in range(10):
            if on():
                break
            R.step(arm=R.arm_cmd(end + push * 0.01, mat), grip=1.0)
        ok = on()
        R.move_ee_path([R.eef_pos - push * 0.02 - z * 0.10], mat, step_len=0.02, max_steps=50, grip=1.0)
        if not ok:
            frac = w.joint_frac(jn)
            raise SkillFailure("no_press", f"lever frac {frac:.2f}")

    def effect(self, w, fixture, slot_pair=0, **kw):
        fx = w.fixture(fixture)
        return self.parts(w, fx, slot_pair)[2]()

    def on_except(self, w, err, **kw):
        R = w.R
        R.move_ee(R.eef_pos - R.eef_mat[:, 2] * 0.08 + np.array([0, 0, 0.03]), max_steps=40)
        return True
