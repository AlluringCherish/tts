"""이동 skill: navigate(fixture), approach(point) — mobile base."""
import heapq

import numpy as np

from ..robot import SkillFailure, wrap
from ..skill import Skill, skill

GRID = 0.05
INFLATE = 0.32  # base 반경 근사 (Omron base 약 0.6 x 0.5 m)


def obstacle_boxes(w, z_max=0.5):
    """바닥에 닿는 fixture의 2D 외곽 (평행사변형 꼭짓점 4개)."""
    from robocasa.models.fixtures import Floor

    boxes = []
    for f in w.env.fixtures.values():
        if isinstance(f, Floor):
            continue
        try:
            p0, px, py, pz = [np.asarray(p) for p in f.get_ext_sites(relative=False)]
        except Exception:  # noqa: BLE001
            continue
        if p0[2] > z_max:  # 벽장처럼 떠 있는 것은 base와 부딪히지 않음
            continue
        boxes.append((p0[:2], px[:2], py[:2], f.name))
    return boxes


def build_grid(w, extra_free=()):
    boxes = obstacle_boxes(w)
    pts = np.concatenate([np.stack([b[0], b[1], b[2], b[1] + b[2] - b[0]]) for b in boxes]) if boxes else np.zeros((1, 2))
    lo = pts.min(0) - 1.0
    hi = pts.max(0) + 1.0
    nx, ny = int((hi[0] - lo[0]) / GRID) + 1, int((hi[1] - lo[1]) / GRID) + 1
    xs = lo[0] + np.arange(nx) * GRID
    ys = lo[1] + np.arange(ny) * GRID
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    P = np.stack([X, Y], -1)
    occ = np.zeros((nx, ny), bool)
    for p0, px, py, _ in boxes:
        ex, ey = px - p0, py - p0
        lx, ly = np.linalg.norm(ex), np.linalg.norm(ey)
        if lx < 1e-6 or ly < 1e-6:
            continue
        d = P - p0
        a = (d @ ex) / lx
        b = (d @ ey) / ly
        occ |= (a > -INFLATE) & (a < lx + INFLATE) & (b > -INFLATE) & (b < ly + INFLATE)
    return occ, lo


def astar(occ, s, g):
    nx, ny = occ.shape
    moves = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
    openq = [(0, s)]
    came, cost = {s: None}, {s: 0.0}
    while openq:
        _, c = heapq.heappop(openq)
        if c == g:
            break
        for dx, dy in moves:
            n = (c[0] + dx, c[1] + dy)
            if not (0 <= n[0] < nx and 0 <= n[1] < ny) or occ[n]:
                continue
            nc = cost[c] + (1.414 if dx and dy else 1.0)
            if nc < cost.get(n, 1e9):
                cost[n] = nc
                came[n] = c
                heapq.heappush(openq, (nc + np.hypot(n[0] - g[0], n[1] - g[1]), n))
    if g not in came:
        return None
    path = []
    c = g
    while c is not None:
        path.append(c)
        c = came[c]
    return path[::-1]


def free_disk(occ, cell, r):
    x, y = cell
    occ[max(0, x - r):x + r + 1, max(0, y - r):y + r + 1] = False


def shortcut(pts, occ, lo):
    """보이는 점까지 건너뛰어 경유점 줄이기."""
    def visible(a, b):
        n = int(np.linalg.norm(b - a) / (GRID / 2)) + 1
        for t in np.linspace(0, 1, n):
            c = tuple(((a + (b - a) * t - lo) / GRID).round().astype(int))
            if occ[c]:
                return False
        return True

    out = [pts[0]]
    i = 0
    while i < len(pts) - 1:
        j = len(pts) - 1
        while j > i + 1 and not visible(pts[i], pts[j]):
            j -= 1
        out.append(pts[j])
        i = j
    return out


def plan_path(w, goal_xy):
    occ, lo = build_grid(w)
    to_cell = lambda p: tuple(((np.asarray(p) - lo) / GRID).round().astype(int))  # noqa: E731
    s, g = to_cell(w.R.base_pos[:2]), to_cell(goal_xy)
    free_disk(occ, s, int(INFLATE / GRID) + 1)  # 시작·목표는 fixture에 붙어 있으므로 비워 준다
    free_disk(occ, g, int(INFLATE / GRID) + 1)
    cells = astar(occ, s, g)
    if cells is None:
        return None
    pts = [lo + np.array(c) * GRID for c in cells]
    pts = shortcut(pts, occ, lo)
    pts[-1] = np.asarray(goal_xy, float)
    return pts[1:]


def follow(w, waypoints, final_yaw):
    R = w.R
    for i, p in enumerate(waypoints):
        last = i == len(waypoints) - 1
        d = p - R.base_pos[:2]
        # 이동 방향을 바라보며 가면 좁은 통로에서 덜 부딪힘. 마지막 구간은 최종 방향으로
        yaw = final_yaw if last or np.linalg.norm(d) < 0.3 else np.arctan2(d[1], d[0])
        if not last and abs(wrap(yaw - R.base_yaw)) > 0.3:
            R.move_base(R.base_pos[:2], yaw, yaw_tol=0.1, max_steps=120)
        ok = R.move_base(p, yaw, tol=0.03 if not last else 0.015, yaw_tol=0.08 if not last else 0.02, max_steps=500)
        if not ok and np.linalg.norm(p - R.base_pos[:2]) > 0.12:
            raise SkillFailure("base_blocked", f"waypoint {i} not reached, err {np.linalg.norm(p - R.base_pos[:2]):.2f}")


@skill("navigate")
class Navigate(Skill):
    """fixture 앞 표준 위치(robocasa compute_robot_base_placement_pose)로 base 이동."""

    retries = 1

    def target(self, w, fixture, ref_object=None, offset=None):
        from robocasa.utils.env_utils import compute_robot_base_placement_pose

        fx = w.fixture(fixture)
        pos, ori = compute_robot_base_placement_pose(w.env, fx, ref_object=ref_object, offset=offset)
        return np.asarray(pos)[:2], float(ori[2])

    def precondition(self, w, fixture, **kw):
        w.fixture(fixture)

    def content(self, w, fixture, ref_object=None, offset=None, **kw):
        R = w.R
        goal, yaw = self.target(w, fixture, ref_object, offset)
        self.goal = (goal, yaw)
        R.go_home(max_steps=60)
        if np.linalg.norm(goal - R.base_pos[:2]) < 0.05:
            R.move_base(goal, yaw)
            return
        path = plan_path(w, goal)
        if path is None:
            raise SkillFailure("no_path", "A* failed")
        follow(w, path, yaw)

    def effect(self, w, fixture, **kw):
        goal, yaw = self.goal
        return np.linalg.norm(goal - w.R.base_pos[:2]) <= 0.10 and np.cos(yaw - w.R.base_yaw) >= 0.99

    def on_except(self, w, err, **kw):
        # 뒤로 조금 빠졌다가 재계획
        R = w.R
        back = R.base_pos[:2] - 0.15 * np.array([np.cos(R.base_yaw), np.sin(R.base_yaw)])
        R.move_base(back, R.base_yaw, max_steps=80)
        return True


@skill("approach")
class Approach(Skill):
    """작업 지점이 팔 작업 영역(base frame x≈0.55, y≈0)에 들도록 base를 옆/앞뒤로 조금 옮긴다."""

    retries = 0

    def content(self, w, point, x_des=0.55, y_tol=0.25, x_lo=0.4, x_hi=0.7, max_shift=1.6, **kw):
        R = w.R
        p_b = R.world_to_base(np.asarray(point))
        dx = 0.0 if x_lo <= p_b[0] <= x_hi else p_b[0] - x_des
        dy = 0.0 if abs(p_b[1]) <= y_tol else p_b[1] - np.sign(p_b[1]) * 0.1
        shift = np.array([dx, dy])
        if np.linalg.norm(shift) < 0.02:
            return
        if np.linalg.norm(shift) > max_shift:
            raise SkillFailure("too_far", f"needs {np.linalg.norm(shift):.2f} m base shift")
        tgt = R.base_pos[:2] + R.base_mat[:2, :2] @ shift
        R.go_home(max_steps=80)  # 팔(과 쥔 물체)을 올려서 카운터·싱크 가장자리에 걸리지 않게
        R.move_base(tgt, R.base_yaw, max_steps=400)

    def effect(self, w, point, y_tol=0.25, **kw):
        p_b = w.R.world_to_base(np.asarray(point))
        return abs(p_b[1]) <= y_tol + 0.05 and 0.3 <= p_b[0] <= 0.8
