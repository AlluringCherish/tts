"""GT 상태 조회 (perceptor 자리). 나중에 perceptor로 바꿀 때 이 파일의 인터페이스만 유지하면 된다."""
import numpy as np
import robosuite.utils.transform_utils as T
from robocasa.utils import object_utils as OU


class World:
    def __init__(self, env, robot):
        self.env, self.R = env, robot
        self.sim = env.sim
        self.history = []  # skill 실행 기록

    # ---------- object ----------
    # name: env.objects 키 또는 (fixture의 움직이는 부품처럼) MuJoCo body 이름
    def body_id(self, name):
        if name in self.env.objects:
            return self.env.obj_body_id[name]
        return self.sim.model.body_name2id(name)

    def obj_pos(self, name):
        return np.array(self.sim.data.body_xpos[self.body_id(name)])

    def obj_mat(self, name):
        return np.array(self.sim.data.body_xmat[self.body_id(name)]).reshape(3, 3)

    def body_geoms(self, name, collide_only=True):
        m = self.sim.model
        root = self.body_id(name)
        out = []
        for g in range(m.ngeom):
            b = m.geom_bodyid[g]
            while b not in (0, root):
                b = m.body_parentid[b]
            if b == root and (not collide_only or m.geom_contype[g] or m.geom_conaffinity[g]):
                out.append(g)
        return out

    def obj_bbox(self, name):
        """world 좌표 8개 bbox 꼭짓점."""
        if name in self.env.objects:
            o = self.env.objects[name]
            q = T.convert_quat(np.array(self.sim.data.body_xquat[self.env.obj_body_id[name]]), to="xyzw")
            return np.array(o.get_bbox_points(trans=self.obj_pos(name), rot=q))
        m, d = self.sim.model, self.sim.data
        pts = []
        for g in self.body_geoms(name):
            c, h = m.geom_aabb[g][:3], m.geom_aabb[g][3:]
            M = d.geom_xmat[g].reshape(3, 3)
            for sx in (-1, 1):
                for sy in (-1, 1):
                    for sz in (-1, 1):
                        pts.append(d.geom_xpos[g] + M @ (c + h * np.array([sx, sy, sz])))
        return np.array(pts)

    def obj_aabb(self, name):
        p = self.obj_bbox(name)
        return p.min(0), p.max(0)

    def obj_half_size(self, name):
        if name in self.env.objects:
            return np.array(self.env.objects[name].size) / 2
        # body: body frame 기준 크기
        p = self.obj_bbox(name)
        M = self.obj_mat(name)
        q = (p - self.obj_pos(name)) @ M
        return (q.max(0) - q.min(0)) / 2

    def obj_cat(self, name):
        for c in self.env.object_cfgs or []:
            if c.get("name") == name:
                return c.get("info", {}).get("cat", "")
        return ""

    def grasped(self, name):
        """쥐고 있는지. 접촉 판정(check_obj_grasped)은 이동 중 깜빡이므로, 손가락 사이 폭과 거리로 보완한다."""
        if name in self.env.objects and OU.check_obj_grasped(self.env, name):
            return True
        R = self.R
        if R.grip <= 0 or R.gripper_width < 0.004:
            return False
        lo, hi = self.obj_aabb(name)
        p = R.eef_pos
        inside = np.all(p >= lo - 0.02) and np.all(p <= hi + 0.02)
        return bool(inside)

    def obj_in_contact(self, name, other):
        a = self.env.objects[name]
        b = self.env.objects.get(other) or self.env.get_fixture(other)
        return self.env.check_contact(a, b)

    def held_by_gripper(self, name):
        return self.env.check_contact(self.R.robot.gripper["right"], self.env.objects[name])

    # ---------- fixture ----------
    def fixture(self, ref):
        """ref: fixture 이름 또는 env.fixture_refs 키 또는 Fixture 객체."""
        if not isinstance(ref, str):
            return ref
        refs = getattr(self.env, "fixture_refs", {})
        if ref in refs:
            v = refs[ref]
            return v[0] if isinstance(v, tuple) else v
        return self.env.get_fixture(ref)

    def fixture_pose(self, fx):
        fx = self.fixture(fx)
        return np.array(fx.pos), T.euler2mat([0, 0, fx.rot])

    def fixture_front(self, fx):
        """fixture의 앞쪽(로봇이 서야 할 방향) 단위벡터. robocasa fixture는 local -y가 앞."""
        _, M = self.fixture_pose(fx)
        return -M[:, 1]

    def site_pos(self, name):
        return np.array(self.sim.data.site_xpos[self.sim.model.site_name2id(name)])

    def geom_pos(self, name):
        return np.array(self.sim.data.geom_xpos[self.sim.model.geom_name2id(name)])

    def body_pos(self, name):
        return np.array(self.sim.data.body_xpos[self.sim.model.body_name2id(name)])

    def joint_q(self, name):
        return float(self.sim.data.qpos[self.sim.model.get_joint_qpos_addr(name)])

    def joint_range(self, name):
        return self.sim.model.jnt_range[self.sim.model.joint_name2id(name)].copy()

    def joint_frac(self, name):
        lo, hi = self.joint_range(name)
        return OU.normalize_joint_value(self.joint_q(name), lo, hi)

    def joint_anchor_axis(self, name):
        """hinge/slide joint의 world anchor, world axis."""
        jid = self.sim.model.joint_name2id(name)
        return np.array(self.sim.data.xanchor[jid]), np.array(self.sim.data.xaxis[jid])

    def geoms_of_body_tree(self, body_name):
        m = self.sim.model
        root = m.body_name2id(body_name)
        out = []
        for g in range(m.ngeom):
            b = m.geom_bodyid[g]
            while b != 0 and b != root:
                b = m.body_parentid[b]
            if b == root:
                out.append(g)
        return out

    def names(self, kind, contains):
        m = self.sim.model
        n = {"site": m.nsite, "geom": m.ngeom, "body": m.nbody, "joint": m.njnt}[kind]
        f = getattr(m, kind)
        return [f(i).name for i in range(n) if contains in f(i).name]


def _robot_body_ids(sim):
    m = sim.model
    return {i for i in range(m.nbody) if m.body(i).name.startswith(("robot0", "gripper0", "mobilebase0"))}


def ceiling(w, xy, z0, max_h=1.5, ignore_objs=()):
    """(xy, z0)에서 위로 ray를 쏴서 처음 닿는 (로봇·지정 물체 제외) 높이. 없으면 z0+max_h."""
    import mujoco

    sim = w.sim
    m, d = sim.model._model, sim.data._data
    if not hasattr(w, "_robot_bodies"):
        w._robot_bodies = _robot_body_ids(sim)
    skip = set(w._robot_bodies)
    for o in ignore_objs:
        skip.add(w.body_id(o))
    p = np.array([xy[0], xy[1], z0], float)
    gid = np.zeros(1, np.int32)
    for _ in range(40):
        dist = mujoco.mj_ray(m, d, p, np.array([0, 0, 1.0]), None, 1, -1, gid)
        if dist < 0 or p[2] + dist > z0 + max_h:
            return z0 + max_h
        g = gid[0]
        b = m.geom_bodyid[g]
        if m.geom_contype[g] == 0 and m.geom_conaffinity[g] == 0:  # 충돌 없는 시각·영역 geom
            p = p + np.array([0, 0, dist + 1e-3])
            continue
        root = b
        while root and root not in skip and m.body_parentid[root] != 0:
            root = m.body_parentid[root]
        if b in skip or root in skip:
            p = p + np.array([0, 0, dist + 1e-3])
            continue
        return p[2] + dist
    return z0 + max_h


World.ceiling = ceiling


def floor_below(w, xy, z0, max_d=1.5, ignore_objs=()):
    """(xy, z0)에서 아래로 ray, 처음 닿는 (로봇·지정 물체·비충돌 geom 제외) 높이."""
    import mujoco

    sim = w.sim
    m, d = sim.model._model, sim.data._data
    if not hasattr(w, "_robot_bodies"):
        w._robot_bodies = _robot_body_ids(sim)
    skip = set(w._robot_bodies) | {w.body_id(o) for o in ignore_objs}
    p = np.array([xy[0], xy[1], z0], float)
    gid = np.zeros(1, np.int32)
    for _ in range(40):
        dist = mujoco.mj_ray(m, d, p, np.array([0, 0, -1.0]), None, 1, -1, gid)
        if dist < 0 or dist > max_d:
            return z0 - max_d
        g = gid[0]
        if m.geom_bodyid[g] in skip or (m.geom_contype[g] == 0 and m.geom_conaffinity[g] == 0):
            p = p - np.array([0, 0, dist + 1e-3])
            continue
        return p[2] - dist
    return z0 - max_d


World.floor_below = floor_below
