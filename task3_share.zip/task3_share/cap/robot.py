"""PandaOmron 저수준 제어 (primitive 층).

action(12) = [arm OSC delta pos(3) rot(3) | gripper(1) | base vel x,y,yaw(3) | torso(1) | mode(1)]
- arm: base frame 기준 delta, 입력 1.0 = 5cm / 0.5rad
- base: 현재 base frame 기준 속도 (x 전방, y 좌측, yaw)
- mode > 0: base 이동 모드 (arm 목표를 desired 기준으로 갱신 → base와 같이 움직임)
모든 primitive는 GT 상태(시뮬레이터)로 폐루프 제어한다.
"""
import numpy as np
import robosuite.utils.transform_utils as T


class SkillFailure(Exception):
    """skill 실행 실패. code: 실패 분류(대시보드 집계용)."""

    def __init__(self, code, msg=""):
        super().__init__(f"{code}: {msg}")
        self.code, self.msg = code, msg


def wrap(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


class Robot:
    ARM_POS_SCALE = 0.05
    ARM_ROT_SCALE = 0.5

    def __init__(self, env, recorder=None, step_budget=None):
        self.env = env
        self.sim = env.sim
        self.robot = env.robots[0]
        self.rec = recorder
        self.steps = 0
        self.step_budget = step_budget
        self.grip = -1.0  # -1 open, +1 close
        self.trace = []  # (step, skill, event)
        self.obs = None
        self.success_seen = False
        self.home_b = self.world_to_base(self.eef_pos)  # 초기 eef 위치(base frame) = home
        self.home_mat_b = self.base_mat.T @ self.eef_mat

    # ---------- 상태 ----------
    @property
    def eef_pos(self):
        return np.array(self.sim.data.site_xpos[self.sim.model.site_name2id("gripper0_right_grip_site")])

    @property
    def eef_mat(self):
        return np.array(self.sim.data.site_xmat[self.sim.model.site_name2id("gripper0_right_grip_site")]).reshape(3, 3)

    @property
    def base_pos(self):
        return np.array(self.sim.data.body_xpos[self.sim.model.body_name2id("mobilebase0_base")])

    @property
    def base_mat(self):
        return np.array(self.sim.data.body_xmat[self.sim.model.body_name2id("mobilebase0_base")]).reshape(3, 3)

    @property
    def base_yaw(self):
        m = self.base_mat
        return np.arctan2(m[1, 0], m[0, 0])

    @property
    def gripper_qpos(self):
        idx = self.robot._ref_gripper_joint_pos_indexes["right"]
        return np.array(self.sim.data.qpos[idx])

    @property
    def gripper_width(self):
        q = self.gripper_qpos
        return float(abs(q[0] - q[1]))

    @property
    def torso_q(self):
        return float(self.sim.data.qpos[self.sim.model.get_joint_qpos_addr("mobilebase0_joint_torso_height")])

    def set_torso(self, q, tol=0.005, max_steps=40):
        """torso 높이(0~0.34 m)를 q로. 팔은 base frame 기준 그대로 따라 올라간다."""
        q = float(np.clip(q, 0.0, 0.34))
        for _ in range(max_steps):
            d = q - self.torso_q
            if abs(d) < tol:
                break
            self.step(arm=np.zeros(6), torso=float(np.clip(d / 0.05, -1, 1)))
        return abs(q - self.torso_q) < tol * 2

    def world_to_base(self, p):
        return self.base_mat.T @ (np.asarray(p) - self.base_pos)

    def base_to_world(self, p):
        return self.base_mat @ np.asarray(p) + self.base_pos

    # ---------- 저수준 step ----------
    def step(self, arm=None, grip=None, base=None, torso=0.0, mode=-1.0):
        a = np.zeros(12)
        if arm is not None:
            a[:6] = np.clip(arm, -1, 1)
        if grip is not None:
            self.grip = grip
        a[6] = self.grip
        if base is not None:
            a[7:10] = np.clip(base, -1, 1)
        a[10] = torso
        a[11] = mode
        self.obs, _, _, _ = self.env.step(a)
        self.steps += 1
        if self.rec is not None:
            self.rec()
        if not self.success_seen and self.env._check_success():
            self.success_seen = True
            self.log("ENV", "task_success")
        if self.step_budget is not None and self.steps >= self.step_budget:
            raise SkillFailure("budget", f"step budget {self.step_budget} exhausted")

    def idle(self, n=1, **kw):
        for _ in range(n):
            self.step(**kw)

    def log(self, skill, event):
        self.trace.append((self.steps, skill, event))

    # ---------- arm ----------
    def arm_cmd(self, pos, mat=None, kp=1.0, max_dpos=1.0):
        """world 목표 pose → OSC delta action(6)."""
        dp = self.base_mat.T @ (np.asarray(pos) - self.eef_pos)
        u = np.zeros(6)
        u[:3] = np.clip(kp * dp / self.ARM_POS_SCALE, -max_dpos, max_dpos)
        if mat is not None:
            r_err = mat @ self.eef_mat.T  # world
            r_err_b = self.base_mat.T @ r_err @ self.base_mat
            aa = T.quat2axisangle(T.mat2quat(r_err_b))
            u[3:] = np.clip(aa / self.ARM_ROT_SCALE, -1, 1)
        return u

    def move_ee(self, pos, mat=None, tol=0.01, rot_tol=0.1, max_steps=150, speed=1.0, grip=None,
                stop_fn=None, name="move_ee"):
        """eef를 목표 pose로. 도달하면 True, stop_fn()이 참이면 즉시 반환."""
        pos = np.asarray(pos, dtype=float)
        for i in range(max_steps):
            perr = np.linalg.norm(pos - self.eef_pos)
            rerr = 0.0 if mat is None else np.linalg.norm(T.quat2axisangle(T.mat2quat(mat @ self.eef_mat.T)))
            if perr < tol and rerr < rot_tol:
                return True
            if stop_fn is not None and stop_fn():
                return True
            self.step(arm=self.arm_cmd(pos, mat, max_dpos=speed), grip=grip)
        return False

    def move_ee_path(self, waypoints, mat=None, tol=0.015, step_len=0.02, max_steps=400, grip=None, stop_fn=None, speed=1.0):
        """경유점 리스트를 촘촘히 보간해서 따라감 (직선 이동, 문 열기 호 등)."""
        pts = [self.eef_pos.copy()] + [np.asarray(w, float) for w in waypoints]
        dense = []
        for a, b in zip(pts[:-1], pts[1:]):
            n = max(1, int(np.ceil(np.linalg.norm(b - a) / step_len)))
            dense += [a + (b - a) * (k + 1) / n for k in range(n)]
        used = 0
        for p in dense:
            ok = self.move_ee(p, mat, tol=tol * 2, max_steps=8, grip=grip, stop_fn=stop_fn, speed=speed)
            used += 1
            if stop_fn is not None and stop_fn():
                return True
            if self.steps > 0 and used > max_steps:
                return False
        return self.move_ee(dense[-1], mat, tol=tol, max_steps=60, grip=grip, stop_fn=stop_fn, speed=speed)

    def gripper(self, close, n=15):
        g = 1.0 if close else -1.0
        for _ in range(n):
            self.step(arm=self.arm_cmd(self.eef_pos), grip=g)

    def go_home(self, max_steps=150):
        """팔을 초기 자세(base 기준)로. 위로 먼저 올린 뒤 이동."""
        home = self.base_to_world(self.home_b)
        up = np.r_[self.eef_pos[:2], max(self.eef_pos[2], home[2] - 0.15)]
        self.move_ee_path([up, home], self.base_mat @ self.home_mat_b, step_len=0.04, max_steps=max_steps)

    # ---------- base ----------
    # base 속도 응답: 축별 deadzone 0.25, 그 위로 선형 (cmd 1.0 ≈ 0.0375 m/step). probe_base_curve.py 참고
    BASE_DEAD = 0.25
    BASE_LIN_SLOPE = 0.05  # m/step per unit cmd above deadzone
    BASE_YAW_SLOPE = 0.1  # rad/step per unit cmd above deadzone (근사)

    def _base_cmd(self, v, slope):
        """원하는 속도(m/step 또는 rad/step) → deadzone 보상한 명령."""
        if abs(v) < 1e-4:
            return 0.0
        return float(np.sign(v) * min(1.0, self.BASE_DEAD + abs(v) / slope))

    def move_base(self, xy, yaw=None, tol=0.015, yaw_tol=0.02, max_steps=600, k=0.15, vmax=0.025, wmax=0.05):
        """mobile base를 world (x,y,yaw)로 폐루프 이동. 성공 여부 반환."""
        xy = np.asarray(xy, dtype=float)
        if self.grip > 0 and self.gripper_width > 0.004:  # 물체를 쥔 채 이동: 급가속·급회전에 물체가 빠지지 않게 절반 속도
            vmax, wmax = vmax * 0.5, wmax * 0.5
        for i in range(max_steps):
            d = self.base_mat.T @ np.r_[xy - self.base_pos[:2], 0.0]
            dyaw = 0.0 if yaw is None else wrap(yaw - self.base_yaw)
            if np.linalg.norm(d[:2]) < tol and abs(dyaw) < yaw_tol:
                break
            v = k * d[:2]
            n = np.linalg.norm(v)
            if n > vmax:
                v *= vmax / n
            w = np.clip(k * dyaw, -wmax, wmax)
            cmd = [self._base_cmd(v[0], self.BASE_LIN_SLOPE), self._base_cmd(v[1], self.BASE_LIN_SLOPE),
                   self._base_cmd(w, self.BASE_YAW_SLOPE)]
            self.step(arm=np.zeros(6), base=np.array(cmd), mode=1.0)
        for _ in range(4):
            self.step(arm=np.zeros(6), base=np.zeros(3), mode=1.0)
        d = np.linalg.norm(xy - self.base_pos[:2])
        dyaw = 0.0 if yaw is None else abs(wrap(yaw - self.base_yaw))
        return d < tol * 2 and dyaw < yaw_tol * 2
