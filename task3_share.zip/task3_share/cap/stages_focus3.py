"""분석 대상 3 task의 전체 프로그램 (focus3 skill 조합). 구간 평가와 같은 형식으로 등록: "<Task>@full3".

success는 env._check_success() (task 원래 성공 조건). setup 없음 — 처음 상태 그대로 시작.
"""
import numpy as np

from cap.stages import Stage, stage


def _counter_spot_near(w, point, clear=0.12):
    """point 근처 카운터의 빈 자리 (머그를 잠깐 내려놓을 곳)."""
    from robocasa.models.fixtures import Counter

    from cap import fx as FX

    best = None
    for f in sorted((f for f in w.env.fixtures.values() if isinstance(f, Counter)),
                    key=lambda f: np.linalg.norm(np.asarray(f.pos[:2]) - np.asarray(point)[:2])):
        best = FX.free_spot(w, f, near=point, clear=clear, max_dist=0.8)
        if best is not None:
            return best
    return None


@stage("PrepareCoffee@full3", "PrepareCoffee")
class CoffeeFull(Stage):
    def program(self, w):
        from cap.programs.composite import go_near
        from cap.programs.precise import coffee_setup_mug, retreat_far
        from cap.robot import SkillFailure
        from cap.skills.controls import PressButton
        from cap.skills.enclosed import PickEnclosed
        from cap.skills.manip import Place, Retreat

        cm = w.env.coffee_machine
        PickEnclosed(w)(obj="obj")  # 벽장 안 머그를 (벽을 잡고) 꺼낸다
        site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
        go_near(w, "coffee_machine", site)
        # 손잡이로 다시 잡기 위해 로봇 바로 앞 카운터 빈 자리에 잠깐 내려놓는다 (머신 옆은 손이 안 들어감)
        R = w.R
        ahead = R.base_to_world(np.r_[0.5, 0.0, 0.0])
        spot = _counter_spot_near(w, ahead)
        if spot is None:
            raise SkillFailure("pre_no_spot", "no counter spot near coffee machine")
        Place(w)(obj="obj", target=spot, tol=0.08, keep_orient=True)
        Retreat(w)(away_from="obj")
        coffee_setup_mug(w)  # 손잡이 잡기 + 노즐 아래 놓기
        retreat_far(w, "obj")
        PressButton(w)(fixture=cm, button="start_button")
        w.R.go_home()


@stage("StirVegetables@full3", "StirVegetables")
class StirFull(Stage):
    def program(self, w):
        from cap.programs.contact import stir_place_part, stir_stir_part

        stir_place_part(w)
        stir_stir_part(w)


@stage("PrepareVeggieDip@full3", "PrepareVeggieDip")
class VeggieFull(Stage):
    def program(self, w):
        from cap.programs.precise import lid_and_power, retreat_far
        from cap.skills.composite_extra import NavigatePose
        from cap.skills.enclosed import PickEnclosed
        from cap.skills.nav import Navigate
        from cap.skills.manip import Pick, Place, Retreat
        from cap.skills.precise import PlaceIntoJug

        bl = w.env.blender
        start = (w.R.base_pos[:2].copy(), float(w.R.base_yaw))
        for i, obj in enumerate(("vegetable", "cream_cheese")):
            if i > 0:
                NavigatePose(w)(xy=start[0], yaw=start[1])  # 냉장고 앞으로 복귀
            PickEnclosed(w)(obj=obj)
            # 칸에서 꺼낼 때는 손끝으로 잡는 경우가 많아 들고 이동하면 빠진다:
            # 근처 카운터에 내려놓고 몸통을 단단히 다시 잡은 뒤 이동
            spot = _counter_spot_near(w, w.R.base_to_world(np.r_[0.5, 0.0, 0.0]))
            if spot is not None:
                Place(w)(obj=obj, target=spot, tol=0.10, keep_orient=True)
                Retreat(w)(away_from=obj)
                Pick(w)(obj=obj)
            Navigate(w)(fixture=bl)
            PlaceIntoJug(w)(obj=obj, fixture=bl)
            retreat_far(w, obj)
        lid_and_power(w)
