"""task별 CaP 프로그램. @program("TaskName") 으로 등록, 함수는 (w: World) 를 받는다."""
import importlib
import pkgutil

PROGRAMS = {}


def program(*tasks):
    def deco(fn):
        for t in tasks:
            PROGRAMS[t] = fn
        return fn

    return deco


def load_all():
    for m in pkgutil.iter_modules(__path__):
        importlib.import_module(f"{__name__}.{m.name}")
    return PROGRAMS
