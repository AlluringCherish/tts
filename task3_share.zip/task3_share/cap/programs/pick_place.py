"""pick & place 계열 atomic task 프로그램."""
import numpy as np

from .. import fx as FX
from ..skills.manip import Pick, Place, Retreat
from . import program


def on_top_of(w, name, dz=0.01):
    """receptacle 물체 위: body xy, 바닥 높이 = 물체 aabb 바닥 + dz."""
    lo, hi = w.obj_aabb(name)
    return np.r_[w.obj_pos(name)[:2], lo[2] + dz]


def finish(w, obj="obj"):
    Retreat(w)(away_from=obj)


@program("PickPlaceCounterToSink")
def counter_to_sink(w):
    Pick(w)(obj="obj")
    p0, px, py, pz = list(FX.int_regions(w.fixture("sink")).values())[0]
    c, z = FX.region_center(p0, px, py, pz)
    Place(w)(obj="obj", target=np.r_[c[:2], z])
    finish(w)


@program("PickPlaceSinkToCounter", "PickPlaceCounterToStove")
def to_container(w):
    Pick(w)(obj="obj")
    Place(w)(obj="obj", target=on_top_of(w, "container"))
    finish(w)


@program("PickPlaceToasterToCounter")
def toaster_to_plate(w):
    recep = next(n for n in w.env.objects if n != "obj" and "plate" in n or n == "container")
    Pick(w)(obj="obj")
    Place(w)(obj="obj", target=on_top_of(w, recep))
    finish(w)


@program("PickPlaceDrawerToCounter")
def drawer_to_counter(w):
    from ..skill import REGISTRY
    from . import load_all

    load_all()  # slide 계열 skill 등록
    # setup에서 서랍이 30%만 열려 있어 물체가 상판 아래에 있다 → 더 연다
    REGISTRY["open_drawer"](w)(fixture="drawer")
    Pick(w)(obj="obj")
    counter = w.fixture("counter") if "counter" in w.env.fixture_refs else None
    if counter is None:
        from robocasa.models.fixtures import Counter
        counter = min((f for f in w.env.fixtures.values() if isinstance(f, Counter)),
                      key=lambda f: np.linalg.norm(np.asarray(f.pos[:2]) - w.R.base_pos[:2]))
    spot = FX.free_spot(w, counter, near=w.R.eef_pos)
    if spot is None:  # 범위를 넓혀 모든 카운터에서
        from robocasa.models.fixtures import Counter
        for f in sorted((f for f in w.env.fixtures.values() if isinstance(f, Counter)),
                        key=lambda f: np.linalg.norm(np.asarray(f.pos[:2]) - w.R.base_pos[:2])):
            spot = FX.free_spot(w, f, near=w.R.eef_pos, clear=0.08, max_dist=1.0)
            if spot is not None:
                break
    if spot is None:
        from ..robot import SkillFailure
        raise SkillFailure("pre_no_spot", "no free counter spot")
    Place(w)(obj="obj", target=spot)
    finish(w)


@program("PickPlaceCounterToCabinet")
def counter_to_cabinet(w):
    cab = w.fixture("cab")
    Pick(w)(obj="obj")
    regs = FX.int_regions(cab)
    # 가장 낮은 칸
    p0, px, py, pz = min(regs.values(), key=lambda r: r[0][2])
    c, z = FX.region_center(p0, px, py, pz)
    front = w.fixture_front(cab)  # 바깥 방향
    depth = abs(np.dot((py - p0)[:2], front[:2])) or np.linalg.norm((py - p0)[:2])
    half = max(w.obj_half_size("obj")[:2])
    # 앞쪽 가장자리에서 (물체 반 + 2cm) 안쪽. obj_inside_of의 허용 오차가 커서 깊이 넣지 않아도 된다
    tgt = c[:2] + front[:2] * (depth / 2 - half - 0.02)
    Place(w)(obj="obj", target=np.r_[tgt, z + 0.005], mode="front", entry=-front)
    finish(w)


@program("CoffeeSetupMug")
def coffee_setup_mug(w):
    cm = w.fixture("coffee_machine")
    site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
    Pick(w)(obj="obj")
    Place(w)(obj="obj", target=np.r_[site[:2], site[2] - 0.01], mode="front", entry=-w.fixture_front(cm), level=True, entry_dz=0.008,
                 debug_hold=getattr(w, "debug_hold", False))
    finish(w)


@program("CloseBlenderLid")
def close_blender_lid(w):
    bl = w.env.blender
    lid = f"{bl.blender_lid.name}_main"
    goal = np.asarray(bl.get_lid_closed_pos(w.env))
    Pick(w)(obj=lid)
    # 뚜껑 body 원점이 goal에 오도록: 바닥 높이 = goal z - (body 원점 - aabb 바닥)
    lo, hi = w.obj_aabb(lid)
    floor = goal[2] - (w.obj_pos(lid)[2] - lo[2])
    Place(w)(obj=lid, target=np.r_[goal[:2], floor], level=True, tol=0.03)
    Retreat(w)(away_from=lid)
