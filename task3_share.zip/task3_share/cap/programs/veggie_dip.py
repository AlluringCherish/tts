"""PrepareVeggieDip (benchmark 50개 밖의 composite): 냉장고의 채소·크림치즈 → 블렌더 → 뚜껑 → 전원.

성공 조건: 두 물체가 블렌더 안(obj_inside_of, th 0.01) AND 블렌더 켜짐.
켜짐은 뚜껑이 닫혀 있을 때만 유지되므로 순서: 넣기 → 뚜껑 닫기 → 전원 버튼.
"""
import numpy as np

from .. import fx as FX
from ..skills.composite_extra import NavigatePose
from ..skills.controls import PressButton
from ..skills.manip import Pick, Place, Retreat
from ..skills.nav import Navigate
from . import program


def blender_target(w, bl, obj):
    """블렌더 용기 안 바닥 중심 (int region), 물체 body가 갈 xy."""
    regs = FX.int_regions(bl)
    if regs:
        p0, px, py, pz = max(regs.values(), key=lambda r: np.linalg.norm(r[1] - r[0]) * np.linalg.norm(r[2] - r[0]))
        c, z = FX.region_center(p0, px, py, pz)
        return np.r_[c[:2], z + 0.01]
    return np.r_[np.asarray(bl.pos)[:2], np.asarray(bl.pos)[2]]


@program("PrepareVeggieDip")
def prepare_veggie_dip(w):
    bl = w.env.blender
    start = (w.R.base_pos[:2].copy(), float(w.R.base_yaw))
    for i, obj in enumerate(("vegetable", "cream_cheese")):
        if i > 0:
            NavigatePose(w)(xy=start[0], yaw=start[1])  # 냉장고 앞으로 복귀
        Pick(w)(obj=obj)
        Navigate(w)(fixture=bl)
        Place(w)(obj=obj, target=blender_target(w, bl, obj), tol=0.05)
        Retreat(w)(away_from=obj)
    lid_and_power(w)


def lid_and_power(w):
    """뚜껑 닫기 (CloseBlenderLid와 같은 방식) + 전원 버튼."""
    bl = w.env.blender
    lid = f"{bl.blender_lid.name}_main"
    goal = np.asarray(bl.get_lid_closed_pos(w.env))
    Pick(w)(obj=lid)
    lo, _ = w.obj_aabb(lid)
    Place(w)(obj=lid, target=np.r_[goal[:2], goal[2] - (w.obj_pos(lid)[2] - lo[2])], level=True, tol=0.03)
    Retreat(w)(away_from=lid)
    PressButton(w)(fixture=bl, button="power_button")
    w.R.go_home()
