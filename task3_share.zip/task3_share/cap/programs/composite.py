"""RoboCasa365 composite benchmark task 프로그램 (composite_seen 16 + composite_unseen 16 중
StirVegetables / ScrubCuttingBoard / PanTransfer(contact.py)를 뺀 29개).

각 프로그램은 task decomposition을 따르는 직선형 skill 호출 열이다. 상태 읽기(어느 화구가 비었는지,
어느 도구가 정답인지, 놓을 자리)는 GT로 한다. fixture를 바꿔야 하면 navigate 계열을 먼저 부른다.
"""
import numpy as np

from .. import fx as FX
from ..robot import SkillFailure
from ..skills.composite_extra import NavigateNear, NavigatePose, Wait
from ..skills.controls import PressButton, PushLever, RotateSpout, TurnKnob, TurnLever
from ..skills.doors import CloseDoor, OpenDoor, door_joints
from ..skills.manip import Pick, Place, Retreat
from ..skills.nav import Navigate
from ..skills.slide import OpenDrawer, SlideRack
from . import program
from .pick_place import on_top_of

# ---------------------------------------------------------------- 공통 헬퍼


def meta_refs(w):
    m = w.env.get_ep_meta()
    return {**(m.get("task_refs") or {}), **(m.get("refs") or {})}


def base_pose(w):
    return w.R.base_pos[:2].copy(), float(w.R.base_yaw)


def far(w, point, d=0.95):
    p = w.obj_pos(point) if isinstance(point, str) else np.asarray(point)
    return np.linalg.norm(p[:2] - w.R.base_pos[:2]) > d


def go_near(w, fixture, point, d=0.95):
    """point가 팔(+approach) 범위 밖이면 fixture 정면 줄을 따라 point 앞으로 이동."""
    if far(w, point, d):
        NavigateNear(w)(fixture=fixture, point=w.obj_pos(point) if isinstance(point, str) else np.asarray(point))


def nearest_stool(w, point):
    from robocasa.models.fixtures.accessories import Stool

    p = w.obj_pos(point) if isinstance(point, str) else np.asarray(point)
    stools = [f for f in w.env.fixtures.values() if isinstance(f, Stool)]
    return min(stools, key=lambda f: np.linalg.norm(np.asarray(f.pos[:2]) - p[:2]))


def go_dining(w, point, d=0.95):
    """식탁 위 물체 앞으로: 가장 가까운 stool 쪽에서 접근."""
    if far(w, point, d):
        NavigateNear(w)(fixture=nearest_stool(w, point), point=w.obj_pos(point) if isinstance(point, str) else np.asarray(point))


def body_for_center(w, obj, center_xy):
    """bbox 중심이 center_xy에 오게 하는 body xy (손잡이 달린 팬 등 body 원점 ≠ bbox 중심)."""
    lo, hi = w.obj_aabb(obj)
    off = (lo + hi)[:2] / 2 - w.obj_pos(obj)[:2]
    return np.asarray(center_xy)[:2] - off


def surface_z(w, xy, z_from, ignore=()):
    return w.floor_below(np.asarray(xy)[:2], z_from, ignore_objs=ignore)


def on_obj(w, recep, offset=(0.0, 0.0), dz=0.01):
    """receptacle 물체 위 (+ world xy offset)."""
    t = on_top_of(w, recep, dz)
    t[:2] += np.asarray(offset)
    return t


def spots_on(w, recep, n=2, frac=0.25):
    """receptacle(쟁반·도마) 긴 축을 따라 n개 자리 offset (world xy): 반길이 * frac * (-1..1)."""
    M = w.obj_mat(recep)
    hs = w.obj_half_size(recep)
    i = int(np.argmax(hs[:2]))
    ax = M[:2, i] / (np.linalg.norm(M[:2, i]) + 1e-9)
    if n == 1:
        return [np.zeros(2)]
    return [ax * hs[i] * 2 * frac * k for k in np.linspace(-1, 1, n)]


def free_side_offset(w, recep, user_objs, step=0.07):
    """recep 위에서 user_objs와 가장 먼 쪽(긴 축 ±) offset."""
    M = w.obj_mat(recep)
    hs = w.obj_half_size(recep)
    i = int(np.argmax(hs[:2]))
    ax = M[:2, i] / (np.linalg.norm(M[:2, i]) + 1e-9)
    c = w.obj_pos(recep)[:2]
    best, bs = np.zeros(2), -1
    for k in (-1, 1):
        o = ax * min(step, hs[i] * 0.5) * k
        s = min([np.linalg.norm(c + o - w.obj_pos(u)[:2]) for u in user_objs] or [1.0])
        if s > bs:
            best, bs = o, s
    return best


# ---------- fixture 내부 자리


def region_axes(w, fx, region):
    """region의 (중심, 바닥 z, 바깥(front) 단위벡터, 깊이, 옆 단위벡터, 폭)."""
    p0, px, py, pz = region
    c, z = FX.region_center(p0, px, py, pz)
    front = w.fixture_front(fx)[:2]
    ex, ey = (px - p0)[:2], (py - p0)[:2]
    if abs(np.dot(ex, front)) > abs(np.dot(ey, front)):
        dvec, lvec = ex, ey
    else:
        dvec, lvec = ey, ex
    depth, width = np.linalg.norm(dvec), np.linalg.norm(lvec)
    lat = lvec / (width + 1e-9)
    return c, z, front, depth, lat, width


def interior_target(w, fx, region, obj, lat=0.0, margin=0.02, dz=0.005, back=None):
    """fixture 칸 안 자리: 앞 가장자리에서 (물체 반 + margin) 안쪽, 옆으로 lat (m, 칸 안으로 clip).
    back: 앞 가장자리에서의 거리를 직접 지정."""
    c, z, front, depth, latv, width = region_axes(w, fx, region)
    half = max(w.obj_half_size(obj)[:2])
    d_in = (half + margin) if back is None else back
    d_in = min(d_in, depth / 2)
    lim = max(width / 2 - half - 0.02, 0.0)
    lat = float(np.clip(lat, -lim, lim))
    xy = c[:2] + front * (depth / 2 - d_in) + latv * lat
    return np.r_[xy, z + dz]


def region_of_point(w, fx, p):
    """p(물체 위치)가 들어 있는 int region. 없으면 가장 낮은 region."""
    regs = FX.int_regions(fx)
    for r in regs.values():
        lo = np.minimum.reduce(r)
        hi = np.maximum.reduce(r)
        if lo[2] - 0.03 <= p[2] <= hi[2] + 0.03 and np.all(p[:2] >= lo[:2] - 0.05) and np.all(p[:2] <= hi[:2] + 0.05):
            return r
    return min(regs.values(), key=lambda r: r[0][2])


def lowest_region(w, fx):
    return min(FX.int_regions(fx).values(), key=lambda r: r[0][2])


def place_inside(w, obj, fx, target, **kw):
    """fixture 칸 안에 앞에서 밀어 넣어 놓기."""
    fxo = w.fixture(fx)
    Place(w)(obj=obj, target=target, mode="front", entry=-w.fixture_front(fxo), **kw)


def lat_offset_of(w, fx, region, p):
    """region 중심 기준 p의 옆 방향 좌표."""
    c, z, front, depth, latv, width = region_axes(w, fx, region)
    return float(np.dot(np.asarray(p)[:2] - c[:2], latv))


def has_doors(fx):
    try:
        return len(door_joints(fx)) > 0
    except Exception:  # noqa: BLE001
        return False


# ---------- 가전별 자리


def burner_xy(w, stove, loc):
    site = stove.burner_sites[loc]
    return w.site_pos(site.get("name"))


def free_burner(w, stove, occupied=()):
    """knob 있는 화구 중 occupied 물체에서 0.25 m 이상 떨어진 것 가운데 로봇에 가장 가까운 것."""
    locs = [k for k in stove.get_knobs_state(env=w.env).keys() if stove.burner_sites.get(k) is not None]
    def clear(l):
        return min([np.linalg.norm(burner_xy(w, stove, l)[:2] - w.obj_pos(o)[:2]) for o in occupied] or [9])
    ok = [l for l in locs if clear(l) > 0.25]
    if ok:
        return min(ok, key=lambda l: np.linalg.norm(burner_xy(w, stove, l)[:2] - w.R.base_pos[:2]))
    return max(locs, key=clear)


def sink_basin(w, sink):
    regs = FX.int_regions(sink)
    r = regs.get("basin") or list(regs.values())[0]
    c, z = FX.region_center(*r)
    return c, z


def sink_water(w, sink):
    return w.site_pos(f"{sink.naming_prefix}water")


def under_water_target(w, sink, obj):
    """물줄기 아래 basin 바닥 (body xy = water site xy)."""
    wp = sink_water(w, sink)
    _, z = sink_basin(w, sink)
    return np.r_[wp[:2], z + 0.005]


def coffee_place(w, obj):
    cm = w.env.coffee_machine
    site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
    Place(w)(obj=obj, target=np.r_[site[:2], site[2] - 0.01], mode="front", entry=-w.fixture_front(cm), level=True,
             entry_dz=0.008)


def dishwasher_rack_spots(w, dw):
    """rack1 body geom aabb 위 두 자리 (fixture 옆 방향 ±)."""
    jn = dw._joint_names["rack"]
    jid = w.sim.model.joint_name2id(jn)
    body = w.sim.model.body_id2name(w.sim.model.jnt_bodyid[jid])
    lo, hi = w.obj_aabb(body)
    c = (lo + hi) / 2
    lat = np.r_[-w.fixture_front(dw)[1], w.fixture_front(dw)[0]]
    half_w = abs(np.dot((hi - lo)[:2], lat)) / 2
    s = min(0.12, half_w * 0.45)
    return [np.r_[c[:2] + lat * s, lo[2] + 0.01], np.r_[c[:2] - lat * s, lo[2] + 0.01]]


# ================================================================ composite_seen


@program("DeliverStraw")
def deliver_straw(w):
    OpenDrawer(w)(fixture="drawer")
    w.R.go_home()
    Pick(w)(obj="straw")
    go_dining(w, "glass_cup", d=0.8)
    lo, hi = w.obj_aabb("glass_cup")
    Place(w)(obj="straw", target=np.r_[w.obj_pos("glass_cup")[:2], lo[2] + 0.01], tol=0.15)
    Retreat(w)(away_from="straw")


@program("GetToastedBread")
def get_toasted_bread(w):
    ts = w.env.toaster
    pair = 0
    for sp in range(len(ts.get_state(w.env).keys())):
        if ts.check_slot_contact(w.env, "obj", sp):
            pair = sp
            break
    PushLever(w)(fixture=ts, slot_pair=pair)
    w.R.go_home()
    # 토스트가 끝나 lever가 올라올 때까지 (on 500 step)
    Wait(w)(until=lambda: not ts.get_state(w.env, slot_pair=pair)["turned_on"], max_steps=900)
    Wait(w)(n=40)
    Pick(w)(obj="obj")
    go_dining(w, "plate", d=0.8)
    Place(w)(obj="obj", target=on_obj(w, "plate"), tol=0.08)
    Retreat(w)(away_from="obj")


@program("KettleBoiling")
def kettle_boiling(w):
    st = w.env.stove
    loc = free_burner(w, st, occupied=("stove_distr",))
    Pick(w)(obj="obj", mode="handle", lift=0.12)
    b = burner_xy(w, st, loc)
    Place(w)(obj="obj", target=np.r_[b[:2], surface_z(w, b, b[2] + 0.3, ignore=("obj",))], tol=0.10)
    Retreat(w)()
    TurnKnob(w)(fixture=st, knob=loc, target="on")
    w.R.go_home()


@program("LoadDishwasher")
def load_dishwasher(w):
    dw = w.env.dishwasher
    for dish, k in (("dish0", 0), ("dish1", 1)):
        go_near(w, "counter", dish, d=0.75)
        Pick(w)(obj=dish)
        spot = dishwasher_rack_spots(w, dw)[k]
        go_near(w, dw, spot, d=0.75)
        Place(w)(obj=dish, target=spot, tol=0.10)
        Retreat(w)()
    SlideRack(w)(fixture=dw, rack="rack1", direction="in")
    w.R.go_home()
    CloseDoor(w)(fixture=dw, th=0.05)
    w.R.go_home()


@program("PackIdenticalLunches")
def pack_identical_lunches(w):
    home = base_pose(w)  # 냉장고 앞
    plan = (("vegetable0", "tupperware0", (-0.06, 0)), ("meat0", "tupperware0", (0.06, 0)),
            ("vegetable1", "tupperware1", (-0.06, 0)), ("meat1", "tupperware1", (0.06, 0)))
    for i, (obj, tup, off) in enumerate(plan):
        if i > 0:
            NavigatePose(w)(xy=home[0], yaw=home[1])
        Pick(w)(obj=obj)
        go_near(w, "counter", tup, d=0.85)
        o = spots_on(w, tup, n=2, frac=0.25)[0 if off[0] < 0 else 1]
        Place(w)(obj=obj, target=on_obj(w, tup, o, dz=0.01), tol=0.08)
        Retreat(w)()


@program("PreSoakPan")
def pre_soak_pan(w):
    sink = w.env.sink
    c, z = sink_basin(w, sink)
    Pick(w)(obj="obj1", mode="handle", lift=0.12)
    Place(w)(obj="obj1", target=np.r_[body_for_center(w, "obj1", c[:2]), z + 0.005], tol=0.08)
    Retreat(w)()
    Pick(w)(obj="obj2")
    Place(w)(obj="obj2", target=np.r_[c[:2], surface_z(w, c, w.obj_pos("obj2")[2] + 0.2, ignore=("obj2",))], tol=0.10)
    Retreat(w)()
    TurnLever(w)(fixture=sink, target="on")
    w.R.go_home()


@program("PrepareCoffee")
def prepare_coffee(w):
    cm = w.env.coffee_machine
    Pick(w)(obj="obj")
    site = w.site_pos(f"{cm.naming_prefix}receptacle_place_site")
    go_near(w, "coffee_machine", site)
    coffee_place(w, "obj")
    Retreat(w)()
    PressButton(w)(fixture=cm, button="start_button")
    w.R.go_home()


@program("RinseSinkBasin")
def rinse_sink_basin(w):
    sink = w.env.sink
    TurnLever(w)(fixture=sink, target="on")
    w.R.go_home()
    seen = {sink.get_handle_state(env=w.env)["spout_ori"]}
    for d in ("left", "right", "center"):
        if d in seen:
            continue
        RotateSpout(w)(fixture=sink, direction=d)
        seen.add(sink.get_handle_state(env=w.env)["spout_ori"])
        w.R.go_home()


@program("SearingMeat")
def searing_meat(w):
    st = w.env.stove
    knob = str(meta_refs(w)["knob"])
    Pick(w)(obj="pan", mode="handle", lift=0.10)
    b = burner_xy(w, st, knob)
    go_near(w, "stove", b, d=0.8)
    Place(w)(obj="pan", target=np.r_[b[:2], surface_z(w, b, b[2] + 0.3, ignore=("pan",))], tol=0.10)
    Retreat(w)()
    Pick(w)(obj="meat")
    Place(w)(obj="meat", target=on_obj(w, "pan", dz=0.01), tol=0.06)
    Retreat(w)()
    TurnKnob(w)(fixture=st, knob=knob, target="on")
    w.R.go_home()


@program("SetUpCuttingStation")
def set_up_cutting_station(w):
    dr = w.fixture("drawer")
    if dr.get_door_state(w.env)["door"] < 0.9:
        OpenDrawer(w)(fixture=dr)
        w.R.go_home()
    Pick(w)(obj="knife")
    go_near(w, "counter", "receptacle", d=0.85)
    o = spots_on(w, "receptacle", n=2, frac=0.22)
    Place(w)(obj="knife", target=on_obj(w, "receptacle", o[0]), tol=0.10)
    Retreat(w)()
    go_near(w, "counter", "meat", d=0.85)
    Pick(w)(obj="meat")
    go_near(w, "counter", "receptacle", d=0.85)
    Place(w)(obj="meat", target=on_obj(w, "receptacle", o[1]), tol=0.10)
    Retreat(w)(away_from="meat")


@program("StackBowlsCabinet")
def stack_bowls_cabinet(w):
    cab = w.fixture("cabinet")
    reg = lowest_region(w, cab)
    Pick(w)(obj="bowl2")
    tgt = interior_target(w, cab, reg, "bowl2")
    place_inside(w, "bowl2", cab, tgt, tol=0.08)
    Retreat(w)()
    Pick(w)(obj="bowl1")
    lo, _ = w.obj_aabb("bowl2")
    place_inside(w, "bowl1", cab, np.r_[w.obj_pos("bowl2")[:2], lo[2] + 0.015], tol=0.08, entry_dz=0.08)
    Retreat(w)(away_from="bowl1")


@program("SteamInMicrowave")
def steam_in_microwave(w):
    mw = w.env.microwave
    Pick(w)(obj="vegetable")
    Place(w)(obj="vegetable", target=on_obj(w, "bowl", dz=0.01), tol=0.07)
    Retreat(w)()
    Pick(w)(obj="bowl")
    reg = FX.int_regions(mw).get("tray") or lowest_region(w, mw)
    c, _ = FX.region_center(*reg)
    go_near(w, "microwave", c, d=0.85)
    place_inside(w, "bowl", mw, interior_target(w, mw, reg, "bowl", back=None), tol=0.10)
    Retreat(w)()
    CloseDoor(w)(fixture=mw)
    w.R.go_home()
    PressButton(w)(fixture=mw, button="start_button")
    w.R.go_home()


@program("StoreLeftoversInBowl")
def store_leftovers_in_bowl(w):
    for obj, off in (("chicken_drumstick", -0.04), ("vegetable", 0.04)):
        go_dining(w, obj, d=0.85)
        Pick(w)(obj=obj)
        go_dining(w, "bowl", d=0.85)
        Place(w)(obj=obj, target=on_obj(w, "bowl", (off, 0.0), dz=0.01), tol=0.08)
        Retreat(w)()
    Pick(w)(obj="bowl")
    fr = w.env.fridge
    names = list(fr.get_reset_regions(w.env, compartment="fridge").keys())
    regs = FX.int_regions(fr)
    name = min(names, key=lambda n: abs(regs[n][0][2] - 1.05)) if names else min(regs, key=lambda n: abs(regs[n][0][2] - 1.05))
    reg = regs[name]
    c, _ = FX.region_center(*reg)
    Navigate(w)(fixture=fr)
    place_inside(w, "bowl", fr, interior_target(w, fr, reg, "bowl", margin=0.04), tol=0.10)
    Retreat(w)(away_from="bowl")


@program("WashLettuce")
def wash_lettuce(w):
    sink = w.env.sink
    TurnLever(w)(fixture=sink, target="on")
    w.R.go_home()
    Pick(w)(obj="lettuce")
    Place(w)(obj="lettuce", target=under_water_target(w, sink, "lettuce"), tol=0.08)
    Retreat(w)()
    Wait(w)(n=40)


# ================================================================ composite_unseen


@program("ArrangeBreadBasket")
def arrange_bread_basket(w):
    cab = w.fixture("cab")
    if has_doors(cab):
        OpenDoor(w)(fixture=cab)
        w.R.go_home()
    Pick(w)(obj="bread")
    go_near(w, "counter", "basket", d=0.85)
    Place(w)(obj="bread", target=on_obj(w, "basket", dz=0.01), tol=0.08)
    Retreat(w)()
    Pick(w)(obj="basket", mode="rim")
    table = w.fixture("dining_table")
    Navigate(w)(fixture=nearest_stool(w, np.asarray(table.pos)))
    spot = FX.free_spot(w, table, near=w.R.base_pos + 0.6 * np.r_[np.cos(w.R.base_yaw), np.sin(w.R.base_yaw), 0],
                        clear=0.2)
    if spot is None:
        raise SkillFailure("pre_no_spot", "no free dining spot")
    Place(w)(obj="basket", target=spot, tol=0.10)
    Retreat(w)(away_from="basket")


@program("ArrangeTea")
def arrange_tea(w):
    o = spots_on(w, "container", n=2, frac=0.25)
    # 로봇에서 먼 쪽에 큰 주전자
    o.sort(key=lambda v: -np.linalg.norm(w.obj_pos("container")[:2] + v - w.R.base_pos[:2]))
    go_near(w, "counter", "obj2", d=0.75)
    Pick(w)(obj="obj2")
    go_near(w, "counter", "container", d=0.75)
    Place(w)(obj="obj2", target=on_obj(w, "container", o[0]), tol=0.08)
    Retreat(w)()
    Pick(w)(obj="obj")
    Place(w)(obj="obj", target=on_obj(w, "container", o[1]), tol=0.08)
    Retreat(w)()
    CloseDoor(w)(fixture="cab")
    w.R.go_home()


@program("BreadSelection")
def bread_selection(w):
    o = spots_on(w, "cutting_board", n=2, frac=0.25)
    Pick(w)(obj="croissant")
    Place(w)(obj="croissant", target=on_obj(w, "cutting_board", o[0]), tol=0.08)
    Retreat(w)()
    Pick(w)(obj="jam")
    Place(w)(obj="jam", target=on_obj(w, "cutting_board", o[1]), tol=0.08)
    Retreat(w)(away_from="croissant")


@program("CategorizeCondiments")
def categorize_condiments(w):
    cab = w.fixture("cab")
    for obj, ref in (("obj1", "cab_obj1"), ("obj2", "cab_obj2")):
        reg = region_of_point(w, cab, w.obj_pos(ref))
        lat_ref = lat_offset_of(w, cab, reg, w.obj_pos(ref))
        others = [n for n in w.env.objects if n not in (obj, ref)]
        # ref 옆 ±0.10 중 다른 물체와 더 먼 쪽
        best, bs = None, -1
        for s in (-0.10, 0.10):
            t = interior_target(w, cab, reg, obj, lat=lat_ref + s)
            if np.linalg.norm(t[:2] - w.obj_pos(ref)[:2]) > 0.14:
                continue
            clr = min(np.linalg.norm(t[:2] - w.obj_pos(n)[:2]) for n in others)
            if clr > bs:
                best, bs = t, clr
        if best is None:
            best = interior_target(w, cab, reg, obj, lat=lat_ref)
        Pick(w)(obj=obj)
        place_inside(w, obj, cab, best, tol=0.06)
        Retreat(w)()


@program("CuttingToolSelection")
def cutting_tool_selection(w):
    env = w.env
    tool = env._CUTTING_MAP[str(meta_refs(w).get("food", env.food))]
    dr = w.fixture("drawer")
    if dr.get_door_state(env)["door"] < 0.6:
        OpenDrawer(w)(fixture=dr)
        w.R.go_home()
    Pick(w)(obj=tool)
    off = free_side_offset(w, "food_container", ["food"], step=0.09)
    go_near(w, "counter", "food_container", d=0.85)
    Place(w)(obj=tool, target=on_obj(w, "food_container", off), tol=0.10)
    Retreat(w)(away_from="food_container")


@program("GarnishPancake")
def garnish_pancake(w):
    OpenDoor(w)(fixture="fridge")
    w.R.go_home()
    Pick(w)(obj="strawberry")
    go_dining(w, "pancake", d=0.8)
    Place(w)(obj="strawberry", target=on_obj(w, "pancake", dz=0.0), tol=0.06)
    Retreat(w)(away_from="strawberry")


@program("GatherTableware")
def gather_tableware(w):
    cab1, cab2 = w.fixture("cab1"), w.fixture("cab2")
    reg = region_of_point(w, cab1, w.obj_pos("glass1"))
    c, z, front, depth, latv, width = region_axes(w, cab1, reg)
    g1 = lat_offset_of(w, cab1, reg, w.obj_pos("glass1"))
    side = 1.0 if g1 >= 0 else -1.0  # glass1 쪽에 컵을 모으고, 반대쪽 끝에 bowl
    start = base_pose(w)
    # glass3 (다른 캐비닛) → glass1 옆
    if far(w, "glass3", 0.85):
        Navigate(w)(fixture=cab2)
    Pick(w)(obj="glass3")
    if far(w, "glass1", 0.85):
        NavigatePose(w)(xy=start[0], yaw=start[1])
    place_inside(w, "glass3", cab1, interior_target(w, cab1, reg, "glass3", lat=g1 - side * 0.11), tol=0.08)
    Retreat(w)()
    # bowl → 반대쪽 끝
    Pick(w)(obj="bowl")
    place_inside(w, "bowl", cab1, interior_target(w, cab1, reg, "bowl", lat=-side * width), tol=0.08)
    Retreat(w)()
    # glass2 → glass1 쪽 (뒤쪽 줄)
    Pick(w)(obj="glass2")
    place_inside(w, "glass2", cab1, interior_target(w, cab1, reg, "glass2", lat=g1 - side * 0.11, back=0.20), tol=0.08)
    Retreat(w)(away_from="glass2")


@program("HeatKebabSandwich")
def heat_kebab_sandwich(w):
    to = w.fixture("toaster_oven")
    regs = FX.int_regions(to)
    rname = next((n for n in ("rack0", "tray0", "rack1", "tray1") if n in regs), list(regs)[0])
    reg = regs[rname]
    c, _ = FX.region_center(*reg)
    for obj, lat in (("kebab", -0.05), ("baguette", 0.05)):
        Pick(w)(obj=obj)
        go_near(w, "counter", c, d=0.85)
        place_inside(w, obj, to, interior_target(w, to, reg, obj, lat=lat, margin=0.0), tol=0.10)
        Retreat(w)()
        if obj == "kebab":
            go_near(w, "counter", "baguette", d=0.85)
    CloseDoor(w)(fixture=to, th=0.05)
    w.R.go_home()
    TurnKnob(w)(fixture=to, knob="time", target=0.3)
    w.R.go_home()


@program("MakeIceLemonade")
def make_ice_lemonade(w):
    OpenDoor(w)(fixture="fridge")
    w.R.go_home()
    Pick(w)(obj="lemon_wedge")
    go_near(w, "counter", "glass_cup", d=0.85)
    lo, _ = w.obj_aabb("glass_cup")
    Place(w)(obj="lemon_wedge", target=np.r_[w.obj_pos("glass_cup")[:2], lo[2] + 0.01], tol=0.10)
    Retreat(w)()
    ice = min(("ice_cube1", "ice_cube2"), key=lambda n: -w.obj_pos(n)[2])  # 위에 있는 것
    go_near(w, "counter", ice, d=0.85)
    Pick(w)(obj=ice)
    go_near(w, "counter", "glass_cup", d=0.85)
    lo, _ = w.obj_aabb("glass_cup")
    Place(w)(obj=ice, target=np.r_[w.obj_pos("glass_cup")[:2], lo[2] + 0.01], tol=0.10)
    Retreat(w)(away_from=ice)


@program("PortionHotDogs")
def portion_hot_dogs(w):
    home = base_pose(w)  # bowl 앞
    plan = (("hotdog_bun1", "plate1", -1), ("sausage1", "plate1", 1),
            ("hotdog_bun2", "plate2", -1), ("sausage2", "plate2", 1))
    for i, (obj, plate, sgn) in enumerate(plan):
        if i > 0 and far(w, obj, 0.85):
            NavigatePose(w)(xy=home[0], yaw=home[1])
        Pick(w)(obj=obj)
        go_dining(w, plate, d=0.85)
        M = w.obj_mat(plate)
        off = M[:2, 0] / (np.linalg.norm(M[:2, 0]) + 1e-9) * 0.045 * sgn
        Place(w)(obj=obj, target=on_obj(w, plate, off, dz=0.01), tol=0.07)
        Retreat(w)()


@program("RecycleBottlesByType")
def recycle_bottles_by_type(w):
    env = w.env
    home = base_pose(w)  # 가운데 stool 앞
    groups = {"plastic": ("bottle_plastic1", "bottle_plastic2"), "glass": ("bottle_glass1", "bottle_glass2")}
    mystery = "glass" if env.choice == "alcohol" else "plastic"
    plan = (("bottle_plastic_middle", "plastic"), ("bottle_glass_middle", "glass"), ("mystery_middle", mystery))
    counter = w.fixture("dining_counter")
    for i, (obj, kind) in enumerate(plan):
        if i > 0 and far(w, obj, 0.85):
            NavigatePose(w)(xy=home[0], yaw=home[1])
        Pick(w)(obj=obj)
        end = w.fixture(f"end_ref_{kind}")
        sample = groups[kind][0]
        if far(w, sample, 0.8):
            NavigateNear(w)(fixture=end, point=w.obj_pos(sample))
        # 견본 병 옆 빈 자리 (0.30 이내)
        sp = w.obj_pos(sample)
        spot = FX.free_spot(w, counter, near=sp, clear=0.10)
        if spot is None or np.linalg.norm(spot[:2] - sp[:2]) > 0.25:
            to_r = w.R.base_pos[:2] - sp[:2]
            spot = np.r_[sp[:2] + to_r / np.linalg.norm(to_r) * 0.12, w.obj_aabb(sample)[0][2]]
        Place(w)(obj=obj, target=spot, tol=0.08)
        Retreat(w)()


@program("SeparateFreezerRack")
def separate_freezer_rack(w):
    fr = w.env.fridge
    regs = FX.int_regions(fr)
    home = base_pose(w)
    for obj, idx in (("meat_tupperware", -2), ("veg_tupperware", -1)):
        if obj == "veg_tupperware":
            NavigatePose(w)(xy=home[0], yaw=home[1])
        Pick(w)(obj=obj)
        name = list(fr.get_reset_regions(w.env, compartment="freezer", rack_index=idx).keys())[0]
        reg = regs[name]
        c, _ = FX.region_center(*reg)
        NavigateNear(w)(fixture=fr, point=c)
        place_inside(w, obj, fr, interior_target(w, fr, reg, obj, margin=0.03), tol=0.10)
        Retreat(w)()


@program("WaffleReheat")
def waffle_reheat(w):
    mw = w.env.microwave
    OpenDoor(w)(fixture=mw)
    w.R.go_home()
    Pick(w)(obj="waffle_container")
    reg = FX.int_regions(mw).get("tray") or lowest_region(w, mw)
    c, _ = FX.region_center(*reg)
    go_near(w, "microwave", c, d=0.85)
    place_inside(w, "waffle_container", mw, interior_target(w, mw, reg, "waffle_container"), tol=0.10)
    Retreat(w)()
    CloseDoor(w)(fixture=mw)
    w.R.go_home()
    PressButton(w)(fixture=mw, button="start_button")
    w.R.go_home()


@program("WashFruitColander")
def wash_fruit_colander(w):
    sink = w.env.sink
    n = int(meta_refs(w).get("num_fruit", w.env.num_fruit))
    Pick(w)(obj="colander")
    Place(w)(obj="colander", target=under_water_target(w, sink, "colander"), tol=0.08)
    Retreat(w)()
    for i in range(n):
        f = f"fruit{i}"
        o = np.array([np.cos(2 * np.pi * i / max(n, 1)), np.sin(2 * np.pi * i / max(n, 1))]) * (0.04 if n > 1 else 0.0)
        Pick(w)(obj=f)
        Place(w)(obj=f, target=on_obj(w, "colander", o, dz=0.01), tol=0.08)
        Retreat(w)()
    TurnLever(w)(fixture=sink, target="on")
    w.R.go_home()


@program("WeighIngredients")
def weigh_ingredients(w):
    Pick(w)(obj="obj")
    go_near(w, "counter", "digital_scale", d=0.85)
    Place(w)(obj="obj", target=on_obj(w, "digital_scale", dz=0.005), tol=0.06)
    Retreat(w)()
    CloseDoor(w)(fixture="cab")
    w.R.go_home()
