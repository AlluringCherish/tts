"""prismatic / lid 계열 atomic task 프로그램."""
from ..skills.slide import CloseDrawer, CloseLid, OpenDrawer, OpenLid, SlideRack
from . import program


@program("OpenDrawer")
def open_drawer(w):
    OpenDrawer(w)(fixture="drawer")
    w.R.go_home()


@program("CloseDrawer")
def close_drawer(w):
    CloseDrawer(w)(fixture="drawer")
    w.R.go_home()


@program("SlideDishwasherRack")
def slide_dishwasher_rack(w):
    direction = "out" if w.env.should_pull else "in"
    SlideRack(w)(fixture="dishwasher", rack="rack1", direction=direction)
    w.R.go_home()


@program("OpenStandMixerHead")
def open_stand_mixer_head(w):
    OpenLid(w)(fixture=w.env.stand_mixer, part="head")
    w.R.go_home()


@program("CloseStandMixerHead")
def close_stand_mixer_head(w):
    CloseLid(w)(fixture=w.env.stand_mixer, part="head")
    w.R.go_home()
