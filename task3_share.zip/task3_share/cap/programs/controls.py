"""소형 가전 조작 atomic task 프로그램 (stove knob, sink handle/spout, microwave/coffee button, toaster/kettle lever)."""
from ..skills.controls import PressButton, PushLever, RotateSpout, TurnKnob, TurnLever
from . import program


def task_refs(w):
    return w.env.get_ep_meta().get("task_refs", {}) or {}


@program("TurnOffStove")
def turn_off_stove(w):
    TurnKnob(w)(fixture=w.env.stove, knob=str(task_refs(w)["knob"]), target="off")


@program("TurnOnStove")
def turn_on_stove(w):
    TurnKnob(w)(fixture=w.env.stove, knob=str(task_refs(w)["knob"]), target="on")


@program("TurnOnSinkFaucet")
def turn_on_sink(w):
    TurnLever(w)(fixture=w.env.sink, target="on")


@program("TurnOffSinkFaucet")
def turn_off_sink(w):
    TurnLever(w)(fixture=w.env.sink, target="off")


@program("TurnSinkSpout")
def turn_spout(w):
    RotateSpout(w)(fixture=w.env.sink, direction=str(task_refs(w)["behavior"]))


@program("TurnOnMicrowave")
def turn_on_microwave(w):
    PressButton(w)(fixture=w.env.microwave, button="start_button")


@program("TurnOffMicrowave")
def turn_off_microwave(w):
    PressButton(w)(fixture=w.env.microwave, button="stop_button")


@program("StartCoffeeMachine")
def start_coffee(w):
    PressButton(w)(fixture=w.env.coffee_machine, button="start_button")


@program("TurnOnElectricKettle")
def turn_on_kettle(w):
    PushLever(w)(fixture=w.fixture("electric_kettle"))


@program("TurnOnToaster")
def turn_on_toaster(w):
    fx = w.env.toaster
    pair = 0
    for sp in range(len(fx.get_state(w.env).keys())):
        if fx.check_slot_contact(w.env, "obj", sp):
            pair = sp
            break
    PushLever(w)(fixture=fx, slot_pair=pair)


@program("AdjustToasterOvenTemperature")
def adjust_toaster_oven_temp(w):
    fx = w.fixture("toaster_oven")
    lang = w.env.get_ep_meta()["lang"].lower()
    cur = w.joint_frac(f"{fx.naming_prefix}knob_temp_joint")
    tgt = cur + 0.27 if "increase" in lang else cur - 0.27
    TurnKnob(w)(fixture=fx, knob="temp", target=float(min(max(tgt, 0.02), 0.98)))


@program("TurnOnToasterOven")
def turn_on_toaster_oven(w):
    fx = w.fixture("toaster_oven")
    TurnKnob(w)(fixture=fx, knob="time", target=0.3)
