"""hinge 문 계열 atomic task 프로그램."""
from ..skills.doors import CloseDoor, OpenDoor
from . import program


@program("OpenCabinet", "OpenMicrowave", "OpenFridge", "OpenDishwasher")
def open_fxtr(w):
    OpenDoor(w)(fixture="fxtr")
    w.R.go_home()


@program("CloseCabinet", "CloseFridge", "CloseMicrowave", "CloseDishwasher")
def close_fxtr(w):
    CloseDoor(w)(fixture="fxtr")
    w.R.go_home()


@program("OpenToasterOvenDoor")
def open_toaster_oven(w):
    OpenDoor(w)(fixture="toaster_oven")
    w.R.go_home()


@program("CloseToasterOvenDoor")
def close_toaster_oven(w):
    CloseDoor(w)(fixture="toaster_oven")
    w.R.go_home()
