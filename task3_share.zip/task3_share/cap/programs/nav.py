"""이동 task."""
from ..skills.nav import Navigate
from . import program


@program("NavigateKitchen")
def navigate_kitchen(w):
    Navigate(w)(fixture=w.env.target_fixture)
