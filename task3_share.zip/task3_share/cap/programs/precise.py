"""정밀 놓기 + 블렌더 계열 프로그램 (task 이름으로 등록하지 않음: cap/stages_precise.py 의 구간으로만 실행)."""
import numpy as np

from ..skills.manip import Pick, Retreat
from ..skills.precise import (CloseLidPrecise, GraspLid, GraspMugHandle, PlaceIntoJug, PlaceUnderNozzle,
                              PressBlenderPower, align_to_machine, nozzle_entry, retreat_from)


def turn_on_blender(w):
    PressBlenderPower(w)(fixture=w.env.blender)
    w.R.go_home()


def close_blender_lid(w):
    bl = w.env.blender
    lid = f"{bl.blender_lid.name}_main"
    GraspLid(w)(fixture=bl)
    CloseLidPrecise(w)(fixture=bl)
    retreat_from(w, w.obj_pos(lid))


def counter_to_blender(w, obj="obj"):
    bl = w.env.blender
    Pick(w)(obj=obj)
    PlaceIntoJug(w)(obj=obj, fixture=bl)
    retreat_far(w, obj)


def retreat_far(w, obj, th=0.30):
    """성공 조건(손-물체 0.25 m 이상)을 만족할 때까지 손을 뺀다: 위·base 쪽으로, 그래도 가까우면 base 후진."""
    R = w.R
    from ..robot import SkillFailure

    try:
        Retreat(w)(away_from=obj)
    except SkillFailure:
        pass
    for _ in range(2):
        if np.linalg.norm(R.eef_pos - w.obj_pos(obj)) > th:
            return
        R.move_ee_path([R.eef_pos + np.array([0, 0, 0.12])], step_len=0.03, max_steps=40)
        if np.linalg.norm(R.eef_pos - w.obj_pos(obj)) > th:
            return
        back = R.base_pos[:2] - 0.2 * R.base_mat[:2, 0]
        R.move_base(back, R.base_yaw, max_steps=150)


def lid_and_power(w):
    close_blender_lid(w)
    turn_on_blender(w)


def coffee_setup_mug(w):
    cm = w.fixture("coffee_machine")
    entry = nozzle_entry(w, "obj", cm)
    GraspMugHandle(w)(obj="obj", want_dir=entry, low=getattr(w, "grip_low", 0.0))
    PlaceUnderNozzle(w)(obj="obj", fixture=cm, entry=entry)
