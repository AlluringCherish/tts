"""접촉이 많은 skill이 들어간 composite task (본 세션 계열만으로 구성 가능한 것)."""
import numpy as np

from ..skills.contact import PickTool, Pour, Scrub, Stir, StirPush
from ..skills.manip import Pick, Place, Retreat
from . import program
from .pick_place import on_top_of


def stir_place_part(w):
    # 두 채소를 냄비 안 좌우로 나눠 놓는다 (겹쳐 쌓이면 위쪽 채소가 냄비에 닿지 않아 "냄비 안" 판정에서 빠짐)
    lo, hi = w.obj_aabb("pot")
    r = 0.5 * min(hi[0] - lo[0], hi[1] - lo[1])
    side = np.array([1.0, 0.0])
    from ..skills.nav import Approach

    for v, sgn in (("veg1", -1), ("veg2", 1)):
        # 쥔 채로 base를 옮기면 물체가 빠지므로, 집기 전에 채소와 냄비 사이로 미리 이동
        mid = (w.obj_pos(v) + w.obj_pos("pot")) / 2
        if np.linalg.norm(w.obj_pos(v)[:2] - w.obj_pos("pot")[:2]) < 1.2:
            Approach(w)(point=mid, y_tol=0.08)
        Pick(w)(obj=v)
        t = on_top_of(w, "pot", dz=0.02)
        t[:2] += side * sgn * min(0.04, 0.35 * r)
        Place(w)(obj=v, target=t, tol=0.08)
        Retreat(w)()


def stir_stir_part(w):
    PickTool(w)(tool="spatula")
    StirPush(w)(tool="spatula", container="pot", targets=("veg1", "veg2"))


@program("StirVegetables")
def stir_vegetables(w):
    stir_place_part(w)
    stir_stir_part(w)


@program("ScrubCuttingBoard")
def scrub_cutting_board(w):
    Pick(w)(obj="sponge")
    Scrub(w)(tool="sponge", target="cutting_board")
    w.R.move_ee(w.R.eef_pos + np.array([0, 0, 0.05]), max_steps=20)
    w.R.gripper(False, n=10)
    Retreat(w)(away_from="sponge")


@program("PanTransfer")
def pan_transfer(w):
    pan = "vegetable_container"
    home = w.obj_pos(pan).copy()
    lo, _ = w.obj_aabb(pan)
    Pick(w)(obj=pan, mode="handle", lift=0.12)
    Pour(w)(container=pan, target="plate", contents=("vegetable",))
    Place(w)(obj=pan, target=np.r_[home[:2], lo[2] + 0.005], tol=0.07)
    Retreat(w)(away_from=pan)
