"""막힌 칸 pick 구간 평가 (pick_enclosed skill). 성공 = 물체를 쥔 채 칸(fixture interior) 밖."""
from cap.stages import Stage, stage


def _ok(w, obj):
    from cap.skills.enclosed import obj_outside

    enc = getattr(w, "_enc_" + obj, None)
    if enc is None:
        return False
    return bool(w.grasped(obj) and obj_outside(w, obj, enc[2]))


class _EnclosedPick(Stage):
    obj = ""

    def program(self, w):
        from cap.skills.enclosed import PickEnclosed, find_enclosure

        setattr(w, "_enc_" + self.obj, find_enclosure(w, self.obj))  # 성공 판정용 (시작 시 칸)
        PickEnclosed(w)(obj=self.obj)  # 끝에 쥔 채 home 위치로 천천히 옮겨 둔다

    def success(self, w):
        return _ok(w, self.obj)


@stage("PrepareCoffee@pick_enclosed", "PrepareCoffee")
class CoffeePickEnclosed(_EnclosedPick):
    obj = "obj"


@stage("PrepareVeggieDip@pick_enclosed", "PrepareVeggieDip")
class VeggiePickEnclosed(_EnclosedPick):
    obj = "vegetable"


@stage("PrepareVeggieDip@pick_cheese_enclosed", "PrepareVeggieDip")
class VeggieCheesePickEnclosed(_EnclosedPick):
    obj = "cream_cheese"
