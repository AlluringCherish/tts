"""RoboCasa365 env 생성 + GT 상태 접근.

CaP 실행에는 카메라 관측이 필요 없으므로 camera obs를 끄고(속도 약 4배),
영상은 Recorder가 필요할 때만 sim.render로 따로 찍는다.
"""
import os

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")

import numpy as np
import robosuite
import robocasa  # noqa: F401  (kitchen env 등록)
from robosuite import load_composite_controller_config

# benchmark target split: layout/style (1,1)...(10,10), obj_instance_split="target"
TARGET_SCENES = list(zip(range(1, 11), range(1, 11)))


def scene_pair(task, scene):
    """scene k → task가 쓸 수 있는 target (layout, style) 중 k번째 (EXCLUDE_LAYOUTS가 있는 task는 건너뛴다)."""
    from robosuite.environments.base import REGISTERED_ENVS

    cls = REGISTERED_ENVS[task]
    ex_l = set(getattr(cls, "EXCLUDE_LAYOUTS", []) or [])
    ex_s = set(getattr(cls, "EXCLUDE_STYLES", []) or [])
    valid = [p for p in TARGET_SCENES if p[0] not in ex_l and p[1] not in ex_s] or TARGET_SCENES
    return valid[scene % len(valid)]


def make_env(task, scene=0, seed=0, render=True, robots="PandaOmron", **kwargs):
    """scene: 0..9 -> target split의 (layout, style) 한 쌍으로 고정 (scene_pair 참고)."""
    controller_config = load_composite_controller_config(controller=None, robot=robots)
    env = robosuite.make(
        env_name=task,
        robots=robots,
        controller_configs=controller_config,
        camera_names=["robot0_agentview_center"],
        camera_widths=256,
        camera_heights=256,
        has_renderer=False,
        has_offscreen_renderer=render,
        ignore_done=True,
        use_object_obs=True,
        use_camera_obs=False,
        camera_depths=False,
        seed=seed,
        obj_instance_split="target",
        generative_textures=None,
        randomize_cameras=False,
        layout_and_style_ids=[scene_pair(task, scene)],
        translucent_robot=False,
        **kwargs,
    )
    return env


class Recorder:
    """sim-time 영상. every 스텝마다 한 프레임."""

    def __init__(self, env, path, every=2, size=320, cams=("robot0_agentview_center", "robot0_eye_in_hand")):
        self.env, self.path, self.every, self.size, self.cams = env, path, every, size, cams
        self.frames, self.t = [], 0

    def __call__(self):
        self.t += 1
        if self.path is None or self.t % self.every:
            return
        imgs = [self.env.sim.render(height=self.size, width=self.size, camera_name=c)[::-1] for c in self.cams]
        self.frames.append(np.concatenate(imgs, axis=1))

    def save(self):
        if self.path is None or not self.frames:
            return None
        import imageio

        imageio.mimsave(self.path, self.frames, fps=20 // self.every * 2, macro_block_size=1)
        return self.path
