"""구간(stage) 평가: composite task의 한 구간만 떼어 시험한다.

run_eval.py --tasks "StirVegetables@stir" 처럼 부른다.
- setup(w): 앞 구간이 끝난 상태를 만든다. **평가 준비 전용** — 물체 위치를 직접 옮기는 것은 여기서만 허용하고,
  정책(program)은 그 뒤 action으로만 환경을 바꾼다.
- program(w): 그 구간의 CaP 코드.
- success(w): 그 구간의 완료 판정 (task 성공 조건 중 해당 부분, 또는 env._check_success).
"""
import numpy as np

STAGES = {}


def stage(name, task):
    def deco(cls):
        cls.name, cls.task = name, task
        STAGES[name] = cls
        return cls

    return deco


def set_obj_pose(w, obj, pos, quat=None):
    """평가 준비용: free joint 물체를 pos로 옮기고 속도 0."""
    env = w.env
    o = env.objects[obj]
    jn = o.joints[0]
    adr = env.sim.model.get_joint_qpos_addr(jn)
    q = env.sim.data.qpos
    q[adr[0]:adr[0] + 3] = pos
    if quat is not None:
        q[adr[0] + 3:adr[0] + 7] = quat
    vadr = env.sim.model.get_joint_qvel_addr(jn)
    env.sim.data.qvel[vadr[0]:vadr[1]] = 0
    env.sim.forward()


def settle(w, n=40):
    w.R.idle(n)


def in_container(w, obj, container, th=None):
    from robocasa.utils import object_utils as OU

    return OU.check_obj_in_receptacle(w.env, obj, container, th=th)


class Stage:
    name = task = ""

    def setup(self, w):
        pass

    def program(self, w):
        raise NotImplementedError

    def success(self, w):
        return bool(w.env._check_success())


# ---------------------------------------------------------------- StirVegetables


@stage("StirVegetables@place", "StirVegetables")
class StirPlace(Stage):
    """채소 2개를 냄비에 넣기까지."""

    def program(self, w):
        from .programs.contact import stir_place_part

        stir_place_part(w)

    def success(self, w):
        return in_container(w, "veg1", "pot") and in_container(w, "veg2", "pot")


@stage("StirVegetables@stir", "StirVegetables")
class StirStir(Stage):
    """채소가 이미 냄비 안: 주걱 집기 + 젓기."""

    def setup(self, w):
        c = w.obj_pos("pot")
        lo, hi = w.obj_aabb("pot")
        for v, d in (("veg1", -0.035), ("veg2", 0.035)):
            vlo, vhi = w.obj_aabb(v)
            set_obj_pose(w, v, np.r_[c[:2] + np.array([d, 0.0]), lo[2] + 0.02 + (vhi[2] - vlo[2]) / 2 + 0.02])
        settle(w)

    def program(self, w):
        from .programs.contact import stir_stir_part

        stir_stir_part(w)


# ---------------------------------------------------------------- PrepareCoffee


@stage("PrepareCoffee@pick", "PrepareCoffee")
class CoffeePick(Stage):
    """벽장 안 머그를 집어 꺼내기."""

    def program(self, w):
        from .skills.manip import Pick

        Pick(w)(obj="obj")
        w.R.go_home()

    def success(self, w):
        lo, _ = w.obj_aabb("obj")
        return w.grasped("obj")


# ---------------------------------------------------------------- PrepareVeggieDip


@stage("PrepareVeggieDip@pick", "PrepareVeggieDip")
class VeggiePick(Stage):
    """냉장고 선반의 채소를 집어 꺼내기."""

    def program(self, w):
        from .skills.manip import Pick

        Pick(w)(obj="vegetable")
        w.R.go_home()

    def success(self, w):
        return w.grasped("vegetable")


@stage("PrepareVeggieDip@pick_cheese", "PrepareVeggieDip")
class VeggiePickCheese(Stage):
    """냉장고 선반의 크림치즈를 집어 꺼내기."""

    def program(self, w):
        from .skills.manip import Pick

        Pick(w)(obj="cream_cheese")
        w.R.go_home()

    def success(self, w):
        return w.grasped("cream_cheese")


@stage("PrepareVeggieDip@lid_power", "PrepareVeggieDip")
class VeggieLidPower(Stage):
    """채소·크림치즈가 이미 블렌더 안: 뚜껑 닫기 + 전원."""

    def setup(self, w):
        from .programs.veggie_dip import blender_target
        from .skills.nav import Navigate

        bl = w.env.blender
        for o, d in (("vegetable", -0.015), ("cream_cheese", 0.015)):
            t = blender_target(w, bl, o)
            lo, hi = w.obj_aabb(o)
            set_obj_pose(w, o, np.r_[t[:2] + np.array([d, 0.0]), t[2] + (hi[2] - lo[2]) / 2 + 0.03])
        settle(w)
        Navigate(w)(fixture=bl)  # 블렌더 앞으로 (정책의 일부지만 이 구간 시작 위치를 맞추는 용도)

    def program(self, w):
        from .programs.veggie_dip import lid_and_power

        lid_and_power(w)


def _autoload():
    """cap/stages_*.py 에 정의된 구간도 등록 (계열별 담당자가 각자 파일에 추가)."""
    import importlib
    import pkgutil

    import cap

    for m in pkgutil.iter_modules(cap.__path__):
        if m.name.startswith("stages_"):
            importlib.import_module(f"cap.{m.name}")


_autoload()
