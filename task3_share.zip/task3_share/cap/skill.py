"""Skill 정의 형식: precondition / content / except / effect.

  @skill("pick")
  class Pick(Skill):
      def precondition(self, w, obj): ...   # 불만족 시 SkillFailure("pre_...") raise
      def content(self, w, obj): ...        # 실제 동작
      def effect(self, w, obj): ...         # 완료 조건, bool 반환
      def on_except(self, w, err, obj): ... # 실패 후 안전 상태 복구. True 반환 시 재시도

Skill.__call__ 이 pre → content → effect 순으로 돌리고, 실패하면 on_except 후 retries 만큼 재시도.
결과는 robot.trace / Skill.history 에 남아 대시보드로 간다.
"""
import time

from .robot import SkillFailure

REGISTRY = {}


def skill(name):
    def deco(cls):
        cls.name = name
        REGISTRY[name] = cls
        return cls

    return deco


class Skill:
    name = "skill"
    retries = 1  # content 재시도 횟수 (총 시도 = retries + 1)

    def __init__(self, world):
        self.w = world
        self.attempt = 0

    def precondition(self, w, **kw):
        pass

    def content(self, w, **kw):
        raise NotImplementedError

    def effect(self, w, **kw):
        return True

    def on_except(self, w, err, **kw):
        return True

    def __call__(self, **kw):
        w, R = self.w, self.w.R
        rec = dict(skill=self.name, args={k: str(v) for k, v in kw.items()}, start=R.steps, attempts=[])
        w.history.append(rec)
        R.log(self.name, "start")
        try:
            for self.attempt in range(self.retries + 1):
                t0 = R.steps
                try:
                    self.precondition(w, **kw)
                    self.content(w, **kw)
                    if not self.effect(w, **kw):
                        raise SkillFailure("effect", f"{self.name} effect not satisfied")
                    rec["attempts"].append(dict(ok=True, steps=R.steps - t0))
                    rec.update(ok=True, end=R.steps)
                    R.log(self.name, "ok")
                    return True
                except SkillFailure as e:
                    rec["attempts"].append(dict(ok=False, code=e.code, msg=e.msg, steps=R.steps - t0))
                    R.log(self.name, f"fail:{e.code}")
                    if e.code == "budget" or e.code.startswith("pre_"):
                        raise
                    if self.attempt >= self.retries or not self.on_except(w, e, **kw):
                        raise
        except SkillFailure as e:
            rec.update(ok=False, end=R.steps, code=e.code, msg=e.msg)
            raise
