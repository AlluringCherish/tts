"""팔 경로 계획 (GT 충돌 검사): IK + RRT-connect + OSC 추종.

위가 막힌 칸(벽장·냉장고 선반) 안처럼, 손만 목표로 직선 이동시키면 팔꿈치·손목이 선반이나
자기 몸에 걸리는 곳에서 쓴다. 시뮬레이터 상태를 복사한 scratch MjData에서만 계산하고,
실제 실행은 Robot.move_ee(OSC)로 한다. OSC nullspace 자세 목표(initial_joint)를 계획한
관절 값으로 바꿔 가며 따라가게 해서, 팔이 계획한 자세를 유지하도록 한다.
"""
import mujoco
import numpy as np
import robosuite.utils.transform_utils as T


class ArmPlanner:
    def __init__(self, w, rng=0):
        self.w = w
        self.R = w.R
        self.sim = w.sim
        self.m = self.sim.model._model
        self.d = mujoco.MjData(self.m)
        robot = self.R.robot
        self.qadr = np.array(robot._ref_arm_joint_pos_indexes)
        self.vadr = np.array(robot._ref_arm_joint_vel_indexes)
        names = robot.robot_model.arm_joints
        jids = [self.m.joint(n).id for n in names]
        self.lo = self.m.jnt_range[jids, 0] + 0.02
        self.hi = self.m.jnt_range[jids, 1] - 0.02
        self.site = self.m.site("gripper0_right_grip_site").id
        self.rng = np.random.default_rng(rng)
        # 로봇 body (팔+손+base)
        self.robot_bodies = {i for i in range(self.m.nbody)
                             if self.m.body(i).name.startswith(("robot0", "gripper0", "mobilebase0"))}
        self.allowed = set()  # 닿아도 되는 body (잡을 물체 등)
        self.soft = set()  # 얕게(soft_depth 이내) 닿아도 되는 body (옆의 다른 물체: 살짝 밀려도 됨)
        self.soft_depth = 0.006
        self.attached = set()  # 손에 쥔 물체 body: 로봇처럼 취급
        self.ctx = {}  # scratch에서만 바꿔 볼 qpos (base 위치·torso 높이): {qpos addr: value}
        self.carry = None  # (free joint qpos addr, p_rel, R_rel): scratch에서 손을 따라 움직일 물체
        self.time_limit = None  # plan() 시간 상한(초)
        self.finger_w = None  # scratch 손가락 벌림 폭(m). None이면 실제 값
        self.fadr = np.array(robot._ref_gripper_joint_pos_indexes["right"])

    # ---------- scratch 상태 ----------
    def sync(self):
        self.d.qpos[:] = self.sim.data.qpos
        for a, v in self.ctx.items():
            self.d.qpos[a] = v
        if self.finger_w is not None:
            self.d.qpos[self.fadr] = [self.finger_w / 2, -self.finger_w / 2]
        self.d.qvel[:] = 0
        mujoco.mj_forward(self.m, self.d)

    def set_q(self, q):
        self.d.qpos[self.qadr] = q
        mujoco.mj_kinematics(self.m, self.d)
        if self.carry is not None:
            adr, p_rel, R_rel = self.carry
            ps = self.d.site_xpos[self.site]
            Ms = self.d.site_xmat[self.site].reshape(3, 3)
            quat = np.zeros(4)
            mujoco.mju_mat2Quat(quat, (Ms @ R_rel).reshape(-1))
            self.d.qpos[adr:adr + 3] = ps + Ms @ p_rel
            self.d.qpos[adr + 3:adr + 7] = quat
            mujoco.mj_kinematics(self.m, self.d)
        mujoco.mj_comPos(self.m, self.d)

    # ---------- 문맥 (base·torso) / 쥔 물체 ----------
    def _jadr(self, name):
        return self.m.jnt_qposadr[self.m.joint(name).id]

    def set_context(self, base_xy=None, torso=None):
        """scratch에서만 base 위치(world xy)·torso 높이를 바꿔 본다. None이면 실제 값."""
        self.ctx = {}
        self.d.qpos[:] = self.sim.data.qpos
        mujoco.mj_forward(self.m, self.d)
        if base_xy is not None:
            jf, js = self.m.joint("mobilebase0_joint_mobile_forward").id, self.m.joint("mobilebase0_joint_mobile_side").id
            A = np.stack([self.d.xaxis[jf][:2], self.d.xaxis[js][:2]], axis=1)
            dq = np.linalg.solve(A, np.asarray(base_xy, float) - self.R.base_pos[:2])
            self.ctx[self._jadr("mobilebase0_joint_mobile_forward")] = self.sim.data.qpos[self._jadr("mobilebase0_joint_mobile_forward")] + dq[0]
            self.ctx[self._jadr("mobilebase0_joint_mobile_side")] = self.sim.data.qpos[self._jadr("mobilebase0_joint_mobile_side")] + dq[1]
        if torso is not None:
            self.ctx[self._jadr("mobilebase0_joint_torso_height")] = float(torso)
        self.sync()

    def base_pose_ctx(self):
        """scratch 문맥의 base world 위치·회전."""
        b = self.m.body("mobilebase0_base").id
        return self.d.xpos[b].copy(), self.d.xmat[b].reshape(3, 3).copy()

    def base_in_collision(self, q=None):
        """scratch 문맥에서 mobile base(바퀴·몸통)가 바닥 아닌 환경과 겹치면 True."""
        if q is not None:
            self.set_q(q)
        mujoco.mj_collision(self.m, self.d)
        for i in range(self.d.ncon):
            c = self.d.contact[i]
            if c.dist > -0.002 or c.pos[2] < 0.06:  # 바닥 접촉은 무시
                continue
            b1, b2 = self.m.geom_bodyid[c.geom1], self.m.geom_bodyid[c.geom2]
            n1, n2 = self.m.body(b1).name, self.m.body(b2).name
            m1, m2 = n1.startswith("mobilebase0"), n2.startswith("mobilebase0")
            if m1 == m2:
                continue
            other = b2 if m1 else b1
            if other in self.robot_bodies:
                continue
            return True
        return False

    def subtree(self, root):
        out = set()
        for b in range(self.m.nbody):
            x = b
            while x not in (0, root):
                x = self.m.body_parentid[x]
            if x == root:
                out.add(b)
        return out

    def attach(self, body, jnt_name, grasp_pos=None, grasp_mat=None):
        """body(free joint)를 손에 쥔 것으로: scratch에서 손을 따라 움직이고 충돌 검사에 포함한다.
        grasp_pos/mat: 잡을 때의 손 자세(계획 단계). None이면 현재 실제 손 자세."""
        adr = self.m.jnt_qposadr[self.m.joint(jnt_name).id]
        po = np.array(self.sim.data.body_xpos[body])
        Mo = np.array(self.sim.data.body_xmat[body]).reshape(3, 3)
        ps = self.R.eef_pos if grasp_pos is None else np.asarray(grasp_pos, float)
        Ms = self.R.eef_mat if grasp_mat is None else np.asarray(grasp_mat, float)
        self.carry = (adr, Ms.T @ (po - ps), Ms.T @ Mo)
        self.attached = self.subtree(body)

    def detach(self):
        self.carry = None
        self.attached = set()

    def q_now(self):
        return np.array(self.sim.data.qpos[self.qadr])

    def fk(self, q):
        self.set_q(q)
        return self.d.site_xpos[self.site].copy(), self.d.site_xmat[self.site].reshape(3, 3).copy()

    def _root(self, b):
        return b

    def baseline(self):
        """현재(실제) 자세에서 이미 닿아 있는 geom 쌍은 무시 목록으로 (base-바닥, 쥔 물체-손가락 등)."""
        self.sync()
        mujoco.mj_collision(self.m, self.d)
        self.ignore_pairs = {tuple(sorted((c.geom1, c.geom2))) for c in self.d.contact[:self.d.ncon]}

    def in_collision(self, q, margin=0.0):
        """q에서 로봇이 환경과 겹치면 True. (쥔 물체는 scratch에서 손을 따라오지 않으므로 검사에서 빠진다)"""
        self.set_q(q)
        mujoco.mj_collision(self.m, self.d)
        for i in range(self.d.ncon):
            c = self.d.contact[i]
            if c.dist > -0.002 - margin:
                continue
            if tuple(sorted((c.geom1, c.geom2))) in getattr(self, "ignore_pairs", ()):
                continue
            b1, b2 = self.m.geom_bodyid[c.geom1], self.m.geom_bodyid[c.geom2]
            n1, n2 = self.m.body(b1).name, self.m.body(b2).name
            if n1.startswith("mobilebase0") or n2.startswith("mobilebase0"):
                continue  # base는 움직이지 않음
            r1, r2 = b1 in self.robot_bodies or b1 in self.attached, b2 in self.robot_bodies or b2 in self.attached
            if r1 and r2:
                # 로봇 자기 충돌: 인접 링크끼리는 무시 (부모-자식)
                if self.m.body_parentid[b1] == b2 or self.m.body_parentid[b2] == b1:
                    continue
                if (b1 in self.attached) != (b2 in self.attached) and (b1 in self.attached or b2 in self.attached):
                    continue  # 쥔 물체-손
                if self.m.body(b1).name.startswith("mobilebase0") and self.m.body(b2).name.startswith("mobilebase0"):
                    continue
                return True
            if r1 or r2:
                other = b2 if r1 else b1
                if other in self.allowed:
                    continue
                if other in self.soft and c.dist > -self.soft_depth:
                    continue
                return True
        return False

    # ---------- IK ----------
    def ik(self, pos, mat, q0, iters=200, tol_p=0.004, tol_r=0.03):
        q = np.array(q0, float)
        jacp = np.zeros((3, self.m.nv))
        jacr = np.zeros((3, self.m.nv))
        for _ in range(iters):
            self.set_q(q)
            p = self.d.site_xpos[self.site]
            M = self.d.site_xmat[self.site].reshape(3, 3)
            ep = pos - p
            er = T.quat2axisangle(T.mat2quat(mat @ M.T))
            if np.linalg.norm(ep) < tol_p and np.linalg.norm(er) < tol_r:
                return q
            mujoco.mj_jacSite(self.m, self.d, jacp, jacr, self.site)
            J = np.vstack([jacp[:, self.vadr], jacr[:, self.vadr]])
            e = np.r_[ep, er]
            dq = J.T @ np.linalg.solve(J @ J.T + 1e-3 * np.eye(6), e)
            q = np.clip(q + np.clip(dq, -0.2, 0.2), self.lo, self.hi)
        return None

    def ik_free(self, pos, mat, seeds=8):
        """충돌 없는 IK 해. 현재 자세, OSC posture, 무작위 seed 순으로 시도."""
        cands = [self.q_now(), np.array(self.R.robot.part_controllers["right"].initial_joint)]
        cands += [self.rng.uniform(self.lo, self.hi) for _ in range(seeds)]
        for q0 in cands:
            q = self.ik(pos, mat, q0)
            if q is not None and not self.in_collision(q):
                return q
        return None

    def line(self, q0, p1, mat, step=0.01, allowed_tail=None, tail=0.0):
        """q0의 손 위치에서 p1까지 손을 직선(자세 mat 고정)으로: 관절 경로(list) 또는 None.
        allowed_tail: 끝 tail(m) 구간에서만 닿아도 되는 body 집합 (잡을 물체)."""
        p0, _ = self.fk(q0)
        p1 = np.asarray(p1, float)
        n = max(1, int(np.ceil(np.linalg.norm(p1 - p0) / step)))
        path, q = [np.array(q0)], np.array(q0)
        keep = self.allowed
        try:
            for k in range(1, n + 1):
                p = p0 + (p1 - p0) * k / n
                q2 = self.ik(p, mat, q, iters=60)
                if q2 is None or np.max(np.abs(q2 - q)) > 0.5:
                    return None
                self.allowed = keep | (allowed_tail or set()) if np.linalg.norm(p1 - p) <= tail else keep
                if self.in_collision(q2):
                    return None
                path.append(q2)
                q = q2
        finally:
            self.allowed = keep
        return path

    # ---------- RRT-connect ----------
    def edge_free(self, a, b, res=0.04):
        n = int(np.ceil(np.max(np.abs(b - a)) / res))
        for t in np.linspace(0, 1, max(n, 2))[1:]:
            if self.in_collision(a + (b - a) * t):
                return False
        return True

    def plan(self, q_start, q_goal, iters=6000, step=0.15):
        import time

        t0 = time.time()
        if self.edge_free(q_start, q_goal):
            return [q_start, q_goal]
        Ta, Tb = [(q_start, -1)], [(q_goal, -1)]

        def nearest(Tr, q):
            return int(np.argmin([np.linalg.norm(n[0] - q) for n in Tr]))

        def extend(Tr, q):
            i = nearest(Tr, q)
            qn = Tr[i][0]
            d = q - qn
            dist = np.linalg.norm(d)
            qnew = q if dist <= step else qn + d / dist * step
            if self.edge_free(qn, qnew):
                Tr.append((qnew, i))
                return len(Tr) - 1, np.allclose(qnew, q)
            return None, False

        for k in range(iters):
            if self.time_limit is not None and time.time() - t0 > self.time_limit:
                return None
            qr = q_goal if k % 10 == 0 else self.rng.uniform(self.lo, self.hi)
            ia, _ = extend(Ta, qr)
            if ia is None:
                Ta, Tb = Tb, Ta
                continue
            qa = Ta[ia][0]
            while True:
                ib, reached = extend(Tb, qa)
                if ib is None:
                    break
                if reached:
                    pa, pb = [], []
                    i = ia
                    while i != -1:
                        pa.append(Ta[i][0]); i = Ta[i][1]
                    i = ib
                    while i != -1:
                        pb.append(Tb[i][0]); i = Tb[i][1]
                    path = pa[::-1] + pb
                    if not np.allclose(path[0], q_start):
                        path = path[::-1]
                    return self.shortcut(path)
            Ta, Tb = Tb, Ta
        return None

    def shortcut(self, path, tries=60):
        path = list(path)
        for _ in range(tries):
            if len(path) < 3:
                break
            i, j = sorted(self.rng.choice(len(path), 2, replace=False))
            if j - i < 2:
                continue
            if self.edge_free(path[i], path[j]):
                path = path[:i + 1] + path[j:]
        return path

    # ---------- 실행 ----------
    def execute(self, path, res=0.08, grip=None, final_mat=None):
        """관절 경로를 OSC로 따라감: 경유 관절값의 FK 자세로 move_ee + nullspace posture를 그 관절값으로."""
        ctrl = self.R.robot.part_controllers["right"]
        posture0 = np.array(ctrl.initial_joint)
        dense = [path[0]]
        for a, b in zip(path[:-1], path[1:]):
            n = int(np.ceil(np.max(np.abs(b - a)) / res))
            dense += [a + (b - a) * t for t in np.linspace(0, 1, max(n, 2))[1:]]
        try:
            for k, q in enumerate(dense):
                self.sync_keep()
                pos, mat = self.fk(q)
                ctrl.initial_joint = np.array(q)
                last = k == len(dense) - 1
                self.R.move_ee(pos, mat, tol=0.006 if last else 0.02, rot_tol=0.05 if last else 0.15,
                               max_steps=60 if last else 10, grip=grip)
        finally:
            ctrl.initial_joint = posture0
        return np.linalg.norm(self.q_now() - dense[-1])

    def sync_keep(self):
        """scratch를 실제 상태로 맞춘다 (물체가 움직였을 수 있음)."""
        self.d.qpos[:] = self.sim.data.qpos
        mujoco.mj_forward(self.m, self.d)

    def go(self, pos, mat, grip=None):
        """충돌 없이 eef를 (pos, mat)로. 성공 여부와 사유."""
        self.baseline()
        qg = self.ik_free(pos, mat)
        if qg is None:
            return False, "no_ik"
        path = self.plan(self.q_now(), qg)
        if path is None:
            return False, "no_path"
        self.execute(path, grip=grip)
        return np.linalg.norm(self.R.eef_pos - pos) < 0.02, "ok"
