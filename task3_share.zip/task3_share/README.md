# RoboCasa365 3-task Code-as-Policies (CaP)

PrepareCoffee, StirVegetables, PrepareVeggieDip 세 task를 skill 단위로 나눠 Code-as-Policies로 푸는 코드입니다.
각 skill은 precondition / content / except / effect 네 부분으로 정의되어 있고, task 프로그램은 skill을 순서대로 부릅니다.

- 결과 요약과 학습 대상 판정: [docs/focus3_result.md](docs/focus3_result.md)
- skill별 성공·실패 영상 페이지: https://claude.ai/artifact/DSweJ1F5sshWGqymwMfLwb (비공개 artifact라 열람하려면 공유 받아야 합니다)

## 먼저 알아 둘 점

- **인식은 시뮬레이터 정답(GT)입니다.** 물체 위치·자세, 가전 관절 값을 MuJoCo에서 직접 읽습니다(`cap/world.py`).
  실제 배포에서는 이 자리를 Perceptor가 대신해야 합니다.
- **정책은 action으로만 환경을 바꿉니다.** 문 상태를 직접 쓰는 `open_door()`, `set_knob_state()`, base 순간 이동 같은 함수는 쓰지 않습니다.
  예외는 구간 평가의 setup 하나입니다(아래 "구간 평가" 참고).
- **task 프로그램은 사람이 짜 둔 고정 코드입니다.** 원래 CaP처럼 실행할 때 LLM이 코드를 생성하는 구조는 아닙니다.
  지금 수치는 "좋은 skill과 GT가 주어졌을 때 스크립트로 어디까지 되는가"의 상한에 가깝습니다.

## 환경

| 항목 | 버전 (확인한 환경) |
|---|---|
| Python | 3.11.16 |
| robocasa | 1.0.1 (git 4f8a298) |
| robosuite | 1.5.2 (git 5ce6643f) |
| mujoco | 3.3.1 |
| numpy | 2.2.5 |
| 기타 | scipy 1.15.3, imageio 2.34.2 (+ imageio-ffmpeg, 영상 저장용) |

- RoboCasa 가구·물체 asset이 내려받아져 있어야 합니다(`python -m robocasa.scripts.download_kitchen_assets`).
- 화면 없는 서버에서는 EGL 렌더링을 씁니다. `cap/env.py`가 `MUJOCO_GL=egl`을 기본으로 설정합니다.
- 로봇은 RoboCasa 기본 `PandaOmron`입니다. action은 팔 OSC delta 6, 그리퍼 1, base 속도 3, torso 1, mode 1로 12차원입니다.

원래 서버에서는 conda 환경 `rc365_cli`(`/data/miniconda3/envs/rc365_cli/bin/python`)로 돌렸습니다.
아래 명령의 `python`은 위 패키지가 깔린 Python으로 바꿔 쓰면 됩니다. 모든 명령은 이 폴더(`task3_share/`)에서 실행합니다.

## 빠른 실행

세 task 전체 프로그램을 장면 0-9에서 병렬로 돌립니다.

```bash
python scripts/run_eval.py --run full_test \
  --tasks "PrepareCoffee@full3,StirVegetables@full3,PrepareVeggieDip@full3" \
  --scenes 0-9 --workers 8
python scripts/summarize.py full_test     # episode마다 skill 순서와 실패 원인
python scripts/table.py full_test         # task별·skill별 성공률 표 (markdown)
```

- 결과: `runs/<run>/<task>/scene<k>.json` (skill 호출 기록, 실패 코드, step 수)과 `scene<k>.mp4`(위 카메라 | 손목 카메라)
- `--no-video`: 영상 없이 빠르게 돌립니다.
- `--workers`: 동시에 띄울 시뮬레이터 수. 하나에 CPU 1코어, 메모리 2~3 GB 정도입니다.
- `--seed-offset 1000`: 개발용 배치. 같은 부엌에 물체·배치만 다릅니다. 공식 평가는 0(seed = scene)입니다.
- 장면 k는 benchmark target split의 (layout, style) 중 그 task가 쓸 수 있는 k번째 쌍입니다(`cap/env.py`의 `scene_pair`).
- PrepareVeggieDip의 scene 3, 8은 RoboCasa가 장면을 만들지 못해 매번 `_load_model() 50 times`로 끝납니다. 정책과 무관합니다.

## 구간 평가 (`Task@stage`)

task 하나를 구간(skill 묶음)으로 떼어 시험합니다. `--tasks`에 `Task@stage`를 넘기면 됩니다.

```bash
python scripts/run_eval.py --run stage_test --tasks "StirVegetables@stir,CoffeeSetupMug@precise" --scenes 0-9 --workers 8
```

| 이름 | 시험하는 구간 | 정의 위치 |
|---|---|---|
| `PrepareCoffee@full3` | PrepareCoffee 전체 | `cap/stages_focus3.py` |
| `StirVegetables@full3` | StirVegetables 전체 | `cap/stages_focus3.py` |
| `PrepareVeggieDip@full3` | PrepareVeggieDip 전체 | `cap/stages_focus3.py` |
| `PrepareCoffee@pick_enclosed` | 벽장 안 머그 꺼내기 | `cap/stages_enclosed.py` |
| `CoffeeSetupMug@precise` | 머그 손잡이 잡기 + 노즐 아래 놓기 (RoboCasa 단독 task) | `cap/stages_precise.py` |
| `StirVegetables@place` | 채소 2개 냄비에 넣기 | `cap/stages.py` |
| `StirVegetables@stir` | 주걱 집고 젓기 (채소를 미리 냄비에 넣은 상태에서 시작) | `cap/stages.py` |
| `PrepareVeggieDip@pick_enclosed` | 냉장고에서 채소 꺼내기 | `cap/stages_enclosed.py` |
| `PrepareVeggieDip@pick_cheese_enclosed` | 냉장고에서 크림치즈 꺼내기 | `cap/stages_enclosed.py` |
| `PickPlaceCounterToBlender@precise` | 블렌더 용기에 넣기 (단독 task) | `cap/stages_precise.py` |
| `CloseBlenderLid@precise` | 블렌더 뚜껑 닫기 (단독 task) | `cap/stages_precise.py` |
| `TurnOnBlender@precise` | 블렌더 전원 (단독 task) | `cap/stages_precise.py` |
| `PrepareVeggieDip@lid_power_precise` | 뚜껑 닫기 + 전원 (재료를 미리 블렌더에 넣은 상태) | `cap/stages_precise.py` |

각 구간은 `setup`(앞 구간이 끝난 상태 만들기), `program`(그 구간의 CaP 코드), `success`(완료 판정)로 되어 있습니다.
**setup에서만** 평가 준비를 위해 물체 위치를 직접 옮깁니다. 예: 젓기 구간은 채소를 냄비 안에 놓고 시작합니다.
그 뒤 정책은 action으로만 움직입니다.

## Astra 고정 장면에서 실행 (선택)

Astra 실험과 같은 초기 상태(PrepareCoffee, StirVegetables 장면 0-4)에서 돌릴 때 씁니다.
`astra-robocasa` 저장소와 고정 장면 묶음이 있어야 합니다.

```bash
export ASTRA_ROOT=/path/to/astra-robocasa
export ASTRA_SCENE_ROOT=/path/to/astra-robocasa-scenes/common-eval-panda-diverse-scenes-20261006
python scripts/run_frozen.py --task "PrepareCoffee@full3,StirVegetables@full3" --scenes 0-4 --run astra_test --workers 10
```

고정 장면은 aarch64 서버에서 만들어졌습니다. x86에서는 메시 다각형 배열 6개(`mesh_poly*`, `plugin_attr`)의 모양이 달라 그 배열만 건너뛰고 복원합니다.
물체·로봇 위치 차이는 1e-15 수준이고, 건너뛴 배열 이름은 결과 json의 `restore_skipped_arrays`에 남습니다.

## 코드 구조

```
cap/
  env.py            make_env(task, scene, seed): 장면 고정 env 생성, Recorder(영상)
  robot.py          저수준 primitive: move_ee(손 목표 자세), move_ee_path, move_base, gripper, set_torso, go_home
  world.py          GT 상태 읽기: 물체 위치·bbox, 관절 값, 위/아래 ray(천장·바닥 높이)
  planner.py        팔 경로 계획: 충돌 검사 IK + RRT-connect, OSC nullspace 자세를 계획 관절값으로 바꿔 가며 추종
  fx.py             fixture 기하: 내부 region, 빈 자리 찾기
  skill.py          Skill 형식 (precondition / content / effect / on_except), 재시도, 실행 기록
  skills/           skill 구현
    manip.py          pick, place, retreat
    enclosed.py       pick_enclosed (벽장·냉장고 칸 안에서 꺼내기)
    precise.py        grasp_mug_handle, place_under_nozzle, place_into_jug, grasp_lid, close_lid_precise, press_blender_power
    contact.py        pick_tool, stir_push (젓기), 이전 실험의 stir/scrub/pour
    nav.py            navigate (A* + base 추종), approach (base 조금 옮기기)
    controls.py       press_button, turn_knob 등
    composite_extra.py navigate_near, navigate_pose, wait
    doors.py, slide.py 문·서랍 (composite 프로그램이 import)
  programs/         task 프로그램 (@program("TaskName")). precise.py, contact.py의 함수를 구간들이 씀
  stages.py         구간 평가 등록 (@stage) + 젓기·넣기 구간
  stages_focus3.py  세 task 전체 프로그램 (@full3)
  stages_enclosed.py, stages_precise.py  꺼내기·정밀 놓기 구간
scripts/
  run_eval.py       병렬 평가 (job마다 새 프로세스, 렌더러 crash는 2번까지 재시도)
  run_frozen.py     Astra 고정 장면에서 평가
  summarize.py, table.py  결과 요약
  frames.py         영상에서 프레임 몇 장 뽑기 (실패 진단용)
  make_demo_clips.py, make_demo_page.py  skill별 영상 클립·데모 HTML 만들기
docs/               계획, 결과, 구간별 상세 보고, skill 설명(glossary)
tests/test_primitives.py  primitive 동작 확인 (move_ee, move_base 오차)
```

## 세 task 프로그램 흐름

`cap/stages_focus3.py`에 있습니다.

**PrepareCoffee**
`pick_enclosed`(벽장 안 머그를 벽을 잡고 꺼냄) → `navigate_near`(커피머신 앞) → `place`(로봇 앞 카운터에 잠깐 내려놓음)
→ `grasp_mug_handle`(손잡이로 다시 잡기) → `place_under_nozzle` → `retreat` → `press_button`

**StirVegetables**
(채소마다) `approach`(채소-냄비 사이로 base 이동) → `pick` → `place`(냄비 안 좌/우) → `retreat`
→ `pick_tool`(주걱 손잡이) → `stir_push`(날을 냄비에 넣고 한 채소 뒤에서 다른 채소 쪽으로 밀기 반복)

**PrepareVeggieDip**
(채소, 크림치즈 각각) `pick_enclosed`(냉장고 칸) → `place` + `pick`(카운터에 내려놓고 다시 단단히 잡기)
→ `navigate`(블렌더) → `place_into_jug` → 냉장고 앞으로 복귀
→ `grasp_lid` → `close_lid_precise` → `press_blender_power`

## 현재 결과 (공식 장면 0-9, seed = scene)

| 구간 | 성공 | 판정 |
|---|---|---|
| 벽장 안 머그 꺼내기 | 10/10 | CaP |
| 머그를 노즐 아래 놓기 | 5/10 | 학습 후보 |
| 커피머신 버튼 | 10/10 | CaP |
| 채소 2개 냄비에 넣기 | 4/10 | CaP 보완 필요 |
| 주걱 집고 젓기 | 5/10 | 학습 대상 |
| 냉장고 채소 꺼내기 | 7/8 | CaP |
| 냉장고 크림치즈 꺼내기 | 5/8 | 학습 후보 |
| 블렌더에 넣기 | 8/10 | CaP (경계) |
| 블렌더 뚜껑 닫기 | 4/8 | 학습 대상 |
| 블렌더 전원 | 10/10 | CaP |

| 전체 task | target 장면 0-9 | Astra 고정 장면 0-4 |
|---|---|---|
| PrepareCoffee | 2/10 | 0/5 |
| StirVegetables | 2/10 | 0/5 |
| PrepareVeggieDip | 0/8 | 장면 없음 |

`/8`은 env 생성이 안 되는 장면 2개를 뺀 값입니다. 전체 task 실패는 위 학습 대상 구간 외에도 구간 사이 연결에서 많이 납니다.
예를 들어 손끝으로 집은 물체를 들고 이동하다 빠지거나, 머그를 내려놓고 손잡이로 다시 잡지 못합니다.
자세한 내용은 [docs/focus3_result.md](docs/focus3_result.md)에 있습니다.

## 새 skill 추가하기

```python
from cap.skill import Skill, skill
from cap.robot import SkillFailure

@skill("my_skill")
class MySkill(Skill):
    retries = 1                                  # content 재시도 횟수
    def precondition(self, w, obj, **kw):        # 안 맞으면 SkillFailure("pre_..."): 재시도 없이 실패
        ...
    def content(self, w, obj, **kw):             # 동작. w.R(Robot) primitive와 w(World) GT 조회만 사용
        ...
    def effect(self, w, obj, **kw):              # 완료 판정 (bool)
        return w.grasped(obj)
    def on_except(self, w, err, obj, **kw):      # 실패 후 복구. True면 재시도
        w.R.gripper(False)
        return True

MySkill(w)(obj="obj")   # 호출. 실행 기록은 w.history → 결과 json의 history
```

구간으로 시험하려면 `cap/stages_<이름>.py`를 새로 만들어 `@stage("Task@name", "Task")`로 등록합니다. 자동으로 불러옵니다.
더 자세한 규칙(금지 API, 평가 규칙)은 [docs/cap_dev_guide.md](docs/cap_dev_guide.md)에 있습니다.
