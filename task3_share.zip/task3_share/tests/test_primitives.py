"""primitive 폐루프 검증: move_ee 위치/자세, move_base 위치/yaw."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, time
from cap.env import make_env
from cap.robot import Robot
env = make_env("OpenDrawer", scene=0, seed=0, render=False); env.reset()
R = Robot(env)
down = np.array([[1,0,0],[0,-1,0],[0,0,-1]], float)  # gripper z 아래
# base frame 기준 down + base yaw 반영
Rb = R.base_mat
tgt_mat = Rb @ np.array([[0,1,0],[1,0,0],[0,0,-1]],float)
p0 = R.eef_pos.copy()
for d in [[0.1,0,0],[0,0.15,-0.1],[-0.1,-0.1,0.1]]:
    tgt = R.base_to_world(R.world_to_base(p0) + d)
    s0=R.steps; ok = R.move_ee(tgt, tgt_mat, tol=0.005)
    rerr = np.degrees(np.arccos(np.clip((np.trace(tgt_mat@R.eef_mat.T)-1)/2,-1,1)))
    print("move_ee", d, ok, "steps", R.steps-s0, "err mm", round(np.linalg.norm(tgt-R.eef_pos)*1000,1), "rot deg", round(rerr,1))
R.gripper(True); print("closed width", R.gripper_width); R.gripper(False); print("open width", R.gripper_width)
b0 = R.base_pos[:2].copy(); y0 = R.base_yaw
for dxy, dyaw in [([-0.3,0],0),([0,-0.3],0.5),([-0.3,0.3],-0.5)]:
    s0=R.steps; ok = R.move_base(b0+np.array(dxy), y0+dyaw)
    print("move_base", dxy, dyaw, ok, "steps", R.steps-s0, "err", np.round(b0+np.array(dxy)-R.base_pos[:2],3), round(y0+dyaw-R.base_yaw,3), "eef-in-base", np.round(R.world_to_base(R.eef_pos),3))
